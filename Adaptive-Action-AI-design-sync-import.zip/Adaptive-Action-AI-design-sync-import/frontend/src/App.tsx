import { useEffect, useState } from 'react'
import { Route, Routes } from 'react-router-dom'
import { AppHeader } from './components/Header/AppHeader'
import { SettingsDrawer } from './components/SettingsDrawer/SettingsDrawer'
import { useTelemetry } from './lib/useTelemetry'
import { api, type DomainManifest } from './lib/api'
import { CopilotPage } from './routes/CopilotPage'
import { GroundingPage } from './routes/GroundingPage'
import { MetricsPage } from './routes/MetricsPage'
import { TransactionsPage } from './routes/TransactionsPage'

const FALLBACK_NAVIGATION = [
  { id: 'assistant', label: 'Copilot', path: '/', capability: null },
  { id: 'records', label: 'Transactions', path: '/transactions', capability: null },
  { id: 'metrics', label: 'Metrics', path: '/metrics', capability: null },
  { id: 'grounding', label: 'Grounding', path: '/grounding', capability: null },
]

/* Domains select pages by stable navigation ids. Components remain trusted,
   compiled frontend code; a manifest can compose the app but cannot inject it. */
const PAGE_REGISTRY: Record<string, { element: React.ReactNode; contained: boolean }> = {
  assistant: { element: <CopilotPage />, contained: true },
  records: { element: <TransactionsPage />, contained: false },
  metrics: { element: <MetricsPage />, contained: true },
  grounding: { element: <GroundingPage />, contained: false },
}

function Contained({ children }: { children: React.ReactNode }) {
  return <div className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6">{children}</div>
}

export default function App() {
  const [settingsOpen, setSettingsOpen] = useState(false)
  const { data: telemetry, offline } = useTelemetry()
  const [domain, setDomain] = useState<DomainManifest | null>(null)
  const navigation = domain?.navigation ?? FALLBACK_NAVIGATION

  useEffect(() => {
    let active = true
    api.domains()
      .then(({ domains }) => {
        if (active) setDomain(domains[0] ?? null)
      })
      .catch(() => {
        // Compatibility with a backend from before domain discovery existed.
      })
    return () => { active = false }
  }, [])

  return (
    <div className="min-h-screen bg-bg">
      <AppHeader
        telemetry={telemetry}
        offline={offline}
        onOpenSettings={() => setSettingsOpen(true)}
        domain={domain}
      />
      {/* The record screens run edge-to-edge under the header with a
          full-height rail, so the centred container belongs to the routes that
          want it rather than to <main>. */}
      <main>
        <Routes>
          {navigation.map((item) => {
            const page = PAGE_REGISTRY[item.id]
            if (!page) return null
            return (
              <Route
                key={item.id}
                path={item.path}
                element={page.contained ? <Contained>{page.element}</Contained> : page.element}
              />
            )
          })}
          {/* A run id in the URL recovers that run from its checkpoint. This is
              what makes the durable approval gate reachable: the look-up screen
              opens a dispute, parks it here, and a reload still finds it. */}
          <Route path="/copilot/:runId" element={<Contained><CopilotPage /></Contained>} />
        </Routes>
      </main>
      <SettingsDrawer
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        telemetry={telemetry}
      />
    </div>
  )
}
