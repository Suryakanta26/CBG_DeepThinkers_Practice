import { CircleCheck, CircleX, Search } from 'lucide-react'
import type { InvestigationStep } from '../../lib/api'

export function InvestigationTimeline({ steps }: { steps: InvestigationStep[] }) {
  if (!steps.length) return null
  return (
    <section className="card p-4">
      <header className="mb-3 flex items-center gap-2">
        <Search size={14} className="text-accent" />
        <h2 className="text-sm font-semibold text-text">Agent investigation</h2>
      </header>
      <ol className="space-y-2">
        {steps.map((step, index) => (
          <li key={`${step.tool}-${index}`} className="flex items-start gap-2 text-xs">
            {step.status === 'ok' ? (
              <CircleCheck size={13} className="mt-0.5 shrink-0 text-success" />
            ) : (
              <CircleX size={13} className="mt-0.5 shrink-0 text-danger" />
            )}
            <div className="min-w-0">
              <span className="font-mono text-text">{step.tool}</span>
              <span className="ml-2 text-text-subtle">
                {step.status === 'ok' ? `${step.hits} evidence item(s)` : step.error}
              </span>
              <pre className="mt-1 overflow-x-auto text-[10px] text-text-subtle">
                {JSON.stringify(step.arguments)}
              </pre>
            </div>
          </li>
        ))}
      </ol>
    </section>
  )
}
