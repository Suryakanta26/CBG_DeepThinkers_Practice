import { Send } from 'lucide-react'
import { useState } from 'react'
import { ApiError, api, type Run } from '../../lib/api'

export function MissingInformationPanel({ run, onResumed }: {
  run: Run
  onResumed: (run: Run) => void
}) {
  const [transactionId, setTransactionId] = useState(run.transaction_id ?? '')
  const [customerId, setCustomerId] = useState(run.customer_id ?? '')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  if (run.status !== 'awaiting_information' || !run.run_id) return null

  async function resume() {
    if (!run.run_id) return
    setBusy(true)
    setError(null)
    try {
      onResumed(await api.provideRunInformation(run.run_id, {
        transaction_id: transactionId || null,
        customer_id: customerId || null,
      }))
    } catch (cause) {
      setError(cause instanceof ApiError ? cause.message : String(cause))
    } finally {
      setBusy(false)
    }
  }

  return (
    <section className="card space-y-3 border-warning/40 p-4">
      <div>
        <h2 className="text-sm font-semibold text-text">More information required</h2>
        <p className="mt-1 text-xs text-text-muted">
          Missing: {run.pending_input?.missing.join(', ') ?? 'required case facts'}
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        <input className="field w-44" value={transactionId}
          onChange={(event) => setTransactionId(event.target.value)}
          placeholder="Transaction ID" aria-label="Transaction ID" />
        <input className="field w-44" value={customerId}
          onChange={(event) => setCustomerId(event.target.value)}
          placeholder="Customer ID" aria-label="Customer ID" />
        <button className="btn-primary" disabled={busy} onClick={() => void resume()}>
          <Send size={14} />{busy ? 'Resuming' : 'Continue'}
        </button>
      </div>
      {error && <p className="text-xs text-danger">{error}</p>}
    </section>
  )
}
