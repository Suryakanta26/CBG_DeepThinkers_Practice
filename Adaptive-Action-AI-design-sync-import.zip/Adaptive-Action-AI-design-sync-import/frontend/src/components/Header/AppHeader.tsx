import { Settings } from 'lucide-react'
import { NavLink } from 'react-router-dom'
import type { DomainManifest, TelemetrySummary } from '../../lib/api'
import { HeaderMonitor } from './HeaderMonitor'
import { ThemeToggle } from './ThemeToggle'

const navClass = ({ isActive }: { isActive: boolean }) =>
  `rounded-md px-2.5 py-1.5 text-sm transition-colors ${
    isActive ? 'bg-accent-subtle font-medium text-accent' : 'text-text-muted hover:text-text'
  }`

export function AppHeader({
  telemetry,
  offline,
  onOpenSettings,
  domain,
}: {
  telemetry: TelemetrySummary | null
  offline: boolean
  onOpenSettings: () => void
  domain: DomainManifest | null
}) {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-surface/90 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-[1400px] items-center gap-4 px-4 sm:px-6">
        <div className="flex items-center gap-2">
          <span className="h-4 w-1 rounded-full bg-accent" aria-hidden="true" />
          <span className="text-sm font-semibold tracking-tight text-text">
            {domain?.name ?? 'Adaptive Copilot'}
          </span>
        </div>

        <nav className="flex items-center gap-1" aria-label="Primary">
          {(domain?.navigation ?? [
            { id: 'assistant', label: 'Copilot', path: '/', capability: null },
            { id: 'records', label: 'Transactions', path: '/transactions', capability: null },
            { id: 'metrics', label: 'Metrics', path: '/metrics', capability: null },
            { id: 'grounding', label: 'Grounding', path: '/grounding', capability: null },
          ]).map((item) => (
            <NavLink key={item.id} to={item.path} className={navClass} end={item.path === '/'}>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-4">
          <HeaderMonitor data={telemetry} offline={offline} />
          <div className="flex items-center gap-2 border-l border-border pl-4">
            <ThemeToggle />
            <button
              type="button"
              onClick={onOpenSettings}
              className="btn-ghost"
              aria-label="Open settings"
              title="Settings"
            >
              <Settings size={15} />
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
