"""Contract and dependency tests for the domain boundary."""

from __future__ import annotations

import unittest
from pathlib import Path

from app.domains.banking_disputes.definition import BankingDisputesDomain
from app.platform.domains.contracts import DomainManifest


class DomainContractTests(unittest.TestCase):
    def test_banking_manifest_is_valid_and_workflow_is_resolvable(self) -> None:
        domain = BankingDisputesDomain()
        manifest = DomainManifest.model_validate(domain.manifest)
        self.assertEqual(manifest.id, "banking-disputes")
        self.assertEqual(domain.workflow("dispute-resolution").__class__.__name__,
                         "DisputeWorkflow")
        self.assertGreater(len(manifest.retrieval_triggers), 0)
        self.assertIn("action_labels", manifest.presentation)
        self.assertEqual(
            domain.action_service().__class__.__name__, "BankingActionService")

    def test_unknown_workflow_is_rejected(self) -> None:
        with self.assertRaises(KeyError):
            BankingDisputesDomain().workflow("missing")

    def test_platform_does_not_import_concrete_domains(self) -> None:
        platform = Path(__file__).parents[1] / "app" / "platform"
        offenders: list[str] = []
        for source in platform.rglob("*.py"):
            if "app.domains" in source.read_text(encoding="utf-8"):
                offenders.append(str(source.relative_to(platform)))
        self.assertEqual(offenders, [], f"platform imports concrete domains: {offenders}")


if __name__ == "__main__":
    unittest.main()
