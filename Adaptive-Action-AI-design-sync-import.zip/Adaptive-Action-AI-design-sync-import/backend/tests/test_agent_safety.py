"""Safety boundaries for agent-selected tools and approved actions."""

import unittest

from pydantic import BaseModel

from app.agents import actions
from app.agents.nodes import route_after_recommend
from app.agents.investigation import _validate_plan
from app.domains.banking_disputes.validators import validate_recommendation
from app.llm.factory import SchemaValidationError
from app.platform.tools import ToolRegistry, ToolSpec
from app.schemas.dispute import InvestigationPlan, Recommendation
from app.schemas.grounding import Evidence, EvidenceKind, GroundingContext, SourceTier


class EmptyInput(BaseModel):
    pass


class AgentSafetyTests(unittest.TestCase):
    def test_write_tool_is_not_agent_executable(self) -> None:
        registry = ToolRegistry("test", [
            ToolSpec("read", "read", "read", EmptyInput, lambda _: "ok"),
            ToolSpec("write", "write", "write", EmptyInput, lambda _: "changed"),
        ])
        self.assertEqual(registry.execute("read", {}), "ok")
        with self.assertRaises(PermissionError):
            registry.execute("write", {})

    def test_investigation_hydrates_known_merchant_id(self) -> None:
        plan = InvestigationPlan.model_validate({
            "ready": False,
            "calls": [{
                "tool": "get_merchant_risk", "arguments": {},
                "reason": "Check merchant risk.",
            }],
            "rationale": "Merchant evidence is relevant.",
        })
        validated = _validate_plan(plan, {"merchant_id": "MERCH-201"})
        self.assertEqual(validated.calls[0].arguments, {"merchant_id": "MERCH-201"})

    def test_investigation_rejects_missing_required_tool_argument(self) -> None:
        plan = InvestigationPlan.model_validate({
            "ready": False,
            "calls": [{
                "tool": "get_merchant_risk", "arguments": {},
                "reason": "Check merchant risk.",
            }],
            "rationale": "Merchant evidence is relevant.",
        })
        with self.assertRaises(SchemaValidationError):
            _validate_plan(plan)

    def test_action_plan_hash_changes_with_effects(self) -> None:
        recommendation = Recommendation.model_validate({
            "action": "request_merchant_contact", "headline": "Contact merchant",
            "rationale": "Required by PCT-7.1", "citations": ["PCT-7.1"],
            "governing_clause": "PCT-7.1", "deadline": "none applicable",
            "requires_approval": False, "confidence": 0.8, "caveats": "",
        })
        first = actions.plan_envelope(recommendation, {
            "run_id": "run-1", "customer_id": "CUST-1",
        })
        second = actions.plan_envelope(recommendation, {
            "run_id": "run-1", "customer_id": "CUST-2",
        })
        self.assertNotEqual(first["hash"], second["hash"])

    def test_fraud_route_plans_a_referral_not_a_dispute_case(self) -> None:
        recommendation = Recommendation.model_validate({
            "action": "route_to_fraud_ops", "headline": "Route",
            "rationale": "Required by FSP-1.2", "citations": ["FSP-1.2"],
            "governing_clause": "FSP-1.2", "deadline": "none applicable",
            "requires_approval": True, "confidence": 0.9, "caveats": "",
        })
        steps = actions.plan(recommendation, {
            "run_id": "run-fraud", "transaction_id": "TXN-9001",
            "customer_id": "CUST-1001",
        })
        self.assertEqual([step["instrument"] for step in steps], ["fraud_referral"])
        self.assertEqual(steps[0]["path"], "/fraud-referrals")

    def test_answer_only_bypasses_approval_path(self) -> None:
        recommendation = Recommendation.model_validate({
            "action": "answer_only", "headline": "Policy answer",
            "rationale": "Supported by FSP-1.2", "citations": ["FSP-1.2"],
            "governing_clause": "FSP-1.2", "deadline": "none applicable",
            "requires_approval": False, "confidence": 0.9, "caveats": "",
        })
        self.assertEqual(
            route_after_recommend({"recommendation": recommendation}),
            "finalize_answer",
        )

    def test_unknown_citation_is_blocked(self) -> None:
        recommendation = Recommendation.model_validate({
            "action": "answer_only", "headline": "Answer",
            "rationale": "Policy", "citations": ["INVENTED-1"],
            "governing_clause": "PCT-7.1", "deadline": "none applicable",
            "requires_approval": False, "confidence": 0.8, "caveats": "",
        })
        grounding = GroundingContext(evidence=[Evidence(
            kind=EvidenceKind.POLICY, ref="PCT-7.1", title="Policy",
            content="Applicable policy", tier=SourceTier.PRODUCT_TERMS,
        )])
        with self.assertRaises(SchemaValidationError):
            validate_recommendation(recommendation, grounding)

    def test_annotated_known_citations_are_canonicalized(self) -> None:
        recommendation = Recommendation.model_validate({
            "action": "answer_only", "headline": "Fraud policy",
            "rationale": "Summary of the retrieved fraud policy.",
            "citations": [
                "FSP-1.2 (tier 3): Mandatory routing for flagged transactions.",
                "FSP-5.1 (tier 3): Fraud Operations handles communication.",
            ],
            "governing_clause": "FSP-1.2 (tier 3)",
            "deadline": "none applicable", "requires_approval": False,
            "confidence": 0.8, "caveats": "",
        })
        grounding = GroundingContext(evidence=[
            Evidence(kind=EvidenceKind.POLICY, ref="FSP-1.2", title="Routing",
                     content="Mandatory routing.", tier=SourceTier.BANK_POLICY),
            Evidence(kind=EvidenceKind.POLICY, ref="FSP-5.1", title="Communication",
                     content="Fraud Operations communicates.", tier=SourceTier.BANK_POLICY),
        ])
        validated = validate_recommendation(recommendation, grounding)
        self.assertEqual(validated.citations, ["FSP-1.2", "FSP-5.1"])
        self.assertEqual(validated.governing_clause, "FSP-1.2")

    def test_cited_clause_must_authorize_the_selected_action(self) -> None:
        recommendation = Recommendation.model_validate({
            "action": "route_to_fraud_ops", "headline": "Route",
            "rationale": "A real clause was cited, but it governs another action.",
            "citations": ["PCT-7.1"], "governing_clause": "PCT-7.1",
            "deadline": "immediate", "requires_approval": True,
            "confidence": 0.8, "caveats": "",
        })
        grounding = GroundingContext(evidence=[Evidence(
            kind=EvidenceKind.POLICY, ref="PCT-7.1", title="Product terms",
            content="Provisional credit timing", tier=SourceTier.PRODUCT_TERMS,
        )])
        with self.assertRaises(SchemaValidationError):
            validate_recommendation(recommendation, grounding)

    def test_fraud_flag_deterministically_forces_fraud_routing(self) -> None:
        recommendation = Recommendation.model_validate({
            "action": "request_merchant_contact", "headline": "Contact merchant",
            "rationale": "Incorrect model selection.", "citations": ["FSP-1.2"],
            "governing_clause": "FSP-1.2", "deadline": "none applicable",
            "requires_approval": False, "confidence": 0.8, "caveats": "",
        })
        grounding = GroundingContext(evidence=[
            Evidence(kind=EvidenceKind.POLICY, ref="FSP-1.2", title="Fraud SOP",
                     content="A flagged transaction must route to Fraud Operations.",
                     tier=SourceTier.BANK_POLICY),
            Evidence(kind=EvidenceKind.RECORD, ref="REC:TXN-9001", title="Transaction",
                     content="Fraud-engine flag: PRESENT (score 0.97)."),
        ])
        validated = validate_recommendation(recommendation, grounding)
        self.assertEqual(validated.action.value, "route_to_fraud_ops")
        self.assertEqual(validated.governing_clause, "FSP-1.2")
        self.assertTrue(validated.requires_approval)
        self.assertIn("REC:TXN-9001", validated.citations)


if __name__ == "__main__":
    unittest.main()
