"""Regression tests for operational response contracts."""

import unittest

from app.config import get_settings
from app.main import health


class HealthContractTests(unittest.TestCase):
    def test_health_includes_prompt_cache_configuration(self) -> None:
        response = health()
        settings = get_settings()
        self.assertEqual(response.prompt_cache_enabled, settings.prompt_cache_enabled)
        self.assertEqual(response.prompt_cache_ttl_s, settings.prompt_cache_ttl_s)


if __name__ == "__main__":
    unittest.main()
