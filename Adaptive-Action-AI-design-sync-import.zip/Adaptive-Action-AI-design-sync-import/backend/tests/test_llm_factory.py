"""Regression tests for provider-compatible structured output schemas."""

import unittest

from pydantic import ValidationError

from app.llm.factory import _transport_schema
from app.schemas.dispute import InvestigationPlan, Recommendation


def _contains_key(value: object, target: str) -> bool:
    if isinstance(value, dict):
        return target in value or any(_contains_key(item, target) for item in value.values())
    if isinstance(value, list):
        return any(_contains_key(item, target) for item in value)
    return False


class TransportSchemaTests(unittest.TestCase):
    def test_transport_schema_removes_max_length_recursively(self) -> None:
        original = Recommendation.model_json_schema()
        transport = _transport_schema(Recommendation)

        self.assertTrue(_contains_key(original, "maxLength"))
        self.assertFalse(_contains_key(transport, "maxLength"))
        # Supported constraints must not be stripped accidentally.
        self.assertEqual(transport["properties"]["citations"]["minItems"], 1)
        self.assertEqual(transport["properties"]["confidence"]["minimum"], 0.0)
        self.assertEqual(transport["properties"]["confidence"]["maximum"], 1.0)

    def test_local_model_still_enforces_removed_constraint(self) -> None:
        payload = {
            "action": "answer_only",
            "headline": "x" * 201,
            "rationale": "Supported by the governing clause.",
            "citations": ["PCT-7.1"],
            "governing_clause": "PCT-7.1",
            "deadline": "none applicable",
            "requires_approval": False,
            "confidence": 0.8,
            "caveats": "",
        }

        with self.assertRaises(ValidationError):
            Recommendation.model_validate(payload)

    def test_investigation_commentary_is_safely_bounded(self) -> None:
        plan = InvestigationPlan.model_validate({
            "ready": True, "calls": [], "rationale": "x" * 700,
        })
        self.assertEqual(len(plan.rationale), 500)

        plan = InvestigationPlan.model_validate({
            "ready": False,
            "calls": [{"tool": "search_policy", "arguments": {}, "reason": "x" * 400}],
            "rationale": "Need policy evidence.",
        })
        self.assertEqual(len(plan.calls[0].reason), 300)


if __name__ == "__main__":
    unittest.main()
