"""Domain-neutral discovery and workflow endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException

from app.platform.domains.contracts import DecisionInput
from app.platform.domains.registry import get_domain, list_domains

router = APIRouter(prefix="/api/v1", tags=["domains"])


def _domain(domain_id: str):
    try:
        return get_domain(domain_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


def _workflow(domain_id: str, workflow_id: str):
    try:
        return _domain(domain_id).workflow(workflow_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/domains")
def domains() -> dict[str, Any]:
    return {"domains": [manifest.model_dump(mode="json") for manifest in list_domains()]}


@router.get("/domains/{domain_id}")
def domain_manifest(domain_id: str) -> dict[str, Any]:
    return _domain(domain_id).manifest.model_dump(mode="json")


@router.get("/domains/{domain_id}/tools")
def domain_tools(domain_id: str) -> dict[str, Any]:
    registry = _domain(domain_id).tool_registry()
    return {
        "domain_id": domain_id,
        "read_tools": registry.descriptions(mode="read"),
        # Write tools are discoverable for review, but the registry still
        # refuses their execution without an approved plan.
        "write_tools": registry.descriptions(mode="write"),
    }


@router.post("/domains/{domain_id}/workflows/{workflow_id}/runs")
def start_run(domain_id: str, workflow_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return _workflow(domain_id, workflow_id).start(payload)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/domains/{domain_id}/workflows/{workflow_id}/runs/{run_id}")
def get_run(domain_id: str, workflow_id: str, run_id: str) -> dict[str, Any]:
    result = _workflow(domain_id, workflow_id).get(run_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"no run '{run_id}'")
    return result


@router.post("/domains/{domain_id}/workflows/{workflow_id}/runs/{run_id}/decisions")
def decide_run(
    domain_id: str, workflow_id: str, run_id: str, decision: DecisionInput,
) -> dict[str, Any]:
    try:
        return _workflow(domain_id, workflow_id).decide(run_id, decision)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"no run '{run_id}'") from exc
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/domains/{domain_id}/workflows/{workflow_id}/runs/{run_id}/inputs")
def provide_run_input(
    domain_id: str, workflow_id: str, run_id: str, payload: dict[str, Any],
) -> dict[str, Any]:
    try:
        return _workflow(domain_id, workflow_id).provide_input(run_id, payload)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"no run '{run_id}'") from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
