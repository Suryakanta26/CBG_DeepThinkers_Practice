"""Banking-dispute implementation of the domain platform contracts.

This adapter deliberately wraps the established implementation first. Moving
its nodes, prompts and repositories under this package can now happen without
changing the platform API contract.
"""

from __future__ import annotations

from typing import Any

from app.agents import actions, graph as agent_graph
from app.db import cases, trace
from app.platform.domains.contracts import (
    DecisionInput,
    DomainManifest,
    NavigationItem,
    RetrievalTrigger,
    WorkflowManifest,
    WorkflowService,
)
from app.schemas.dispute import DisputeRequest
from app.tools import core_banking
from app.domains.banking_disputes.tools import registry as banking_tools
from app.domains.banking_disputes.approval import validate_approval
from app.domains.banking_disputes.actions import service as banking_actions


def _status(state: dict[str, Any], output: Any) -> str:
    if state.get("decision") == "rejected":
        return "rejected"
    if state.get("decision") == "approved":
        results = state.get("action_results") or []
        return ("approved_action_failed" if any(
            result.get("status_code") != 200 for result in results) else "approved")
    if output and output.action.value == "answer_only":
        return "answered"
    if output:
        return "awaiting_approval"
    assessment = state.get("evidence_assessment")
    return "awaiting_information" if assessment and assessment.missing else "incomplete"


def _serialise(state: dict[str, Any], *, expanded: bool = False) -> dict[str, Any]:
    grounding = state.get("grounding")
    output = state.get("recommendation")
    action_plan = state.get("action_plan") or (
        actions.plan_envelope(output, state) if output else None
    )
    result = {
        "run_id": state.get("run_id"),
        "domain_id": "banking-disputes",
        "workflow_id": "dispute-resolution",
        "workflow_version": "1.0.0",
        "status": _status(state, output),
        "created_at": state.get("started_at"),
        "updated_at": state.get("approved_at") or state.get("started_at"),
        "input": {
            "text": state.get("request_text"),
            "transaction_id": state.get("transaction_id"),
            "customer_id": state.get("customer_id"),
        },
        "output": output.model_dump(mode="json") if output else None,
        "evidence": ([e.model_dump(mode="json") for e in grounding.by_precedence()]
                     if grounding else []),
        "approval": {
            "decision": state.get("decision"),
            "actor": state.get("approver"),
            "actor_role": state.get("approver_role"),
            "decided_at": state.get("approved_at"),
            "reason": state.get("reject_reason"),
        },
        "planned_actions": [
            {"id": step["instrument"], "input": step["payload"]}
            for step in (action_plan or {}).get("steps", [])
        ],
        "action_plan_hash": (action_plan or {}).get("hash"),
        "investigation": state.get("investigation") or [],
        "evidence_assessment": (state["evidence_assessment"].model_dump(mode="json")
                                if state.get("evidence_assessment") else None),
        "pending_input": state.get("pending_input"),
        "action_executions": state.get("action_results") or [],
        "metadata": {
            "elapsed_ms": state.get("elapsed_ms", 0),
            "case_id": state.get("case_id"),
            "domain_record_id": state.get("dispute_id"),
        },
        "presentation": domain.manifest.presentation,
    }
    if expanded:
        run_id = str(state["run_id"])
        result["events"] = trace.events(run_id)
        result["effects"] = core_banking.effects_for(run_id)
        result["domain_record"] = cases.by_run(run_id)
    return result


class DisputeWorkflow(WorkflowService):
    def start(self, payload: dict[str, Any]) -> dict[str, Any]:
        request = DisputeRequest.model_validate(payload)
        state = agent_graph.run(
            request.text,
            transaction_id=request.transaction_id,
            customer_id=request.customer_id,
            attachments=request.attachments,
        )
        return _serialise(state)

    def get(self, run_id: str) -> dict[str, Any] | None:
        state = agent_graph.get_state(run_id)
        return _serialise(state, expanded=True) if state else None

    def decide(self, run_id: str, decision: DecisionInput) -> dict[str, Any]:
        current = agent_graph.get_state(run_id)
        if current is None:
            raise KeyError(run_id)
        recommendation = current.get("recommendation")
        if recommendation is None:
            raise RuntimeError("run has no recommendation to decide")
        amount = recommendation.amount or 0.0
        if decision.decision == "approved":
            validate_approval(amount=amount, actor_role=decision.actor_role)
        action_plan = current.get("action_plan") or actions.plan_envelope(
            recommendation, current)
        if decision.decision == "approved" and decision.plan_hash is not None:
            if decision.plan_hash != action_plan["hash"]:
                raise RuntimeError(
                    "the action plan changed after it was displayed; reload and review it again"
                )
        state = agent_graph.resume(
            run_id,
            decision=decision.decision,
            approver=decision.actor,
            approver_role=decision.actor_role,
            note=decision.note,
            reject_reason=decision.reason,
            approved_plan_hash=action_plan["hash"]
            if decision.decision == "approved" else None,
        )
        return _serialise(state, expanded=True)

    def provide_input(self, run_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        state = agent_graph.provide_information(
            run_id,
            transaction_id=payload.get("transaction_id"),
            customer_id=payload.get("customer_id"),
        )
        return _serialise(state, expanded=True)


class BankingDisputesDomain:
    manifest = DomainManifest(
        id="banking-disputes",
        name="Banking Disputes",
        version="1.0.0",
        description="Grounded card-dispute resolution with human approval.",
        capabilities=["workflows", "records", "grounding", "graph", "actions", "metrics",
                      "agent_tools"],
        workflows=[WorkflowManifest(
            id="dispute-resolution",
            name="Dispute resolution",
            description="Triage, retrieve, reconcile, recommend and approve a dispute action.",
            input_schema="banking-disputes/DisputeRequest@1",
            output_schema="banking-disputes/Recommendation@1",
            requires_approval=True,
        )],
        navigation=[
            NavigationItem(id="assistant", label="Copilot", path="/"),
            NavigationItem(id="records", label="Transactions", path="/transactions",
                           capability="records"),
            NavigationItem(id="metrics", label="Metrics", path="/metrics", capability="metrics"),
            NavigationItem(id="grounding", label="Grounding", path="/grounding",
                           capability="grounding"),
        ],
        terminology={
            "assistant": "Copilot", "record": "Transaction", "subject": "Customer",
            "case": "Dispute", "proposal": "Recommendation",
        },
        retrieval_triggers=[
            RetrievalTrigger(id="fraud_flag_routing", field="fraud_flag", op="truthy",
                             query="fraud engine flag mandatory routing to fraud operations dispute intake",
                             why="A record-only fraud flag mandates policy retrieval."),
            RetrievalTrigger(id="signature_tier_timing", field="product_tier", op="equals",
                             value="SIGNATURE",
                             query="accelerated provisional credit timing for Signature premium cardholders",
                             why="Product tier is authoritative record data."),
            RetrievalTrigger(id="small_amount_goodwill", field="amount", op="lt", value=50,
                             query="goodwill refund auto approval threshold and merchant contact requirement",
                             why="The posted amount determines goodwill eligibility."),
            RetrievalTrigger(id="high_risk_merchant", field="risk_band", op="equals", value="high",
                             query="merchant dispute history and chargeback representment evidence requirements",
                             why="Merchant risk is not supplied by the cardholder."),
        ],
        presentation={
            "action_labels": {
                "PROVISIONAL_CREDIT": "Provisional credit",
                "GOODWILL_REFUND": "Goodwill refund",
                "ROUTE_TO_FRAUD_OPS": "Route to fraud operations",
                "REQUEST_MERCHANT_CONTACT": "Request merchant contact",
                "DECLINE": "Decline",
            },
            "instrument_labels": {
                "dispute_case": "Dispute case",
                "fraud_referral": "Fraud Operations referral",
                "provisional_credit": "Provisional credit",
                "customer_notice": "Customer notice",
            },
            "approval": {
                "agent_limit": 500,
                "currency": "USD",
                "elevated_role": "team_lead",
                "elevated_role_label": "Team Lead",
                "policy_reference": "BDP-3.4",
            },
        },
    )
    _workflow = DisputeWorkflow()

    def workflow(self, workflow_id: str) -> WorkflowService:
        if workflow_id != "dispute-resolution":
            raise KeyError(f"unknown workflow '{workflow_id}'")
        return self._workflow

    def tool_registry(self):
        return banking_tools

    def action_service(self):
        return banking_actions


domain = BankingDisputesDomain()
