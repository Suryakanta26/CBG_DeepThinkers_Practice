"""Approval rules owned by the banking-disputes domain."""

AGENT_AUTHORITY_LIMIT = 500.0


def validate_approval(*, amount: float, actor_role: str | None) -> None:
    if amount > AGENT_AUTHORITY_LIMIT and actor_role != "team_lead":
        raise PermissionError(
            f"BDP-3.4: provisional credit above {AGENT_AUTHORITY_LIMIT:.0f} USD requires "
            f"Disputes Team Lead approval; this run is for {amount:.2f} USD and the "
            f"approver is recorded as '{actor_role}'."
        )
