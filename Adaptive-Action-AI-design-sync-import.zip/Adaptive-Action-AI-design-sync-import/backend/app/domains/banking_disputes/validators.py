"""Deterministic banking policy checks applied after model reasoning."""

from __future__ import annotations

from app.llm.factory import SchemaValidationError
from app.schemas.dispute import ActionType, Recommendation
from app.schemas.grounding import EvidenceKind, GroundingContext

ACTION_AUTHORITIES: dict[ActionType, tuple[str, ...]] = {
    ActionType.PROVISIONAL_CREDIT: ("BDP-3.4", "BDP-4.2", "PCT-7.1", "REG-E-3"),
    ActionType.GOODWILL_REFUND: ("GRS-",),
    ActionType.ROUTE_TO_FRAUD_OPS: ("FSP-1.2",),
    ActionType.REQUEST_MERCHANT_CONTACT: ("CNR-11.4",),
}


def _canonical_ref(value: str, known: set[str]) -> str | None:
    """Accept an exact ref or a known ref followed only by annotation text."""
    candidate = value.strip()
    if candidate in known:
        return candidate
    for ref in sorted(known, key=len, reverse=True):
        if candidate.startswith(ref) and candidate[len(ref):len(ref) + 1] in {
            " ", ":", "(", "[", "-", "–", "—",
        }:
            return ref
    return None


def canonicalize_references(
    result: Recommendation, grounding: GroundingContext,
) -> Recommendation:
    """Remove model-added prose from citations without accepting new refs."""
    known = set(grounding.citations())
    normalized: list[str] = []
    unknown: list[str] = []
    for citation in result.citations:
        ref = _canonical_ref(citation, known)
        if ref is None:
            unknown.append(citation)
        elif ref not in normalized:
            normalized.append(ref)
    if unknown:
        raise SchemaValidationError(
            f"citations are not present in evidence: {unknown}; use only exact refs from "
            f"{sorted(known)}"
        )
    governing = _canonical_ref(
        result.governing_clause, {item.ref for item in grounding.policy},
    )
    return result.model_copy(update={
        "citations": normalized,
        "governing_clause": governing or result.governing_clause,
    })


def apply_mandatory_rules(
    result: Recommendation, grounding: GroundingContext,
) -> Recommendation:
    """Apply record-triggered rules that leave the model no discretion."""
    fraud_records = [
        item for item in grounding.evidence
        if item.kind is EvidenceKind.RECORD
        and "Fraud-engine flag: PRESENT" in item.content
    ]
    policy_refs = {item.ref for item in grounding.policy}
    if fraud_records and "FSP-1.2" in policy_refs:
        record_ref = fraud_records[0].ref
        citations = list(dict.fromkeys(["FSP-1.2", record_ref, *result.citations]))
        return result.model_copy(update={
            "action": ActionType.ROUTE_TO_FRAUD_OPS,
            "headline": "Route the flagged transaction to Fraud Operations",
            "rationale": (
                f"The authoritative transaction record {record_ref} shows a fraud-engine "
                "flag. FSP-1.2 therefore requires Fraud Operations routing and removes "
                "the transaction from the standard dispute path."
            ),
            "citations": citations,
            "governing_clause": "FSP-1.2",
            "deadline": "none applicable",
            "requires_approval": True,
        })
    return result


def validate_recommendation(
    result: Recommendation, grounding: GroundingContext | None,
) -> Recommendation:
    if grounding is None:
        raise SchemaValidationError("recommendation has no grounding context")
    result = canonicalize_references(result, grounding)
    result = apply_mandatory_rules(result, grounding)
    known = set(grounding.citations())
    policy = {item.ref for item in grounding.policy}
    unknown = [citation for citation in result.citations if citation not in known]
    if unknown:  # Defensive check for any future mandatory-rule transformation.
        raise SchemaValidationError(f"citations are not present in evidence: {unknown}")
    if result.governing_clause not in policy:
        raise SchemaValidationError(
            f"governing_clause '{result.governing_clause}' is not a retrieved policy ref; "
            f"choose one of {sorted(policy)}"
        )
    authorities = ACTION_AUTHORITIES.get(result.action)
    if authorities and not any(result.governing_clause.startswith(ref) for ref in authorities):
        raise SchemaValidationError(
            f"clause '{result.governing_clause}' does not authorize action "
            f"'{result.action.value}'; expected authority matching {list(authorities)}"
        )
    return result
