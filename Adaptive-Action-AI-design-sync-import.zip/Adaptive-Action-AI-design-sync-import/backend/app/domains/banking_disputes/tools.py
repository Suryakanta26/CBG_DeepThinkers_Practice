"""Read-only tools available to the banking-disputes investigation agent."""

from __future__ import annotations

from pydantic import BaseModel, Field

from app.db import records
from app.graph.base import get_store
from app.platform.tools import ToolRegistry, ToolSpec
from app.rag import store as vector_store
from app.schemas.grounding import Evidence, EvidenceKind


class PolicySearchInput(BaseModel):
    query: str = Field(min_length=2, max_length=500)
    k: int = Field(default=6, ge=1, le=10)


class TransactionInput(BaseModel):
    transaction_id: str = Field(min_length=3, max_length=100)


class CustomerInput(BaseModel):
    customer_id: str = Field(min_length=3, max_length=100)


class MerchantInput(BaseModel):
    merchant_id: str = Field(min_length=3, max_length=100)


class ClauseInput(BaseModel):
    clause_id: str = Field(min_length=2, max_length=120)


def _transaction(args: TransactionInput) -> list[Evidence]:
    fact = records.transaction_facts(args.transaction_id)
    return [fact] if fact else []


def _transaction_graph(args: TransactionInput) -> list[Evidence]:
    row = get_store().transaction_context(args.transaction_id)
    if not row:
        return []
    return [Evidence(kind=EvidenceKind.GRAPH, ref=f"GRAPH:{args.transaction_id}",
                     title="Transaction neighbourhood", content=_render(row))]


def _customer_history(args: CustomerInput) -> list[Evidence]:
    rows = get_store().customer_dispute_history(args.customer_id)
    if not rows:
        return []
    body = "\n".join(
        f"- {row['opened_at']}: {row['reason_code']} {float(row['amount'] or 0):.2f} "
        f"-> {row['outcome']}" for row in rows
    )
    return [Evidence(kind=EvidenceKind.GRAPH, ref=f"GRAPH:{args.customer_id}:disputes",
                     title=f"Prior disputes for {args.customer_id} ({len(rows)})", content=body)]


def _merchant_risk(args: MerchantInput) -> list[Evidence]:
    row = get_store().merchant_risk_profile(args.merchant_id)
    if not row:
        return []
    return [Evidence(kind=EvidenceKind.GRAPH, ref=f"GRAPH:{args.merchant_id}",
                     title="Merchant risk profile", content=_render(row))]


def _clause_dependencies(args: ClauseInput) -> list[Evidence]:
    rows = get_store().policy_dependencies(args.clause_id)
    if not rows:
        return []
    return [Evidence(kind=EvidenceKind.GRAPH, ref=f"GRAPH:{args.clause_id}:deps",
                     title=f"Clause relationships for {args.clause_id}", content=_render_rows(rows))]


def _render(row: dict) -> str:
    return "\n".join(f"{key}: {value}" for key, value in row.items() if value not in (None, ""))


def _render_rows(rows: list[dict]) -> str:
    return "\n".join("; ".join(f"{key}: {value}" for key, value in row.items()) for row in rows)


registry = ToolRegistry("banking-disputes", [
    ToolSpec("search_policy", "Search the governed policy corpus for relevant clauses.",
             "read", PolicySearchInput,
             lambda args: vector_store.search(args.query, k=args.k)),
    ToolSpec("get_transaction", "Read authoritative transaction and cardholder facts.",
             "read", TransactionInput, _transaction),
    ToolSpec("get_transaction_context", "Read transaction relationships from the graph.",
             "read", TransactionInput, _transaction_graph),
    ToolSpec("get_customer_history", "Read the customer's prior dispute history.",
             "read", CustomerInput, _customer_history),
    ToolSpec("get_merchant_risk", "Read a merchant risk profile when its id is known.",
             "read", MerchantInput, _merchant_risk),
    ToolSpec("get_clause_dependencies", "Read precedence relationships for a policy clause.",
             "read", ClauseInput, _clause_dependencies),
])
