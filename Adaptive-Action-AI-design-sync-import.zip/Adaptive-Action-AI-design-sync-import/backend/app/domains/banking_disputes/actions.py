"""Domain-owned deterministic plans and approved core-banking execution."""
from __future__ import annotations
import hashlib
import json
from typing import Any
import httpx
from app.config import get_settings
from app.logging_setup import get_logger
from app.schemas.dispute import ActionType, Recommendation

log = get_logger("domains.banking_disputes.actions")
TIMEOUT_S = 15.0
ACTION_PLAN_VERSION = "1"

def _post(path: str, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
    url = f"http://127.0.0.1:{get_settings().port}/api/core-banking{path}"
    with httpx.Client(timeout=TIMEOUT_S) as client:
        response = client.post(url, json=payload)
    try:
        body = response.json()
    except ValueError:
        body = {"raw": response.text}
    return response.status_code, body

class BankingActionService:
    def plan(self, recommendation: Recommendation, state: dict[str, Any]) -> list[dict[str, Any]]:
        run_id, customer_id = state.get("run_id", ""), state.get("customer_id")
        transaction_id, triage = state.get("transaction_id"), state.get("triage")
        reason_code = triage.reason_code.value if triage else "other"
        amount, steps = recommendation.amount, []
        if recommendation.action is ActionType.PROVISIONAL_CREDIT:
            steps.extend([
                {"instrument": "dispute_case", "path": "/dispute-cases", "payload": {
                    "run_id": run_id, "customer_id": customer_id, "transaction_id": transaction_id,
                    "reason_code": reason_code, "queue": "disputes", "amount": amount}},
                {"instrument": "provisional_credit", "path": "/provisional-credits", "payload": {
                    "run_id": run_id, "customer_id": customer_id, "transaction_id": transaction_id,
                    "amount": amount or 0.0, "governing_clause": recommendation.governing_clause,
                    "deadline": recommendation.deadline}},
                {"instrument": "customer_notice", "path": "/notices", "payload": {
                    "run_id": run_id, "customer_id": customer_id,
                    "subject": "Provisional credit applied to your disputed transaction",
                    "body": f"{recommendation.headline}\n\n{recommendation.deadline}"}},
            ])
        elif recommendation.action is ActionType.GOODWILL_REFUND:
            steps.extend([
                {"instrument": "provisional_credit", "path": "/provisional-credits", "payload": {
                    "run_id": run_id, "customer_id": customer_id, "transaction_id": transaction_id,
                    "amount": amount or 0.0, "governing_clause": recommendation.governing_clause,
                    "deadline": recommendation.deadline}},
                {"instrument": "customer_notice", "path": "/notices", "payload": {
                    "run_id": run_id, "customer_id": customer_id,
                    "subject": "Goodwill credit applied", "body": recommendation.headline}},
            ])
        elif recommendation.action is ActionType.ROUTE_TO_FRAUD_OPS:
            steps.append({"instrument": "fraud_referral", "path": "/fraud-referrals", "payload": {
                "run_id": run_id, "customer_id": customer_id, "transaction_id": transaction_id,
                "reason_code": reason_code,
                "governing_clause": recommendation.governing_clause}})
        elif recommendation.action is ActionType.REQUEST_MERCHANT_CONTACT:
            steps.append({"instrument": "customer_notice", "path": "/notices", "payload": {
                "run_id": run_id, "customer_id": customer_id,
                "subject": "Please contact the merchant before we can proceed",
                "body": recommendation.headline}})
        return steps

    def plan_envelope(self, recommendation: Recommendation, state: dict[str, Any]) -> dict[str, Any]:
        steps = self.plan(recommendation, state)
        canonical = json.dumps({"version": ACTION_PLAN_VERSION, "steps": steps},
                               sort_keys=True, separators=(",", ":"), default=str)
        return {"version": ACTION_PLAN_VERSION, "steps": steps,
                "hash": hashlib.sha256(canonical.encode()).hexdigest()}

    def execute(self, recommendation: Recommendation, state: dict[str, Any]) -> list[dict[str, Any]]:
        results = []
        for step in self.plan(recommendation, state):
            attempts, status, body = 0, 0, {}
            while attempts < 2:
                attempts += 1
                try:
                    status, body = _post(step["path"], step["payload"])
                except httpx.RequestError as exc:
                    body = {"error": str(exc)}
                    if attempts < 2: continue
                if status not in (429, 502, 503, 504) or attempts >= 2: break
            reference = (body.get("credit_id") or body.get("cb_case_id")
                         or body.get("referral_id") or body.get("notice_id") or "")
            classification = ("idempotent_success" if status == 200 and body.get("idempotent")
                              else "success" if status == 200
                              else "retryable_failure" if status == 0 or status in (429, 502, 503, 504)
                              else "non_retryable_failure")
            results.append({"instrument": step["instrument"], "reference": reference,
                            "status_code": status, "idempotent": bool(body.get("idempotent")),
                            "classification": classification, "attempts": attempts, "detail": body})
            if status != 200:
                log.error("action_failed", instrument=step["instrument"], status=status, body=body)
                break
        return results

    def recovery_plan(self, recommendation: Recommendation, state: dict[str, Any],
                      results: list[dict[str, Any]]) -> dict[str, Any] | None:
        if not results or results[-1].get("status_code") == 200:
            return None
        completed = len([result for result in results if result.get("status_code") == 200])
        remaining = self.plan(recommendation, state)[completed:]
        canonical = json.dumps({"version": ACTION_PLAN_VERSION, "kind": "recovery",
                                "steps": remaining},
                               sort_keys=True, separators=(",", ":"), default=str)
        return {"version": ACTION_PLAN_VERSION, "steps": remaining,
                "hash": hashlib.sha256(canonical.encode()).hexdigest(),
                "requires_new_approval": True,
                "reason": results[-1].get("classification", "action_failure")}

service = BankingActionService()
