"""Concrete business domains installed in this deployment."""

from app.domains.banking_disputes.definition import domain as banking_disputes
from app.platform.domains.registry import get_domain, register_domain


def register_installed_domains() -> None:
    try:
        get_domain(banking_disputes.manifest.id)
    except KeyError:
        register_domain(banking_disputes)
