"""Structured output contracts for the reasoning pipeline (PRD 5.3).

Every LLM response that enters application logic is one of these models,
requested via LangChain's structured-output binding and validated before use.
There is no free-text path into the workflow.

Field descriptions are load-bearing: they are what the model actually sees when
the schema is bound, so they carry the instruction, not just the documentation.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field, field_validator

from app.schemas.grounding import SourceTier


class ReasonCode(str, Enum):
    UNAUTHORISED = "unauthorised"
    GOODS_NOT_RECEIVED = "goods_not_received"
    DUPLICATE_CHARGE = "duplicate_charge"
    INCORRECT_AMOUNT = "incorrect_amount"
    CANCELLED_RECURRING = "cancelled_recurring"
    QUALITY_DISPUTE = "quality_dispute"
    OTHER = "other"


class Intent(str, Enum):
    """US-1 opens a case; US-5 answers a question without opening one."""

    DISPUTE_INTAKE = "dispute_intake"
    POLICY_QUESTION = "policy_question"


class Attachment(BaseModel):
    """PRD 8.1 provision 4: carried from day one.

    Non-text attachments are accepted, stored and surfaced in the trace. They
    are not yet interpreted, and the recommendation must not pretend otherwise.
    """

    filename: str
    modality: str = "text"
    source_uri: str | None = None


class DisputeRequest(BaseModel):
    """What the agent submits from the UI."""

    text: str = Field(min_length=4, max_length=4000)
    transaction_id: str | None = None
    customer_id: str | None = None
    attachments: list[Attachment] = Field(default_factory=list)


class InformationResponse(BaseModel):
    transaction_id: str | None = Field(default=None, min_length=3, max_length=100)
    customer_id: str | None = Field(default=None, min_length=3, max_length=100)


class Triage(BaseModel):
    """Extraction output (FR-1). Entities are hints, never authority.

    Anything the model extracts here is re-read from the system of record before
    it is relied on - an LLM-parsed transaction id is a lookup key, not a fact.
    """

    intent: Intent = Field(description="dispute_intake if the user wants a case opened or a "
                                       "decision made; policy_question if they only want an answer")
    transaction_id: str | None = Field(default=None, description="Transaction id if stated, e.g. TXN-9001")
    customer_id: str | None = Field(default=None, description="Customer id if stated, e.g. CUST-1001")
    merchant_hint: str | None = Field(default=None, description="Merchant name if stated")
    amount: float | None = Field(default=None, description="Disputed amount if stated")
    reason_code: ReasonCode = Field(description="Closest matching dispute reason")
    summary: str = Field(max_length=400, description="One sentence restating the request")
    retrieval_query: str = Field(
        max_length=300,
        description="A focused query for policy retrieval. State the substantive question, "
                    "not the customer's narrative.",
    )


class Conflict(BaseModel):
    """One detected contradiction (FR-3, FR-16).

    `is_true_conflict` exists because C2 is the case where two clauses appear to
    disagree but govern different instruments. Collapsing that into "conflict"
    would make the copilot confidently wrong in exactly the way the product
    thesis says conventional RAG is.
    """

    description: str = Field(max_length=600, description="What the sources disagree about")
    governing_clause: str = Field(description="Clause id that governs, e.g. PCT-7.1")
    governing_tier: SourceTier = Field(description="Precedence tier of the governing clause")
    superseded_clauses: list[str] = Field(
        default_factory=list, description="Clause ids that do NOT govern here")
    is_true_conflict: bool = Field(
        description="False when the clauses govern different instruments or scopes and only "
                    "appear to disagree")
    resolution_basis: str = Field(
        max_length=600,
        description="Why the governing clause wins: which precedence rule applied, or why the "
                    "conflict is only apparent",
    )


class Reconciliation(BaseModel):
    """`reconcile` output. Empty conflicts is a valid, meaningful answer."""

    conflicts: list[Conflict] = Field(default_factory=list)
    notes: str = Field(default="", max_length=800,
                       description="Anything material the conflicts list does not capture")


class InvestigationToolCall(BaseModel):
    tool: str = Field(description="Exact id of one available read-only tool")
    arguments: dict = Field(default_factory=dict)
    reason: str = Field(
        max_length=300,
        description="A concise reason this evidence is needed; maximum 300 characters",
    )

    @field_validator("reason", mode="before")
    @classmethod
    def _bound_reason(cls, value: object) -> object:
        # This text is audit commentary, not a control or decision field. Local
        # models commonly exceed prose limits because maxLength is intentionally
        # removed from the provider grammar for Ollama/llama.cpp compatibility.
        return value[:300] if isinstance(value, str) else value


class InvestigationPlan(BaseModel):
    ready: bool = Field(description="True only when no additional evidence is needed")
    calls: list[InvestigationToolCall] = Field(default_factory=list, max_length=4)
    rationale: str = Field(
        max_length=500,
        description="Concise explanation of the plan; maximum 500 characters",
    )

    @field_validator("rationale", mode="before")
    @classmethod
    def _bound_rationale(cls, value: object) -> object:
        return value[:500] if isinstance(value, str) else value


class ActionType(str, Enum):
    PROVISIONAL_CREDIT = "provisional_credit"
    GOODWILL_REFUND = "goodwill_refund"
    ROUTE_TO_FRAUD_OPS = "route_to_fraud_ops"
    REQUEST_MERCHANT_CONTACT = "request_merchant_contact"
    DECLINE = "decline"
    ANSWER_ONLY = "answer_only"


class Recommendation(BaseModel):
    """FR-4 and FR-5. At least one citation is enforced, not requested."""

    action: ActionType
    headline: str = Field(max_length=200, description="The recommendation in one line")
    rationale: str = Field(max_length=2000, description="Why, referencing clause ids inline")
    citations: list[str] = Field(
        min_length=1,
        description="Clause ids and record refs this rests on, e.g. ['PCT-7.1', 'REC:TXN-9002']",
    )
    governing_clause: str = Field(
        description="The single clause that AUTHORISES OR REQUIRES the action you are "
                    "recommending in the `action` field. It must be the clause a reviewer "
                    "would cite to justify that specific action - not merely the "
                    "highest-ranked clause you retrieved, and not a clause about a "
                    "different instrument or a different question.",
    )
    deadline: str = Field(
        max_length=200,
        description="The applicable deadline, stated concretely with its clause, e.g. "
                    "'2 business days from notice (PCT-7.1)'. Where you are recommending an "
                    "action, this is the deadline governing that action. Where you are only "
                    "answering a question, it is the deadline the answer establishes - a "
                    "question about a filing window is answered by stating that window here. "
                    "Use 'none applicable' only when no deadline features in the answer at all.",
    )
    amount: float | None = Field(default=None, description="Monetary amount if the action has one")
    requires_approval: bool = Field(
        description="True for any action moving money or opening a case")
    confidence: float = Field(ge=0.0, le=1.0,
                              description="0-1. Lower it when evidence is thin or conflicting.")
    caveats: str = Field(default="", max_length=800,
                         description="What a reviewer should check before approving")

    @field_validator("citations")
    @classmethod
    def _no_blank_citations(cls, v: list[str]) -> list[str]:
        cleaned = [c.strip() for c in v if c and c.strip()]
        if not cleaned:
            raise ValueError(
                "at least one citation is required (FR-5); a recommendation without a "
                "governing clause is not a recommendation"
            )
        return cleaned


class ApproverRole(str, Enum):
    """Authority levels from BDP-3.4.

    This is a POLICY check, not authentication. PRD section 8 excludes auth and
    RBAC; the operator asserts their own role and nothing verifies it. It exists
    because the corpus mandates an authority limit and the audit trail has to
    record who claimed to approve - not because anyone is being authenticated.
    """

    AGENT = "agent"
    TEAM_LEAD = "team_lead"


class ApprovalRequest(BaseModel):
    approver: str = Field(min_length=2, max_length=120)
    approver_role: ApproverRole = ApproverRole.AGENT
    note: str = Field(default="", max_length=600)
    plan_hash: str = Field(
        min_length=64, max_length=64,
        description="SHA-256 of the exact action plan displayed to the approver",
    )


class RejectionRequest(BaseModel):
    approver: str = Field(min_length=2, max_length=120)
    reason: str = Field(
        min_length=3, max_length=600,
        description="Why the recommendation was rejected. Recorded even though "
                    "nothing executes (FR-8).",
    )


class Decision(str, Enum):
    APPROVED = "approved"
    REJECTED = "rejected"


class ActionResult(BaseModel):
    """One call against the mock core-banking API."""

    instrument: str
    reference: str
    status_code: int
    detail: dict = Field(default_factory=dict)
