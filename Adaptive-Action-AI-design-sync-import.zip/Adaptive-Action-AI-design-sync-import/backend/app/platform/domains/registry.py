"""Validated in-process registry for trusted, statically installed domains."""

from __future__ import annotations

from app.platform.domains.contracts import DomainDefinition, DomainManifest

_domains: dict[str, DomainDefinition] = {}


def register_domain(domain: DomainDefinition) -> None:
    manifest = DomainManifest.model_validate(domain.manifest)
    if manifest.id in _domains:
        raise ValueError(f"domain '{manifest.id}' is already registered")
    workflow_ids = [workflow.id for workflow in manifest.workflows]
    if len(workflow_ids) != len(set(workflow_ids)):
        raise ValueError(f"domain '{manifest.id}' has duplicate workflow ids")
    _domains[manifest.id] = domain


def get_domain(domain_id: str) -> DomainDefinition:
    try:
        return _domains[domain_id]
    except KeyError as exc:
        raise KeyError(f"unknown domain '{domain_id}'") from exc


def list_domains() -> list[DomainManifest]:
    return [domain.manifest for domain in _domains.values()]


def clear_domains() -> None:
    """Test hook; production registration occurs once during application boot."""
    _domains.clear()
