"""Domain discovery and contracts."""

from app.platform.domains.registry import get_domain, list_domains, register_domain

__all__ = ["get_domain", "list_domains", "register_domain"]
