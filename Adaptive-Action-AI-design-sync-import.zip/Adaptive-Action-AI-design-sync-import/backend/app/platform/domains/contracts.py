"""Stable contracts between the platform and independently owned domains.

Platform modules may depend on this file. Concrete domains implement these
contracts and may depend on the rest of the platform; the dependency never
runs in the opposite direction.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, Field


class NavigationItem(BaseModel):
    id: str
    label: str
    path: str
    capability: str | None = None


class WorkflowManifest(BaseModel):
    id: str
    name: str
    description: str
    input_schema: str
    output_schema: str
    requires_approval: bool = False


class RetrievalTrigger(BaseModel):
    id: str
    field: str
    op: str = "truthy"
    value: Any = None
    query: str
    why: str = ""


class DomainManifest(BaseModel):
    id: str = Field(pattern=r"^[a-z][a-z0-9_-]*$")
    name: str
    version: str
    description: str
    capabilities: list[str]
    workflows: list[WorkflowManifest]
    navigation: list[NavigationItem] = Field(default_factory=list)
    terminology: dict[str, str] = Field(default_factory=dict)
    retrieval_triggers: list[RetrievalTrigger] = Field(default_factory=list)
    presentation: dict[str, Any] = Field(default_factory=dict)


class DecisionInput(BaseModel):
    decision: str
    actor: str
    actor_role: str | None = None
    note: str = ""
    reason: str | None = None
    plan_hash: str | None = None


@runtime_checkable
class WorkflowService(Protocol):
    """Runtime operations exposed by one domain workflow."""

    def start(self, payload: dict[str, Any]) -> dict[str, Any]: ...

    def get(self, run_id: str) -> dict[str, Any] | None: ...

    def decide(self, run_id: str, decision: DecisionInput) -> dict[str, Any]: ...

    def provide_input(self, run_id: str, payload: dict[str, Any]) -> dict[str, Any]: ...


@runtime_checkable
class DomainDefinition(Protocol):
    manifest: DomainManifest

    def workflow(self, workflow_id: str) -> WorkflowService: ...

    def tool_registry(self) -> Any: ...
    def action_service(self) -> Any: ...
