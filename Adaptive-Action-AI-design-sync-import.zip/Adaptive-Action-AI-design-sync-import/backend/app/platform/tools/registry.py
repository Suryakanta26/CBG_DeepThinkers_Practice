"""Validation and execution boundary for agent-selectable tools."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Literal

from pydantic import BaseModel


@dataclass(frozen=True)
class ToolSpec:
    id: str
    description: str
    mode: Literal["read", "write"]
    input_model: type[BaseModel]
    handler: Callable[[BaseModel], Any]

    def prompt_description(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "description": self.description,
            "mode": self.mode,
            "input_schema": self.input_model.model_json_schema(),
        }


class ToolRegistry:
    def __init__(self, domain_id: str, tools: list[ToolSpec]) -> None:
        self.domain_id = domain_id
        self._tools = {tool.id: tool for tool in tools}
        if len(self._tools) != len(tools):
            raise ValueError(f"domain '{domain_id}' registered duplicate tool ids")

    def descriptions(self, *, mode: Literal["read", "write"] = "read") -> list[dict[str, Any]]:
        return [tool.prompt_description() for tool in self._tools.values() if tool.mode == mode]

    def validate_arguments(self, tool_id: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """Validate without executing, for agent-plan review and repair."""
        try:
            tool = self._tools[tool_id]
        except KeyError as exc:
            raise KeyError(f"unknown tool '{tool_id}' for domain '{self.domain_id}'") from exc
        return tool.input_model.model_validate(arguments).model_dump(mode="json")

    def execute(self, tool_id: str, arguments: dict[str, Any], *, allow_write: bool = False) -> Any:
        try:
            tool = self._tools[tool_id]
        except KeyError as exc:
            raise KeyError(f"unknown tool '{tool_id}' for domain '{self.domain_id}'") from exc
        if tool.mode == "write" and not allow_write:
            raise PermissionError(f"write tool '{tool_id}' requires an approved execution plan")
        validated = tool.input_model.model_validate(arguments)
        return tool.handler(validated)
