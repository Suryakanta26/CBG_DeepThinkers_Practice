"""Domain-neutral application platform."""
