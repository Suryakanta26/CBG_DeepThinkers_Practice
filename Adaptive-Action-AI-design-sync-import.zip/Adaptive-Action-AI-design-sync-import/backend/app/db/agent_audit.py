"""Queryable audit records for bounded-agent decisions and effects."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from app.db.engine import connect, query_all


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def tool_call(run_id: str, entry: dict[str, Any]) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO agent_tool_calls (run_id,ts,tool,arguments,status,hits,error) "
            "VALUES (?,?,?,?,?,?,?)",
            (run_id, _now(), entry["tool"], json.dumps(entry.get("arguments", {}), default=str),
             entry["status"], int(entry.get("hits", 0)), entry.get("error")),
        )


def assessment(run_id: str, value: Any) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO evidence_assessments "
            "(run_id,ts,status,missing,evidence_count,policy_count) VALUES (?,?,?,?,?,?)",
            (run_id, _now(), value.status, json.dumps(value.missing),
             value.evidence_count, value.policy_count),
        )


def action_plan(run_id: str, plan: dict[str, Any]) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO action_plans "
            "(plan_hash,run_id,version,steps,created_at) VALUES (?,?,?,?,?)",
            (plan["hash"], run_id, plan["version"],
             json.dumps(plan["steps"], default=str), _now()),
        )


def approval(run_id: str, *, plan_hash: str | None, decision: str, approver: str,
             approver_role: str | None, decided_at: str) -> None:
    with connect() as conn:
        conn.execute(
            "INSERT INTO approval_bindings "
            "(run_id,plan_hash,decision,approver,approver_role,decided_at) VALUES (?,?,?,?,?,?)",
            (run_id, plan_hash, decision, approver, approver_role, decided_at),
        )


def executions(run_id: str, plan_hash: str | None, results: list[dict[str, Any]]) -> None:
    with connect() as conn:
        for result in results:
            conn.execute(
                "INSERT INTO action_executions "
                "(run_id,plan_hash,ts,instrument,reference,status_code,classification,attempts,detail) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (run_id, plan_hash, _now(), result["instrument"], result.get("reference"),
                 result["status_code"], result.get("classification", "unknown"),
                 result.get("attempts", 1), json.dumps(result.get("detail", {}), default=str)),
            )


def for_run(run_id: str) -> dict[str, list[dict[str, Any]]]:
    return {
        "tool_calls": query_all("SELECT * FROM agent_tool_calls WHERE run_id=? ORDER BY id", (run_id,)),
        "evidence_assessments": query_all(
            "SELECT * FROM evidence_assessments WHERE run_id=? ORDER BY id", (run_id,)),
        "action_plans": query_all("SELECT * FROM action_plans WHERE run_id=?", (run_id,)),
        "approvals": query_all("SELECT * FROM approval_bindings WHERE run_id=? ORDER BY id", (run_id,)),
        "executions": query_all("SELECT * FROM action_executions WHERE run_id=? ORDER BY id", (run_id,)),
    }
