"""Compatibility facade resolving actions through the domain contract."""
from __future__ import annotations
from typing import Any
from app.schemas.dispute import Recommendation

def _service():
    from app.platform.domains.registry import get_domain
    try:
        domain = get_domain("banking-disputes")
    except KeyError:
        from app.domains import register_installed_domains
        register_installed_domains()
        domain = get_domain("banking-disputes")
    return domain.action_service()

def plan(recommendation: Recommendation, state: dict[str, Any]) -> list[dict[str, Any]]:
    return _service().plan(recommendation, state)

def plan_envelope(recommendation: Recommendation, state: dict[str, Any]) -> dict[str, Any]:
    return _service().plan_envelope(recommendation, state)

def execute(recommendation: Recommendation, state: dict[str, Any]) -> list[dict[str, Any]]:
    return _service().execute(recommendation, state)

def recovery_plan(recommendation: Recommendation, state: dict[str, Any],
                  results: list[dict[str, Any]]) -> dict[str, Any] | None:
    return _service().recovery_plan(recommendation, state, results)
