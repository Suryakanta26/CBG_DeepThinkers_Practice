@echo off
TITLE Adaptive Knowledge-to-Action Copilot Launcher
cls
echo ======================================================================
echo           ADAPTIVE KNOWLEDGE-TO-ACTION COPILOT LAUNCHER              
echo ======================================================================
echo.

set "PY_CMD=python"
if exist "%~dp0venv\Scripts\python.exe" (
    set "PY_CMD=%~dp0venv\Scripts\python.exe"
    echo Using Virtual Environment Python: %~dp0venv\Scripts\python.exe
) else (
    echo Using System Python: python
)

echo.
echo [1/2] Launching FastAPI Backend Server (Port 8000)...
start "Copilot Backend API (Port 8000)" cmd /k "cd /d %~dp0 && "%PY_CMD%" -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload"

echo [2/2] Launching Vite React Frontend UI (Port 3000)...
start "Copilot Frontend UI (Port 3000)" cmd /k "cd /d %~dp0ui && npm run dev"

echo.
echo ======================================================================
echo Applications started in separate windows!
echo - Frontend UI Console: http://127.0.0.1:3000
echo - Backend REST API:    http://127.0.0.1:8000/docs
echo - A2A Agent Card:      http://127.0.0.1:8000/.well-known/agent-card.json
echo ======================================================================
echo.
