"""
MCP Ingestion Tools for Card Dispute Operations.
Exposes data acquisition endpoints conforming to MCP tool protocols.
"""

from typing import Dict, Any, List
from mcp_server.data_store import (
    get_transaction,
    get_customer,
    get_dispute_history,
    get_auth_log
)


def tool_get_transaction_facts(transaction_id: str) -> Dict[str, Any]:
    """Retrieve structured transaction facts and card metadata for a given transaction ID."""
    txn = get_transaction(transaction_id)
    if not txn:
        return {"error": f"Transaction '{transaction_id}' not found"}
    
    cust = get_customer(txn["cardholder_id"])
    auth = get_auth_log(transaction_id)
    
    return {
        "transaction": txn,
        "customer": cust,
        "auth_log": auth
    }


def tool_get_customer_verification(customer_id: str) -> Dict[str, Any]:
    """Retrieve identity verification status and KYC risk segment for a customer."""
    cust = get_customer(customer_id)
    if not cust:
        return {"error": f"Customer '{customer_id}' not found"}
    return cust


def tool_get_dispute_history(customer_id: str, transaction_id: str = "") -> Dict[str, Any]:
    """Retrieve historical dispute records for a customer and check for duplicate filings."""
    history = get_dispute_history(customer_id)
    duplicate_dispute = any(item.get("transaction_id") == transaction_id for item in history)
    
    return {
        "customer_id": customer_id,
        "previous_disputes_count": len(history),
        "dispute_history": history,
        "is_duplicate_for_transaction": duplicate_dispute
    }
