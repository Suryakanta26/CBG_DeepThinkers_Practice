"""
MCP Action Tools for Card Dispute Operations.
Exposes consequential action tools (e.g. creating mock dispute cases) with idempotency guarantees.
"""

from typing import Dict, Any
from mcp_server.data_store import create_dispute_case, get_transaction


def tool_create_mock_dispute_case(
    transaction_id: str,
    dispute_reason: str,
    amount: float,
    idempotency_key: str,
    authorized_by: str
) -> Dict[str, Any]:
    """
    Creates a mock dispute case in the bank core operational system.
    Guaranteed idempotent via idempotency_key.
    """
    txn = get_transaction(transaction_id)
    if not txn:
        return {"error": f"Cannot create dispute case: Transaction '{transaction_id}' not found"}
    
    case_record = create_dispute_case(
        tx_id=transaction_id,
        dispute_reason=dispute_reason,
        amount=amount,
        idempotency_key=idempotency_key,
        created_by=authorized_by
    )
    
    return {
        "success": True,
        "message": f"Mock Dispute Case {case_record['case_id']} successfully registered.",
        "case_record": case_record
    }
