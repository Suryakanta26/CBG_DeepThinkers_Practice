"""
Standalone Mock MCP (Model Context Protocol) Server.
Manages tool discovery, schema registration, and execution dispatch for ingestion and action tools.
"""

from typing import Dict, Any, List, Callable
from mcp_server.tools.ingestion_tools import (
    tool_get_transaction_facts,
    tool_get_customer_verification,
    tool_get_dispute_history
)
from mcp_server.tools.action_tools import tool_create_mock_dispute_case


class MCPServer:
    """Mock MCP Server managing tool registry and invocation dispatches."""

    def __init__(self):
        self._tools: Dict[str, Callable] = {}
        self._schemas: Dict[str, Dict[str, Any]] = {}
        self._register_default_tools()

    def _register_default_tools(self):
        self.register_tool(
            name="get_transaction_facts",
            func=tool_get_transaction_facts,
            description="Retrieve structured transaction facts, card details, and auth logs.",
            input_schema={
                "type": "object",
                "properties": {
                    "transaction_id": {"type": "string", "description": "Transaction ID e.g. TX-1001"}
                },
                "required": ["transaction_id"]
            }
        )
        self.register_tool(
            name="get_customer_verification",
            func=tool_get_customer_verification,
            description="Retrieve customer identity verification status and risk segment.",
            input_schema={
                "type": "object",
                "properties": {
                    "customer_id": {"type": "string", "description": "Customer ID e.g. CUST-8821"}
                },
                "required": ["customer_id"]
            }
        )
        self.register_tool(
            name="get_dispute_history",
            func=tool_get_dispute_history,
            description="Retrieve previous dispute records for customer and check for duplicate filings.",
            input_schema={
                "type": "object",
                "properties": {
                    "customer_id": {"type": "string", "description": "Customer ID e.g. CUST-8821"},
                    "transaction_id": {"type": "string", "description": "Optional transaction ID to check"}
                },
                "required": ["customer_id"]
            }
        )
        self.register_tool(
            name="create_mock_dispute_case",
            func=tool_create_mock_dispute_case,
            description="Create a mock dispute case in bank core systems with idempotency.",
            input_schema={
                "type": "object",
                "properties": {
                    "transaction_id": {"type": "string", "description": "Transaction ID e.g. TX-1001"},
                    "dispute_reason": {"type": "string", "description": "Dispute reason classification"},
                    "amount": {"type": "number", "description": "Disputed amount"},
                    "idempotency_key": {"type": "string", "description": "Idempotency key"},
                    "authorized_by": {"type": "string", "description": "Authorization source e.g. POLICY_AUTO_GATE or ANALYST"}
                },
                "required": ["transaction_id", "dispute_reason", "amount", "idempotency_key", "authorized_by"]
            }
        )

    def register_tool(self, name: str, func: Callable, description: str, input_schema: Dict[str, Any]):
        self._tools[name] = func
        self._schemas[name] = {
            "name": name,
            "description": description,
            "inputSchema": input_schema
        }

    def list_tools(self) -> List[Dict[str, Any]]:
        return list(self._schemas.values())

    def call_tool(self, name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        if name not in self._tools:
            return {"error": f"Tool '{name}' is not registered on this MCP server."}
        try:
            result = self._tools[name](**arguments)
            return {"status": "success", "result": result}
        except Exception as e:
            return {"status": "error", "error": str(e)}


# Global instance
mcp_server_instance = MCPServer()
