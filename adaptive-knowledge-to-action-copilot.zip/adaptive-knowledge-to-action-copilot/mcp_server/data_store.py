"""
Mock Enterprise Data Store for Card Dispute Operations.
Contains synthetic transactions, customer profiles, dispute histories, and authentication logs.
"""

from typing import Dict, Any, List, Optional
import datetime

SYNTHETIC_TRANSACTIONS: Dict[str, Dict[str, Any]] = {
    "TX-1001": {
        "transaction_id": "TX-1001",
        "cardholder_id": "CUST-8821",
        "card_last4": "4392",
        "merchant_name": "LUXURY_ELECTRONICS_ONLINE",
        "merchant_category": "5732 - Electronics Stores",
        "amount": 349.99,
        "currency": "USD",
        "timestamp": (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=14)).isoformat(),
        "transaction_age_days": 14,
        "channel": "E_COMMERCE",
        "pos_entry_mode": "01 - Keyed / Online",
        "billing_country": "US",
        "shipping_country": "US",
        "is_recurring": False,
        "status": "SETTLED"
    },
    "TX-1002": {
        "transaction_id": "TX-1002",
        "cardholder_id": "CUST-3104",
        "card_last4": "8812",
        "merchant_name": "GLOBAL_TRAVEL_RESERVATIONS",
        "merchant_category": "4722 - Travel Agencies",
        "amount": 1250.00,
        "currency": "USD",
        "timestamp": (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=22)).isoformat(),
        "transaction_age_days": 22,
        "channel": "E_COMMERCE",
        "pos_entry_mode": "01 - Keyed / Online",
        "billing_country": "US",
        "shipping_country": "UK",
        "is_recurring": False,
        "status": "SETTLED"
    },
    "TX-1003": {
        "transaction_id": "TX-1003",
        "cardholder_id": "CUST-9042",
        "card_last4": "1104",
        "merchant_name": "SUPERMARKET_EXPRESS_STORE",
        "merchant_category": "5411 - Grocery Stores",
        "amount": 89.40,
        "currency": "USD",
        "timestamp": (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=75)).isoformat(),
        "transaction_age_days": 75,
        "channel": "POS_CHIP",
        "pos_entry_mode": "05 - Chip / Contactless",
        "billing_country": "US",
        "shipping_country": "US",
        "is_recurring": False,
        "status": "SETTLED"
    },
    "TX-1004": {
        "transaction_id": "TX-1004",
        "cardholder_id": "CUST-5519",
        "card_last4": "9901",
        "merchant_name": "CLOUD_STREAMING_SERVICES",
        "merchant_category": "4899 - Cable, Pay TV",
        "amount": 29.99,
        "currency": "USD",
        "timestamp": (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=5)).isoformat(),
        "transaction_age_days": 5,
        "channel": "E_COMMERCE",
        "pos_entry_mode": "01 - Keyed / Online",
        "billing_country": "US",
        "shipping_country": "US",
        "is_recurring": True,
        "status": "SETTLED"
    },
    "ORD-5001": {
        "transaction_id": "ORD-5001",
        "cardholder_id": "CUST-RET-101",
        "card_last4": "SKU-AUDIO-44",
        "merchant_name": "WIRELESS_NOISE_CANCEL_HEADPHONES",
        "merchant_category": "Standard Inventory - Electronics",
        "amount": 149.99,
        "currency": "USD",
        "timestamp": (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=8)).isoformat(),
        "transaction_age_days": 8,
        "channel": "ONLINE_STORE",
        "pos_entry_mode": "Warehouse WH-CHICAGO-01",
        "billing_country": "US",
        "shipping_country": "US",
        "is_recurring": False,
        "status": "DELIVERED"
    },
    "ORD-5002": {
        "transaction_id": "ORD-5002",
        "cardholder_id": "CUST-RET-102",
        "card_last4": "SKU-LAPTOP-99",
        "merchant_name": "ULTRA_SLIM_GAMING_LAPTOP_15INCH",
        "merchant_category": "Premium Electronics",
        "amount": 899.00,
        "currency": "USD",
        "timestamp": (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=12)).isoformat(),
        "transaction_age_days": 12,
        "channel": "ONLINE_STORE",
        "pos_entry_mode": "Warehouse WH-SEATTLE-02",
        "billing_country": "US",
        "shipping_country": "US",
        "is_recurring": False,
        "status": "DELIVERED"
    },
    "ORD-5003": {
        "transaction_id": "ORD-5003",
        "cardholder_id": "CUST-RET-103",
        "card_last4": "SKU-SHOES-12",
        "merchant_name": "RUNNING_SHOES_PRO_SPORT",
        "merchant_category": "Standard Footwear",
        "amount": 120.00,
        "currency": "USD",
        "timestamp": (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=45)).isoformat(),
        "transaction_age_days": 45,
        "channel": "ONLINE_STORE",
        "pos_entry_mode": "Warehouse WH-DALLAS-01",
        "billing_country": "US",
        "shipping_country": "US",
        "is_recurring": False,
        "status": "DELIVERED"
    },
    "ORD-5004": {
        "transaction_id": "ORD-5004",
        "cardholder_id": "CUST-RET-104",
        "card_last4": "SKU-CLEAR-09",
        "merchant_name": "WINTER_PARKA_JACKET_CLEARANCE",
        "merchant_category": "FINAL_SALE_CLEARANCE",
        "amount": 75.00,
        "currency": "USD",
        "timestamp": (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=6)).isoformat(),
        "transaction_age_days": 6,
        "channel": "ONLINE_STORE",
        "pos_entry_mode": "Warehouse WH-NEWYORK-03",
        "billing_country": "US",
        "shipping_country": "US",
        "is_recurring": False,
        "status": "DELIVERED"
    }
}

SYNTHETIC_CUSTOMERS: Dict[str, Dict[str, Any]] = {
    "CUST-8821": {
        "customer_id": "CUST-8821",
        "full_name": "Alex Mercer",
        "identity_verification_status": "VERIFIED_2FA",
        "kyc_tier": "TIER_1_COMPLETE",
        "account_tenure_months": 48,
        "risk_segment": "LOW_RISK"
    },
    "CUST-3104": {
        "customer_id": "CUST-3104",
        "full_name": "Jordan Hayes",
        "identity_verification_status": "VERIFIED_OTP",
        "kyc_tier": "TIER_1_COMPLETE",
        "account_tenure_months": 18,
        "risk_segment": "MEDIUM_RISK"
    },
    "CUST-9042": {
        "customer_id": "CUST-9042",
        "full_name": "Taylor Morgan",
        "identity_verification_status": "VERIFIED_PASSCODE",
        "kyc_tier": "TIER_1_COMPLETE",
        "account_tenure_months": 36,
        "risk_segment": "LOW_RISK"
    },
    "CUST-5519": {
        "customer_id": "CUST-5519",
        "full_name": "Sam Rivera",
        "identity_verification_status": "VERIFIED_2FA",
        "kyc_tier": "TIER_1_COMPLETE",
        "account_tenure_months": 12,
        "risk_segment": "LOW_RISK"
    },
    "CUST-RET-101": {
        "customer_id": "CUST-RET-101",
        "full_name": "Elena Rostova",
        "identity_verification_status": "VERIFIED_ACCOUNT",
        "kyc_tier": "VIP_PLATINUM_TIER",
        "account_tenure_months": 24,
        "risk_segment": "LOW_RETURN_RATE"
    },
    "CUST-RET-102": {
        "customer_id": "CUST-RET-102",
        "full_name": "Marcus Vance",
        "identity_verification_status": "VERIFIED_ACCOUNT",
        "kyc_tier": "STANDARD_TIER",
        "account_tenure_months": 8,
        "risk_segment": "LOW_RETURN_RATE"
    },
    "CUST-RET-103": {
        "customer_id": "CUST-RET-103",
        "full_name": "Chloe Bennett",
        "identity_verification_status": "VERIFIED_ACCOUNT",
        "kyc_tier": "STANDARD_TIER",
        "account_tenure_months": 14,
        "risk_segment": "LOW_RETURN_RATE"
    },
    "CUST-RET-104": {
        "customer_id": "CUST-RET-104",
        "full_name": "David Kim",
        "identity_verification_status": "VERIFIED_ACCOUNT",
        "kyc_tier": "STANDARD_TIER",
        "account_tenure_months": 6,
        "risk_segment": "LOW_RETURN_RATE"
    }
}

SYNTHETIC_DISPUTE_HISTORIES: Dict[str, List[Dict[str, Any]]] = {
    "CUST-8821": [],
    "CUST-3104": [
        {
            "dispute_id": "DISP-2025-0091",
            "transaction_id": "TX-0988",
            "amount": 420.00,
            "merchant_name": "DIGITAL_GAMES_INC",
            "filed_date": "2025-11-10",
            "outcome": "RESOLVED_MERCHANT_CREDIT",
            "status": "CLOSED"
        }
    ],
    "CUST-9042": [],
    "CUST-5519": []
}

SYNTHETIC_AUTHENTICATION_LOGS: Dict[str, Dict[str, Any]] = {
    "TX-1001": {
        "3ds_auth_status": "NOT_ATTEMPTED",
        "avs_match": "MATCH_ZIP_AND_ADDRESS",
        "cvv_match": "MATCH",
        "ip_geolocation": "New York, US",
        "device_fingerprint": "DEV-UNKNOWN-881",
        "conflicting_evidence_signals": []
    },
    "TX-1002": {
        "3ds_auth_status": "SUCCESS_OTP",
        "avs_match": "MATCH_ZIP_ONLY",
        "cvv_match": "MATCH",
        "ip_geolocation": "London, UK",
        "device_fingerprint": "DEV-KNOWN-310",
        "conflicting_evidence_signals": [
            "Cardholder OTP authentication recorded at 2026-07-28T14:22:00Z from registered mobile device DEV-KNOWN-310",
            "IP Address matches cardholder known travel location log"
        ]
    },
    "TX-1003": {
        "3ds_auth_status": "POS_EMV_CHIP",
        "avs_match": "NOT_APPLICABLE",
        "cvv_match": "NOT_APPLICABLE",
        "ip_geolocation": "Chicago, US",
        "device_fingerprint": "POS-TERMINAL-9941",
        "conflicting_evidence_signals": [
            "Physical Chip card insert validated with PIN verification at POS Terminal 9941"
        ]
    },
    "TX-1004": {
        "3ds_auth_status": "RECURRING_TOKEN",
        "avs_match": "MATCH",
        "cvv_match": "MATCH",
        "ip_geolocation": "Seattle, US",
        "device_fingerprint": "DEV-KNOWN-551",
        "conflicting_evidence_signals": []
    }
}

# In-memory store for created mock dispute cases
CREATED_DISPUTE_CASES: Dict[str, Dict[str, Any]] = {}


def get_transaction(tx_id: str) -> Optional[Dict[str, Any]]:
    return SYNTHETIC_TRANSACTIONS.get(tx_id)


def get_customer(cust_id: str) -> Optional[Dict[str, Any]]:
    return SYNTHETIC_CUSTOMERS.get(cust_id)


def get_dispute_history(cust_id: str) -> List[Dict[str, Any]]:
    return SYNTHETIC_DISPUTE_HISTORIES.get(cust_id, [])


def get_auth_log(tx_id: str) -> Optional[Dict[str, Any]]:
    return SYNTHETIC_AUTHENTICATION_LOGS.get(tx_id)


def create_dispute_case(tx_id: str, dispute_reason: str, amount: float, idempotency_key: str, created_by: str) -> Dict[str, Any]:
    if idempotency_key in CREATED_DISPUTE_CASES:
        return CREATED_DISPUTE_CASES[idempotency_key]
    
    case_id = f"CASE-DISP-{len(CREATED_DISPUTE_CASES) + 5001}"
    now_str = datetime.datetime.now(datetime.timezone.utc).isoformat()
    
    case_record = {
        "case_id": case_id,
        "transaction_id": tx_id,
        "dispute_reason": dispute_reason,
        "disputed_amount": amount,
        "idempotency_key": idempotency_key,
        "created_by": created_by,
        "created_at": now_str,
        "status": "OPEN_INVESTIGATION",
        "stage": "CHARGEBACK_INITIATED",
        "provisional_credit_issued": True if amount <= 500.0 else False
    }
    
    CREATED_DISPUTE_CASES[idempotency_key] = case_record
    return case_record
