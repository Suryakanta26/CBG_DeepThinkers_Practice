import React, { useState, useEffect, useRef } from 'react';
import { 
  Share2, Filter, ZoomIn, ZoomOut, RotateCcw, 
  Info, Shield, CheckSquare, FileText, Zap, Layers, Sparkles
} from 'lucide-react';

interface Node {
  id: string;
  label: string;
  properties: Record<string, any>;
  x?: number;
  y?: number;
}

interface Edge {
  source: string;
  target: string;
  type: string;
}

interface KnowledgeGraphViewerProps {
  graphData: {
    nodes?: Node[];
    edges?: Edge[];
  } | null;
}

const LABEL_THEMES: Record<string, { bg: string; border: string; text: string; glow: string; badge: string }> = {
  DisputeCategory: {
    bg: '#082f49',
    border: '#06b6d4',
    text: '#38bdf8',
    glow: 'rgba(6, 182, 212, 0.4)',
    badge: 'Dispute Category'
  },
  PolicySection: {
    bg: '#3b0764',
    border: '#a855f7',
    text: '#c084fc',
    glow: 'rgba(168, 85, 247, 0.4)',
    badge: 'Policy Section'
  },
  RuleCondition: {
    bg: '#022c22',
    border: '#10b981',
    text: '#34d399',
    glow: 'rgba(16, 185, 129, 0.4)',
    badge: 'Rule Condition'
  },
  ActionAuthority: {
    bg: '#451a03',
    border: '#f59e0b',
    text: '#fbbf24',
    glow: 'rgba(245, 158, 11, 0.4)',
    badge: 'Action Authority'
  },
  Entity: {
    bg: '#0f172a',
    border: '#64748b',
    text: '#94a3b8',
    glow: 'rgba(100, 116, 139, 0.4)',
    badge: 'Entity'
  }
};

export const KnowledgeGraphViewer: React.FC<KnowledgeGraphViewerProps> = ({ graphData }) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>('UNRECOGNIZED_CARD_TRANSACTION');
  const [filterLabel, setFilterLabel] = useState<string>('ALL');
  const [cypherQuery, setCypherQuery] = useState<string>(
    'MATCH (c:DisputeCategory)-[:REGULATES]->(p:PolicySection)-[:REQUIRES_CHECK]->(r:RuleCondition) RETURN p, r'
  );
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [draggedNode, setDraggedNode] = useState<string | null>(null);
  const [positions, setPositions] = useState<Record<string, { x: number; y: number }>>({});
  
  const svgRef = useRef<SVGSVGElement | null>(null);

  // Compute clean structured 4-column layout
  useEffect(() => {
    if (!graphData?.nodes) return;

    const newPositions: Record<string, { x: number; y: number }> = {};
    const nodesByLabel: Record<string, Node[]> = {
      DisputeCategory: [],
      PolicySection: [],
      RuleCondition: [],
      ActionAuthority: [],
      Other: []
    };

    graphData.nodes.forEach(node => {
      const lbl = node.label || 'Other';
      if (nodesByLabel[lbl]) {
        nodesByLabel[lbl].push(node);
      } else {
        nodesByLabel.Other.push(node);
      }
    });

    // Column 1: Dispute Category (Intake Root)
    nodesByLabel.DisputeCategory.forEach((n, idx) => {
      newPositions[n.id] = { x: 130, y: 340 + idx * 120 };
    });

    // Column 2: Policy Sections (Manual Clauses)
    nodesByLabel.PolicySection.forEach((n, idx) => {
      newPositions[n.id] = { x: 460, y: 80 + idx * 96 };
    });

    // Column 3: Deterministic Rule Conditions
    nodesByLabel.RuleCondition.forEach((n, idx) => {
      newPositions[n.id] = { x: 830, y: 80 + idx * 96 };
    });

    // Column 4: Action Authority (Mock Case Creation)
    nodesByLabel.ActionAuthority.forEach((n, idx) => {
      newPositions[n.id] = { x: 1150, y: 368 + idx * 120 };
    });

    // Fallback for any other entities
    nodesByLabel.Other.forEach((n, idx) => {
      newPositions[n.id] = { x: 600, y: 100 + idx * 80 };
    });

    setPositions(newPositions);
  }, [graphData]);

  if (!graphData || !graphData.nodes || graphData.nodes.length === 0) {
    return (
      <div className="glass-card text-center p-8 text-gray-400">
        <Share2 size={32} className="mx-auto mb-2 opacity-50" />
        <p>No graph triples loaded in LadybugDB yet.</p>
      </div>
    );
  }

  const nodes = graphData.nodes.filter(n => filterLabel === 'ALL' || n.label === filterLabel);
  const visibleNodeIds = new Set(nodes.map(n => n.id));
  const edges = (graphData.edges || []).filter(e => visibleNodeIds.has(e.source) && visibleNodeIds.has(e.target));

  const selectedNode = graphData.nodes.find(n => n.id === selectedNodeId);
  const connectedEdges = (graphData.edges || []).filter(
    e => e.source === selectedNodeId || e.target === selectedNodeId
  );

  const handleMouseDown = (nodeId: string) => {
    setDraggedNode(nodeId);
    setSelectedNodeId(nodeId);
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!draggedNode || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left - panOffset.x) / zoomLevel;
    const y = (e.clientY - rect.top - panOffset.y) / zoomLevel;
    setPositions(prev => ({
      ...prev,
      [draggedNode]: { x: Math.max(80, Math.min(1240, x)), y: Math.max(40, Math.min(660, y)) }
    }));
  };

  const handleMouseUp = () => {
    setDraggedNode(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="glass-card">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <Share2 size={20} className="text-purple-400" />
              <h2 className="text-base font-bold text-white">LadybugDB Embedded Property Graph Viewer</h2>
              <span className="badge badge-info text-[10px]">14 Nodes • 13 Edges</span>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              Multi-hop Cypher Property Graph stored locally in <span className="font-mono text-cyan-400">local_ladybug.lbug</span> (Daemonless Embedded Graph Store)
            </p>
          </div>

          {/* Quick Filter Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-gray-400 flex items-center gap-1 font-semibold">
              <Filter size={13} /> Filter:
            </span>
            {['ALL', 'DisputeCategory', 'PolicySection', 'RuleCondition', 'ActionAuthority'].map(lbl => (
              <button
                key={lbl}
                onClick={() => setFilterLabel(lbl)}
                className={`text-xs px-3 py-1 rounded-full border transition-all cursor-pointer ${
                  filterLabel === lbl
                    ? 'bg-blue-600 border-blue-400 text-white font-bold shadow-[0_0_12px_rgba(59,130,246,0.5)]'
                    : 'bg-slate-900 border-slate-700 text-gray-300 hover:text-white hover:border-slate-500'
                }`}
              >
                {lbl}
              </button>
            ))}
          </div>
        </div>

        {/* Live Cypher Command Bar */}
        <div className="flex items-center gap-3 p-2.5 bg-slate-950 rounded-xl border border-slate-800">
          <div className="flex items-center gap-1 text-xs font-bold text-cyan-400 px-2 font-mono shrink-0">
            <Sparkles size={14} />
            <span>CYPHER:</span>
          </div>
          <input
            type="text"
            value={cypherQuery}
            onChange={(e) => setCypherQuery(e.target.value)}
            className="w-full bg-transparent text-xs font-mono text-cyan-200 focus:outline-none"
          />
          <button 
            onClick={() => setFilterLabel('ALL')} 
            className="btn btn-secondary text-xs py-1.5 px-4 shrink-0"
          >
            Execute Query
          </button>
        </div>
      </div>

      {/* Main Graph Grid: 75% Canvas, 25% Node Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* Visual SVG Canvas (3 Cols) */}
        <div className="lg:col-span-3 glass-card p-0 relative overflow-hidden rounded-xl border border-slate-800 shadow-2xl">
          {/* Zoom Toolbar */}
          <div className="absolute top-4 right-4 z-10 flex items-center gap-1 bg-slate-900/95 border border-slate-700 rounded-lg p-1.5 shadow-xl backdrop-blur">
            <button
              onClick={() => setZoomLevel(prev => Math.min(1.8, prev + 0.15))}
              className="p-1.5 text-gray-300 hover:text-white hover:bg-slate-800 rounded transition"
              title="Zoom In"
            >
              <ZoomIn size={16} />
            </button>
            <button
              onClick={() => setZoomLevel(prev => Math.max(0.6, prev - 0.15))}
              className="p-1.5 text-gray-300 hover:text-white hover:bg-slate-800 rounded transition"
              title="Zoom Out"
            >
              <ZoomOut size={16} />
            </button>
            <button
              onClick={() => { setZoomLevel(1); setPanOffset({ x: 0, y: 0 }); }}
              className="p-1.5 text-gray-300 hover:text-white hover:bg-slate-800 rounded transition"
              title="Reset View"
            >
              <RotateCcw size={16} />
            </button>
            <span className="text-[11px] text-cyan-400 font-mono px-2 font-bold">{Math.round(zoomLevel * 100)}%</span>
          </div>

          {/* Interactive Graph Legend */}
          <div className="absolute bottom-4 left-4 z-10 flex items-center gap-4 bg-slate-950/90 border border-slate-800 rounded-xl px-4 py-2 text-xs backdrop-blur shadow-lg">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-cyan-400 inline-block shadow-[0_0_8px_#06b6d4]"></span>
              <span className="text-gray-300 font-medium">DisputeCategory</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-purple-400 inline-block shadow-[0_0_8px_#a855f7]"></span>
              <span className="text-gray-300 font-medium">PolicySection</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-emerald-400 inline-block shadow-[0_0_8px_#10b981]"></span>
              <span className="text-gray-300 font-medium">RuleCondition</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-amber-400 inline-block shadow-[0_0_8px_#f59e0b]"></span>
              <span className="text-gray-300 font-medium">ActionAuthority</span>
            </div>
          </div>

          {/* SVG Canvas */}
          <svg
            ref={svgRef}
            viewBox="0 0 1280 680"
            className="w-full h-[640px] bg-[#030712] cursor-grab active:cursor-grabbing select-none"
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
          >
            <defs>
              <marker id="arrow-default" viewBox="0 0 10 10" refX="24" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="#475569" />
              </marker>
              <marker id="arrow-active" viewBox="0 0 10 10" refX="24" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="#38bdf8" />
              </marker>
              <filter id="node-glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="6" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
            </defs>

            <g transform={`translate(${panOffset.x}, ${panOffset.y}) scale(${zoomLevel})`}>
              {/* Directed Edges with Bezier Curves and Relationship Badges */}
              {edges.map((edge, idx) => {
                const sourcePos = positions[edge.source];
                const targetPos = positions[edge.target];
                if (!sourcePos || !targetPos) return null;

                const isConnected = selectedNodeId && (edge.source === selectedNodeId || edge.target === selectedNodeId);
                const midX = (sourcePos.x + targetPos.x) / 2;
                const midY = (sourcePos.y + targetPos.y) / 2;

                const dx = targetPos.x - sourcePos.x;
                const pathData = `M ${sourcePos.x} ${sourcePos.y} C ${sourcePos.x + dx * 0.45} ${sourcePos.y}, ${targetPos.x - dx * 0.45} ${targetPos.y}, ${targetPos.x} ${targetPos.y}`;

                return (
                  <g key={`${edge.source}-${edge.target}-${idx}`}>
                    <path
                      d={pathData}
                      fill="none"
                      stroke={isConnected ? '#38bdf8' : '#334155'}
                      strokeWidth={isConnected ? 3 : 1.8}
                      strokeDasharray={isConnected ? 'none' : '4 3'}
                      markerEnd={isConnected ? 'url(#arrow-active)' : 'url(#arrow-default)'}
                      className="transition-all duration-300"
                    />
                    {/* Relationship Badge in Center of Edge */}
                    <g transform={`translate(${midX}, ${midY})`}>
                      <rect
                        x="-46"
                        y="-10"
                        width="92"
                        height="20"
                        rx="10"
                        fill="#020617"
                        stroke={isConnected ? '#38bdf8' : '#334155'}
                        strokeWidth="1.2"
                      />
                      <text
                        x="0"
                        y="4"
                        textAnchor="middle"
                        fill={isConnected ? '#38bdf8' : '#94a3b8'}
                        fontSize="9"
                        fontWeight="700"
                        fontFamily="monospace"
                        letterSpacing="0.05em"
                      >
                        {edge.type}
                      </text>
                    </g>
                  </g>
                );
              })}

              {/* Visual Nodes */}
              {nodes.map(node => {
                const pos = positions[node.id] || { x: 600, y: 300 };
                const isSelected = selectedNodeId === node.id;
                const isConnectedToSelected = (graphData.edges || []).some(
                  e => (e.source === selectedNodeId && e.target === node.id) ||
                       (e.target === selectedNodeId && e.source === node.id)
                );
                const theme = LABEL_THEMES[node.label] || LABEL_THEMES.Entity;

                const nodeWidth = 190;
                const nodeHeight = 52;

                return (
                  <g
                    key={node.id}
                    transform={`translate(${pos.x}, ${pos.y})`}
                    onMouseDown={() => handleMouseDown(node.id)}
                    className="cursor-pointer group"
                  >
                    {/* Glowing Selection Halo */}
                    {isSelected && (
                      <rect
                        x={-nodeWidth / 2 - 8}
                        y={-nodeHeight / 2 - 8}
                        width={nodeWidth + 16}
                        height={nodeHeight + 16}
                        rx="18"
                        fill="none"
                        stroke={theme.border}
                        strokeWidth="2.5"
                        strokeDasharray="6 3"
                        className="animate-pulse"
                      />
                    )}

                    {/* Main Capsule Node Card */}
                    <rect
                      x={-nodeWidth / 2}
                      y={-nodeHeight / 2}
                      width={nodeWidth}
                      height={nodeHeight}
                      rx="14"
                      fill={theme.bg}
                      stroke={isSelected ? '#ffffff' : isConnectedToSelected ? theme.border : theme.border}
                      strokeWidth={isSelected ? 2.5 : 1.5}
                      filter={isSelected ? `drop-shadow(0 0 16px ${theme.glow})` : `drop-shadow(0 0 8px ${theme.glow})`}
                      className="transition-all duration-200"
                    />

                    {/* Node Category Badge */}
                    <rect
                      x={-nodeWidth / 2 + 10}
                      y={-nodeHeight / 2 + 7}
                      width="100"
                      height="15"
                      rx="7.5"
                      fill="#030712"
                      stroke={theme.border}
                      strokeWidth="1"
                    />
                    <text
                      x={-nodeWidth / 2 + 60}
                      y={-nodeHeight / 2 + 18}
                      textAnchor="middle"
                      fill={theme.text}
                      fontSize="8"
                      fontWeight="800"
                      fontFamily="sans-serif"
                      letterSpacing="0.06em"
                    >
                      {theme.badge.toUpperCase()}
                    </text>

                    {/* Node ID Title */}
                    <text
                      x={-nodeWidth / 2 + 12}
                      y={nodeHeight / 2 - 12}
                      fill="#ffffff"
                      fontSize="11"
                      fontWeight="700"
                      fontFamily="monospace"
                    >
                      {node.id.length > 20 ? node.id.substring(0, 19) + '…' : node.id}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>
        </div>

        {/* Node Property Inspector Side Drawer (1 Col) */}
        <div className="glass-card p-5 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
            <Info size={18} className="text-cyan-400" />
            <h3 className="text-sm font-bold text-white">LadybugDB Node Inspector</h3>
          </div>

          {selectedNode ? (
            <div className="space-y-4 text-xs">
              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div>
                  <span className="text-gray-400 block text-[11px]">Node Identifier:</span>
                  <span className="font-mono font-bold text-cyan-300 text-sm">{selectedNode.id}</span>
                </div>
                <div>
                  <span className="text-gray-400 block text-[11px]">Cypher Label:</span>
                  <span className="badge badge-info text-[10px] mt-1">{selectedNode.label}</span>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-gray-300 mb-1.5 flex items-center gap-1.5">
                  <FileText size={14} className="text-purple-400" />
                  <span>Node Properties & Metadata</span>
                </h4>
                <pre className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-emerald-300 overflow-x-auto">
                  {JSON.stringify(selectedNode.properties, null, 2)}
                </pre>
              </div>

              <div>
                <h4 className="font-semibold text-gray-300 mb-1.5 flex items-center gap-1.5">
                  <Share2 size={14} className="text-cyan-400" />
                  <span>Connected Relationships ({connectedEdges.length})</span>
                </h4>
                <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                  {connectedEdges.length === 0 ? (
                    <p className="text-gray-500 italic text-[11px]">No direct relationships.</p>
                  ) : (
                    connectedEdges.map((e, idx) => (
                      <div key={idx} className="p-2.5 bg-slate-950 border border-slate-800 rounded-lg text-[11px] font-mono">
                        <div className="text-cyan-400 font-bold flex items-center gap-1">
                          <Zap size={11} />
                          <span>{e.type}</span>
                        </div>
                        <div className="text-gray-400 mt-1 flex items-center justify-between text-[10px]">
                          <span>{e.source === selectedNode.id ? 'Target:' : 'Source:'}</span>
                          <span className="text-white font-semibold">{e.source === selectedNode.id ? e.target : e.source}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-16 text-gray-500 text-xs">
              <Share2 size={28} className="mx-auto mb-2 opacity-40" />
              <p>Click any node in the graph above to inspect its Cypher attributes and relationships.</p>
            </div>
          )}

          <div className="pt-3 border-t border-slate-800 text-[11px] text-gray-400 flex items-center justify-between">
            <span>Graph Nodes: <strong className="text-white">{graphData.nodes?.length || 0}</strong></span>
            <span>Graph Edges: <strong className="text-white">{graphData.edges?.length || 0}</strong></span>
          </div>
        </div>
      </div>
    </div>
  );
};
