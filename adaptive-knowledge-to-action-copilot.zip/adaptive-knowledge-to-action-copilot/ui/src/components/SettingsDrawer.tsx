import React, { useState } from 'react';
import { X, Save, ShieldAlert, Lock } from 'lucide-react';

interface SettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentSettings: any;
  onSave: (settings: any) => void;
}

export const SettingsDrawer: React.FC<SettingsDrawerProps> = ({
  isOpen,
  onClose,
  currentSettings,
  onSave
}) => {
  const [model, setModel] = useState(currentSettings?.primary_model || 'gemini-3.1-flash-lite');
  const [apiKey, setApiKey] = useState('');
  const [tlsVerify, setTlsVerify] = useState(currentSettings?.tls_verify ?? true);

  if (!isOpen) return null;

  const handleSave = () => {
    onSave({
      primary_model: model,
      api_key: apiKey,
      tls_verify: tlsVerify
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border-l border-slate-800 p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
            <h2 className="text-lg font-bold flex items-center gap-2">
              <Lock className="text-blue-400" size={18} />
              <span>LiteLLM Router Settings</span>
            </h2>
            <button onClick={onClose} className="text-gray-400 hover:text-white">
              <X size={20} />
            </button>
          </div>

          <div className="space-y-5">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase mb-2">Primary LLM Model</label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
              >
                <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Fast Intake)</option>
                <option value="gemini-2.5-flash">gemini-2.5-flash (Standard Grounding)</option>
                <option value="gemini-2.5-pro">gemini-2.5-pro (Reasoning & Exceptions)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase mb-2">LiteLLM Gateway API Key</label>
              <input
                type="password"
                placeholder="••••••••••••••••••••"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
              />
              <p className="text-[11px] text-gray-500 mt-1">API keys are submitted to backend and never exposed in client logs.</p>
            </div>

            <div className="p-4 bg-slate-800/50 border border-slate-700/60 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Enforce TLS Verification</span>
                <input
                  type="checkbox"
                  checked={tlsVerify}
                  onChange={(e) => setTlsVerify(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
              </div>
              <p className="text-xs text-gray-400">
                Disabling TLS verification triggers a persistent security warning banner across the analyst console.
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-6 border-t border-slate-800">
          <button onClick={onClose} className="btn btn-secondary text-sm">Cancel</button>
          <button onClick={handleSave} className="btn btn-primary text-sm flex items-center gap-1.5">
            <Save size={16} />
            <span>Save Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};
