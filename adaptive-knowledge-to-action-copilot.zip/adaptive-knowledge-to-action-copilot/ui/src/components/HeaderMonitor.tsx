import React from 'react';
import { Activity, ShieldAlert, Cpu, Database, DollarSign, Settings, Layers, Lock } from 'lucide-react';

interface HeaderMonitorProps {
  metrics: any;
  uiConfig?: any;
  activeDomainPack: string;
  availableDomainPacks?: any[];
  onSelectDomainPack: (domainId: string) => void;
  onOpenSettings: () => void;
}

export const HeaderMonitor: React.FC<HeaderMonitorProps> = ({ 
  metrics, 
  uiConfig, 
  activeDomainPack, 
  availableDomainPacks = [],
  onSelectDomainPack, 
  onOpenSettings 
}) => {
  const gateway = metrics?.llm_gateway || {};
  const cache = metrics?.cache || {};
  const tlsDisabled = gateway?.tls_verify === false;

  // Filter packs enabled by manifest (active: true)
  const enabledPacks = availableDomainPacks.filter(p => p.active !== false);
  const isMultipleActive = enabledPacks.length > 1;
  const isSingleActive = enabledPacks.length === 1;

  return (
    <header className="mb-6">
      {tlsDisabled && (
        <div className="tls-alert-banner mb-4">
          <div className="flex items-center gap-2">
            <ShieldAlert size={18} />
            <span>SECURITY ALERT: TLS Verification is explicitly DISABLED in LiteLLM Gateway settings. Non-production transport mode active.</span>
          </div>
          <button onClick={onOpenSettings} className="underline text-xs hover:text-white">Configure Settings</button>
        </div>
      )}

      <div className="glass-card flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-600/20 border border-blue-500/30 rounded-xl text-blue-400">
            <Activity size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold">{uiConfig?.app_title || 'Adaptive Knowledge-to-Action Copilot'}</h1>
              <span className="badge badge-info">{uiConfig?.domain_badge || 'Domain Pack Active'}</span>
            </div>
            <p className="text-xs text-gray-400 mt-0.5">Daemonless Embedded Platform • 3-Way Hybrid RRF Retrieval • Deterministic Policy Gate</p>
          </div>
        </div>

        <div className="flex items-center gap-5 text-sm flex-wrap justify-end">
          {/* Live Domain Knowledge Pack Switcher */}
          <div className={`flex items-center gap-2 bg-slate-950/80 border rounded-lg px-2.5 py-1.5 ${
            isMultipleActive ? 'border-cyan-500/50 shadow-[0_0_8px_rgba(6,182,212,0.2)]' : 'border-slate-700/80 opacity-90'
          }`}>
            <Layers className="text-cyan-400 shrink-0" size={15} />
            <div>
              <div className="text-[10px] uppercase font-bold text-gray-400">Domain Pack</div>
              <select
                value={activeDomainPack}
                disabled={!isMultipleActive}
                onChange={(e) => onSelectDomainPack(e.target.value)}
                className={`bg-transparent text-xs font-semibold focus:outline-none ${
                  isMultipleActive 
                    ? 'text-white cursor-pointer hover:text-cyan-300' 
                    : 'text-gray-300 cursor-not-allowed'
                }`}
                title={isMultipleActive ? "Select active domain knowledge pack" : "Only 1 domain pack is active in manifest"}
              >
                {enabledPacks.length > 0 ? (
                  enabledPacks.map(pack => (
                    <option key={pack.domain_id} value={pack.domain_id} className="bg-slate-900 text-white">
                      {pack.name}
                    </option>
                  ))
                ) : (
                  <option value="" className="bg-slate-900 text-gray-400">No active packs</option>
                )}
              </select>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Cpu className="text-cyan-400" size={16} />
            <div>
              <div className="text-xs text-gray-400">Model</div>
              <div className="font-semibold">{gateway.primary_model || 'gemini-3.1-flash-lite'}</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Database className="text-purple-400" size={16} />
            <div>
              <div className="text-xs text-gray-400">Tokens / Cache Hit</div>
              <div className="font-semibold">{gateway.total_tokens || 0} / {cache.hit_ratio_pct || 0}%</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <DollarSign className="text-emerald-400" size={16} />
            <div>
              <div className="text-xs text-gray-400">Est. LLM Cost</div>
              <div className="font-semibold text-emerald-400">${gateway.estimated_cost_usd || '0.0000'}</div>
            </div>
          </div>

          <button onClick={onOpenSettings} className="btn btn-secondary text-xs flex items-center gap-1">
            <Settings size={14} />
            <span>Settings</span>
          </button>
        </div>
      </div>
    </header>
  );
};
