import React, { useState, useEffect } from 'react';
import { HeaderMonitor } from './components/HeaderMonitor';
import { SettingsDrawer } from './components/SettingsDrawer';
import { KnowledgeGraphViewer } from './components/KnowledgeGraphViewer';
import { 
  Play, ShieldCheck, ShieldAlert, FileText, Share2, Terminal, Upload, 
  BarChart3, CheckCircle2, XCircle, AlertTriangle, ArrowRight, RefreshCw, UserCheck, Lock, ExternalLink
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'console' | 'grounding' | 'mcp' | 'knowledge' | 'dashboard'>('console');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  
  const [syntheticTxns, setSyntheticTxns] = useState<any[]>([]);
  const [activeDomainPack, setActiveDomainPack] = useState<string>('card_dispute_ops');
  const [availableDomainPacks, setAvailableDomainPacks] = useState<any[]>([]);
  const [selectedTxId, setSelectedTxId] = useState<string>('TX-1001');
  const [cardholderStatement, setCardholderStatement] = useState<string>('I do not recognize this charge on my statement.');
  
  const [activeWorkItem, setActiveWorkItem] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const [metrics, setMetrics] = useState<any>(null);
  const [uiConfig, setUiConfig] = useState<any>(null);
  const [mcpLogs, setMcpLogs] = useState<any[]>([]);
  const [corpusStats, setCorpusStats] = useState<any>(null);
  const [graphData, setGraphData] = useState<any>(null);
  
  const [humanNotes, setHumanNotes] = useState<string>('');

  // Fetch initial data
  useEffect(() => {
    fetchDomainPacks();
    fetchSyntheticTxns();
    fetchUiConfig();
    fetchMetrics();
    fetchMcpLogs();
    fetchCorpusStats();
    fetchGraphData();
  }, []);

  const fetchDomainPacks = async () => {
    try {
      const res = await fetch('/api/v1/work-items/domain-packs');
      const data = await res.json();
      setAvailableDomainPacks(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleSelectDomainPack = async (domainId: string) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/v1/work-items/domain-packs/select', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain_id: domainId })
      });
      const data = await res.json();
      setActiveDomainPack(domainId);
      setUiConfig(data.ui_config);
      setActiveWorkItem(null);
      
      // Update default transaction ID and statement
      if (domainId === 'retail_returns_ops') {
        setSelectedTxId('ORD-5001');
        setCardholderStatement('Item arrived with damaged packaging and broken casing during shipping.');
      } else {
        setSelectedTxId('TX-1001');
        setCardholderStatement('I do not recognize this charge on my statement.');
      }

      await fetchSyntheticTxns();
      await fetchGraphData();
      await fetchCorpusStats();
      await fetchMetrics();
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchUiConfig = async () => {
    try {
      const res = await fetch('/api/v1/work-items/ui-config');
      const data = await res.json();
      setUiConfig(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchSyntheticTxns = async () => {
    try {
      const res = await fetch('/api/v1/work-items/synthetic-transactions');
      const data = await res.json();
      setSyntheticTxns(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchMetrics = async () => {
    try {
      const res = await fetch('/api/v1/metrics/dashboard');
      const data = await res.json();
      setMetrics(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchMcpLogs = async () => {
    try {
      const res = await fetch('/api/v1/mcp/logs');
      const data = await res.json();
      setMcpLogs(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchCorpusStats = async () => {
    try {
      const res = await fetch('/api/v1/knowledge/stats');
      const data = await res.json();
      setCorpusStats(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchGraphData = async () => {
    try {
      const res = await fetch('/api/v1/knowledge/graph');
      const data = await res.json();
      setGraphData(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleStartInvestigation = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/v1/work-items/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transaction_id: selectedTxId,
          cardholder_statement: cardholderStatement
        })
      });
      const data = await res.json();
      setActiveWorkItem(data);
      fetchMetrics();
      fetchMcpLogs();
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResumeReview = async (action: 'APPROVE' | 'REJECT') => {
    if (!activeWorkItem) return;
    setIsLoading(true);
    try {
      const res = await fetch(`/api/v1/work-items/${activeWorkItem.work_item_id}/resume`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          notes: humanNotes || 'Analyst reviewed case evidence and submitted decision.'
        })
      });
      const data = await res.json();
      
      // Refresh full work item
      const fullRes = await fetch(`/api/v1/work-items/${activeWorkItem.work_item_id}`);
      const fullData = await fullRes.json();
      setActiveWorkItem(fullData);

      fetchMetrics();
      fetchMcpLogs();
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveSettings = async (newSettings: any) => {
    try {
      await fetch('/api/v1/settings/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings)
      });
      fetchMetrics();
    } catch (e) {
      console.error(e);
    }
  };

  const selectedTxnDetails = syntheticTxns.find(t => t.transaction_id === selectedTxId);

  return (
    <div className="app-container">
      <HeaderMonitor 
        metrics={metrics} 
        uiConfig={uiConfig} 
        activeDomainPack={activeDomainPack}
        availableDomainPacks={availableDomainPacks}
        onSelectDomainPack={handleSelectDomainPack}
        onOpenSettings={() => setIsSettingsOpen(true)} 
      />

      {/* Navigation Tabs */}
      <div className="tab-list">
        <button
          onClick={() => setActiveTab('console')}
          className={`tab-btn ${activeTab === 'console' ? 'active' : ''}`}
        >
          <Play size={16} />
          <span>Analyst Investigation Console</span>
        </button>
        <button
          onClick={() => setActiveTab('grounding')}
          className={`tab-btn ${activeTab === 'grounding' ? 'active' : ''}`}
        >
          <Share2 size={16} />
          <span>Grounding & Cypher KG Subgraph</span>
        </button>
        <button
          onClick={() => setActiveTab('mcp')}
          className={`tab-btn ${activeTab === 'mcp' ? 'active' : ''}`}
        >
          <Terminal size={16} />
          <span>MCP Tool Telemetry Console</span>
        </button>
        <button
          onClick={() => setActiveTab('knowledge')}
          className={`tab-btn ${activeTab === 'knowledge' ? 'active' : ''}`}
        >
          <FileText size={16} />
          <span>Knowledge Base Manager</span>
        </button>
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`tab-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
        >
          <BarChart3 size={16} />
          <span>KPI & Metrics Dashboard</span>
        </button>
      </div>

      {/* TAB 1: ANALYST INVESTIGATION CONSOLE */}
      {activeTab === 'console' && (
        <div className="space-y-6">
          {/* Intake Selection Bar */}
          <div className="glass-card">
            <h2 className="text-base font-bold mb-3 flex items-center gap-2">
              <UserCheck size={18} className="text-blue-400" />
              <span>{uiConfig?.item_selector_label || 'Cardholder Intake & Synthetic Transaction Selector'}</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Target Synthetic Transaction</label>
                <select
                  value={selectedTxId}
                  onChange={(e) => setSelectedTxId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                >
                  {syntheticTxns.map((t) => (
                    <option key={t.transaction_id} value={t.transaction_id}>
                      {t.transaction_id} — {t.merchant_name} (${t.amount.toFixed(2)}) — Age: {t.transaction_age_days}d
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-400 uppercase mb-1">Cardholder Statement Intake</label>
                <input
                  type="text"
                  value={cardholderStatement}
                  onChange={(e) => setCardholderStatement(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <button
                  onClick={handleStartInvestigation}
                  disabled={isLoading}
                  className="btn btn-primary w-full py-2.5 flex items-center justify-center gap-2"
                >
                  {isLoading ? <RefreshCw className="animate-spin" size={16} /> : <Play size={16} />}
                  <span>Launch Copilot Investigation</span>
                </button>
              </div>
            </div>

            {selectedTxnDetails && (
              <div className="mt-4 pt-3 border-t border-slate-800 grid grid-cols-2 md:grid-cols-6 gap-3 text-xs">
                <div><span className="text-gray-400">Card Last 4:</span> <span className="font-semibold text-white">•••• {selectedTxnDetails.card_last4}</span></div>
                <div><span className="text-gray-400">Amount:</span> <span className="font-semibold text-emerald-400">${selectedTxnDetails.amount.toFixed(2)}</span></div>
                <div><span className="text-gray-400">Merchant Category:</span> <span className="font-semibold text-white">{selectedTxnDetails.merchant_category}</span></div>
                <div><span className="text-gray-400">POS Channel:</span> <span className="font-semibold text-cyan-400">{selectedTxnDetails.channel}</span></div>
                <div><span className="text-gray-400">Txn Age:</span> <span className="font-semibold text-amber-400">{selectedTxnDetails.transaction_age_days} Days</span></div>
                <div><span className="text-gray-400">Status:</span> <span className="font-semibold text-white">{selectedTxnDetails.status}</span></div>
              </div>
            )}
          </div>

          {/* Active Work Item Workflow Display */}
          {activeWorkItem && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column: 6-Check Policy Authorization Matrix */}
              <div className="lg:col-span-2 space-y-6">
                <div className="glass-card">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-base font-bold flex items-center gap-2">
                        <ShieldCheck size={20} className="text-emerald-400" />
                        <span>Deterministic Policy Authorization Gate Matrix</span>
                      </h3>
                      <p className="text-xs text-gray-400">Requires 100% PASS across all 6 reviewed policy rules to authorize automatic action</p>
                    </div>

                    <div>
                      {activeWorkItem.is_authorized ? (
                        <span className="badge badge-pass">AUTO_AUTHORIZED</span>
                      ) : activeWorkItem.status === 'ESCALATED_HUMAN_REVIEW' ? (
                        <span className="badge badge-warning">HUMAN_REVIEW_REQUIRED</span>
                      ) : activeWorkItem.status === 'ACTION_COMPLETED' ? (
                        <span className="badge badge-pass">CASE_CREATED</span>
                      ) : (
                        <span className="badge badge-fail">{activeWorkItem.status}</span>
                      )}
                    </div>
                  </div>

                  <div className="space-y-3">
                    {activeWorkItem.policy_check_matrix?.map((check: any) => (
                      <div
                        key={check.rule_id}
                        className={`p-3.5 rounded-xl border transition-all ${
                          check.status === 'PASS'
                            ? 'bg-emerald-950/20 border-emerald-800/40'
                            : check.status === 'CONFLICTING'
                            ? 'bg-amber-950/20 border-amber-800/40'
                            : 'bg-rose-950/20 border-rose-800/40'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            {check.status === 'PASS' ? (
                              <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />
                            ) : check.status === 'CONFLICTING' ? (
                              <AlertTriangle size={18} className="text-amber-400 shrink-0" />
                            ) : (
                              <XCircle size={18} className="text-rose-400 shrink-0" />
                            )}
                            <span className="font-semibold text-sm">{check.rule_name}</span>
                          </div>

                          <span className={`badge ${
                            check.status === 'PASS' ? 'badge-pass' : check.status === 'CONFLICTING' ? 'badge-warning' : 'badge-fail'
                          }`}>
                            {check.status}
                          </span>
                        </div>

                        <p className="text-xs text-gray-300 mt-2 pl-6">{check.details}</p>

                        <div className="mt-2 pl-6 flex items-center gap-2 text-[11px] text-gray-400 border-t border-white/5 pt-2">
                          <span className="font-mono text-cyan-400">{check.source_passage_id}</span>
                          <span>—</span>
                          <span className="italic">{check.policy_citation}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Grounding & Evidence Assessment Card */}
                {activeWorkItem.evidence_assessment && (
                  <div className="glass-card">
                    <h3 className="text-sm font-bold mb-3 flex items-center gap-2 text-purple-400">
                      <FileText size={16} />
                      <span>AI Model Grounding & Evidence Assessment</span>
                    </h3>
                    <div className="p-3 bg-slate-900/60 rounded-lg text-xs space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Dispute Classification:</span>
                        <span className="font-semibold text-white">{activeWorkItem.evidence_assessment.classification}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Grounding Confidence Score:</span>
                        <span className="font-semibold text-cyan-400">{(activeWorkItem.evidence_assessment.confidence * 100).toFixed(0)}%</span>
                      </div>
                      <div>
                        <span className="text-gray-400 block mb-1">Key Evidence Findings:</span>
                        <ul className="list-disc pl-4 space-y-0.5 text-gray-300">
                          {activeWorkItem.evidence_assessment.key_findings?.map((f: string, i: number) => (
                            <li key={i}>{f}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Right Column: Case Outcome & Human Review Panel */}
              <div className="space-y-6">
                <div className="glass-card">
                  <h3 className="text-base font-bold mb-3 flex items-center gap-2">
                    <Lock size={18} className="text-cyan-400" />
                    <span>Workflow Decision & Action Outcome</span>
                  </h3>

                  <div className="p-4 bg-slate-900/80 rounded-xl border border-slate-800 mb-4 text-xs space-y-2">
                    <div>
                      <span className="text-gray-400 block">Decision Status:</span>
                      <span className="font-bold text-sm text-white">{activeWorkItem.decision_reason}</span>
                    </div>

                    {activeWorkItem.action_record && (
                      <div className="mt-3 pt-3 border-t border-slate-800 space-y-1.5">
                        <div className="text-emerald-400 font-bold flex items-center gap-1">
                          <CheckCircle2 size={14} />
                          <span>Mock Dispute Case Registered</span>
                        </div>
                        <div><span className="text-gray-400">Case ID:</span> <span className="font-mono font-bold text-white">{activeWorkItem.action_record.case_id}</span></div>
                        <div><span className="text-gray-400">Disputed Amount:</span> <span className="font-bold text-emerald-400">${activeWorkItem.action_record.disputed_amount?.toFixed(2)}</span></div>
                        <div><span className="text-gray-400">Provisional Credit:</span> <span className="font-semibold text-cyan-400">{activeWorkItem.action_record.provisional_credit_issued ? 'ISSUED ($500 limit)' : 'NOT ISSUED'}</span></div>
                        <div><span className="text-gray-400">Idempotency Key:</span> <span className="font-mono text-[10px] text-gray-400">{activeWorkItem.action_record.idempotency_key}</span></div>
                        <div><span className="text-gray-400">Authorized By:</span> <span className="font-semibold text-purple-300">{activeWorkItem.action_record.created_by}</span></div>
                      </div>
                    )}
                  </div>

                  {/* Pause & Resume Controls for Escalated Human Review */}
                  {activeWorkItem.status === 'ESCALATED_HUMAN_REVIEW' && (
                    <div className="p-4 bg-amber-950/30 border border-amber-800/50 rounded-xl space-y-3">
                      <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                        <AlertTriangle size={18} />
                        <span>Human Review Required (Paused Workflow)</span>
                      </div>
                      <p className="text-xs text-gray-300">
                        Automatic case creation blocked due to policy check exception or conflicting evidence. Please review evidence citations and submit analyst decision.
                      </p>

                      <textarea
                        rows={2}
                        placeholder="Enter analyst justification notes..."
                        value={humanNotes}
                        onChange={(e) => setHumanNotes(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-amber-500"
                      />

                      <div className="flex gap-2">
                        <button
                          onClick={() => handleResumeReview('APPROVE')}
                          disabled={isLoading}
                          className="btn btn-success text-xs flex-1 py-2"
                        >
                          <span>Override & Create Case</span>
                        </button>
                        <button
                          onClick={() => handleResumeReview('REJECT')}
                          disabled={isLoading}
                          className="btn btn-danger text-xs flex-1 py-2"
                        >
                          <span>Reject Dispute Claim</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: GROUNDING & CYPHER KG SUBGRAPH */}
      {activeTab === 'grounding' && (
        <KnowledgeGraphViewer graphData={graphData} />
      )}

      {/* TAB 3: MCP TELEMETRY CONSOLE */}
      {activeTab === 'mcp' && (
        <div className="space-y-6">
          <div className="glass-card">
            <h2 className="text-base font-bold mb-3 flex items-center gap-2">
              <Terminal size={20} className="text-cyan-400" />
              <span>Live MCP (Model Context Protocol) Tool Invocation Logs</span>
            </h2>
            <p className="text-xs text-gray-400 mb-4">
              Displays tool execution dispatches between core platform client and standalone Mock MCP Server (<span className="font-mono text-cyan-400">mcp_server/</span>).
            </p>

            <div className="space-y-3">
              {mcpLogs.length === 0 ? (
                <p className="text-xs text-gray-500 italic">No MCP tools invoked yet. Launch an investigation on the Console tab.</p>
              ) : (
                mcpLogs.map((log: any, i: number) => (
                  <div key={i} className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono">
                    <div className="flex items-center justify-between text-cyan-400 font-bold mb-1">
                      <span>TOOL: {log.tool_name}</span>
                      <span className="badge badge-pass text-[10px]">{log.status}</span>
                    </div>
                    <div className="text-gray-400 mb-1">Arguments: {JSON.stringify(log.arguments)}</div>
                    <div className="text-emerald-400 bg-black/40 p-2 rounded border border-white/5 overflow-x-auto">
                      Result: {JSON.stringify(log.response)}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: KNOWLEDGE MANAGER */}
      {activeTab === 'knowledge' && (
        <div className="space-y-6">
          <div className="glass-card">
            <h2 className="text-base font-bold mb-3 flex items-center gap-2">
              <FileText size={20} className="text-emerald-400" />
              <span>Knowledge Base & Policy Document Manager</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-xs">
                <div className="text-gray-400">Vector Engine</div>
                <div className="font-bold text-white text-sm">{corpusStats?.vector_engine}</div>
              </div>
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-xs">
                <div className="text-gray-400">Indexed Document Chunks</div>
                <div className="font-bold text-cyan-400 text-sm">{corpusStats?.vector_chunks_count} Chunks</div>
              </div>
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-xs">
                <div className="text-gray-400">LadybugDB Graph Triples</div>
                <div className="font-bold text-purple-400 text-sm">{corpusStats?.ladybug_nodes_count} Nodes / {corpusStats?.ladybug_edges_count} Edges</div>
              </div>
            </div>

            <div className="p-6 border-2 border-dashed border-slate-700 rounded-xl text-center">
              <Upload size={32} className="mx-auto text-gray-500 mb-2" />
              <h3 className="text-sm font-semibold mb-1">Upload Operating Policy Document (.md)</h3>
              <p className="text-xs text-gray-400 mb-3">Upload markdown files to chunk, embed, and index into ChromaDB & BM25 index immediately.</p>
              <input type="file" accept=".md,.txt" className="text-xs text-gray-400 file:btn file:btn-secondary file:text-xs" />
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: KPI DASHBOARD */}
      {activeTab === 'dashboard' && (
        <div className="space-y-6">
          <div className="glass-card">
            <h2 className="text-base font-bold mb-4 flex items-center gap-2">
              <BarChart3 size={20} className="text-blue-400" />
              <span>Executive Business & IT Metrics Dashboard</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
                <div className="text-xs text-gray-400">Handling Time Reduction</div>
                <div className="text-2xl font-bold text-emerald-400">77.9%</div>
                <div className="text-[11px] text-gray-500 mt-1">14.5m baseline → 3.2m AI</div>
              </div>

              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
                <div className="text-xs text-gray-400">Policy Check Accuracy</div>
                <div className="text-2xl font-bold text-cyan-400">100%</div>
                <div className="text-[11px] text-gray-500 mt-1">Target: ≥ 90%</div>
              </div>

              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
                <div className="text-xs text-gray-400">Erroneous Automatic Actions</div>
                <div className="text-2xl font-bold text-emerald-400">0</div>
                <div className="text-[11px] text-gray-500 mt-1">Strict fail-closed gate</div>
              </div>

              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
                <div className="text-xs text-gray-400">Traceability Coverage</div>
                <div className="text-2xl font-bold text-purple-400">100%</div>
                <div className="text-[11px] text-gray-500 mt-1">Every check linked to citation</div>
              </div>
            </div>

            <div className="p-4 bg-slate-900/60 rounded-xl border border-slate-800 text-xs space-y-2">
              <h3 className="font-bold text-sm text-white mb-2">Non-Bypass Safety Architecture Highlights</h3>
              <p className="text-gray-300">• <strong>Policy, not confidence, authorizes action:</strong> Model confidence is necessary but never sufficient.</p>
              <p className="text-gray-300">• <strong>Daemonless Embedded Footprint:</strong> LadybugDB property graph (.lbug) and ChromaDB vector store run inside local user space without Docker or root privileges.</p>
              <p className="text-gray-300">• <strong>Pluggable Domain Packs:</strong> Banking terminology, rules, schemas, and Cypher graph triples are cleanly separated from the reusable platform core.</p>
            </div>
          </div>
        </div>
      )}

      {/* Settings Drawer Modal */}
      <SettingsDrawer
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        currentSettings={metrics?.llm_gateway}
        onSave={handleSaveSettings}
      />
    </div>
  );
}
