# Architecture & Implementation Plan: Adaptive Knowledge-to-Action Copilot

## Overview

The **Adaptive Knowledge-to-Action Copilot** converts fragmented enterprise knowledge and operational facts into explainable decisions and controlled actions. Built according to the specification in [prd.md](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/prd.md) and [usecase.md](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/usecase.md), the system enforces a strict separation between a **reusable domain-agnostic core platform** and **pluggable Domain Knowledge Packs** (demonstrated via a **Card Dispute Operations Domain Knowledge Pack** for banking).

Operational data ingestion and action execution are decoupled through a dedicated **Mock MCP (Model Context Protocol) Server**. Policy knowledge retrieval uses an **Embedded LadybugDB Property Graph & Hybrid Search Engine** (combining LadybugDB Cypher graph traversals, ChromaDB dense vector embeddings, and BM25 sparse keyword search).

The system runs entirely in local user space without external database daemons, container runtimes, or administrative privileges.

---

## Architectural Blueprint

```mermaid
graph TD
    subgraph Frontend ["Frontend Tier (React + Dynamic Domain Layout)"]
        UI["Domain-Aware Analyst Console"]
        Header["Global LLM & Cost Monitor"]
        Settings["Settings Drawer & TLS Controls"]
        KGViewer["Interactive Cypher & KG Graph Viewer"]
        MCPConsole["MCP Tool Monitor & Log Console"]
    end

    subgraph API ["API Tier (FastAPI Backend)"]
        Routes["REST Endpoints (/api/v1)"]
        A2ACard["A2A Protocol & Dynamic Agent Card"]
    end

    subgraph Core ["Reusable Domain-Agnostic Core Platform"]
        PackRegistry["Domain Knowledge Pack Registry & Loader"]
        MCPClient["Core MCP Protocol Client"]
        Orchestrator["LangGraph Workflow Engine (WorkItem State)"]
        subgraph HybridSearch ["3-Way Hybrid Retrieval Engine"]
            VectorSearch["ChromaDB Dense Vector Search"]
            SparseSearch["BM25 Keyword Search Engine"]
            LadybugGraph["LadybugDB Property Graph (Cypher Queries)"]
            RRF["Reciprocal Rank Fusion (RRF) Re-ranker"]
        end
        PolicyGate["Deterministic Policy Authorization Gate (PolicyRule)"]
        Actions["Idempotent Action Engine (MCP Tool Action)"]
        Cache["SQLite Exact & Semantic Cache Manager"]
        Gateway["LiteLLM Router & Model Initializer"]
        Obs["LangSmith Tracing & Redacted JSON Logger"]
    end

    subgraph MCPServer ["Standalone Mock MCP Server (mcp_server/)"]
        MCPProtocol["MCP Server Engine (FastMCP / JSON-RPC Protocol)"]
        IngestionTools["Ingestion Tools (get_facts, get_history)"]
        ActionTools["Action Tools (create_mock_dispute_case)"]
    end

    subgraph DomainPacks ["Pluggable Domain Knowledge Packs"]
        subgraph BankingPack ["packs/card_dispute/ (Active Demo Pack)"]
            BankManifest["manifest.json (MCP Tool Bindings, Rules)"]
            BankKnowledge["knowledge/ (Synthetic Operating Manuals)"]
            BankKG["kg_triples.json (Cypher Node & Edge Definitions)"]
            BankSchemas["schemas/ (Transaction Facts, Dispute Intake)"]
            BankRules["rules/ (6 Reviewed Banking Dispute Rules)"]
            BankData["data/ (Synthetic Enterprise DB Records)"]
            BankUI["ui_config/ (Banking Labels & Card Layouts)"]
            BankEval["eval/ (Banking Benchmark Dataset)"]
        end
    end

    subgraph Storage ["Local Embedded Storage (Daemonless)"]
        ChromaDB[("ChromaDB Embedded Vector Store")]
        LadybugDB[("LadybugDB Embedded Graph Store (.lbug)")]
        SQLite[("SQLite DB (Checkpoints & Audit Logs)")]
    end

    UI --> Routes
    Header --> Routes
    Settings --> Routes
    KGViewer --> Routes
    MCPConsole --> Routes
    Routes --> Core
    A2ACard --> PackRegistry
    Core --> PackRegistry
    PackRegistry --> BankingPack
    Core --> MCPClient
    MCPClient -- "MCP Protocol (stdio/HTTP)" --> MCPServer
    MCPServer --> BankData
    VectorSearch --> ChromaDB
    LadybugGraph --> LadybugDB
    HybridSearch --> Orchestrator
    Orchestrator --> SQLite
    Cache --> SQLite
    Gateway --> LiteLLM["LiteLLM Gateway / LLM Providers"]
    Obs --> LangSmith["LangSmith Observability"]
```

---

## LadybugDB & Hybrid Search Architecture

### Why LadybugDB?
- **Serverless & Embedded**: Runs in user space storing graph data in a local `.lbug` file without requiring Docker, root access, or database daemons (fulfilling **NFR-001**).
- **Cypher Query Language**: Supports standard Cypher property graph queries for multi-hop graph traversal and relationship filtering.
- **Native Graph RAG**: Optimized for combining structural graph expansion with semantic retrieval.
- **Resilient Fallback**: Includes a fallback adapter to NetworkX / SQLite graph storage if the `ladybug` native module is not installed in the execution environment.

```mermaid
flowchart LR
    Query["User Query / Work Item Intake"] --> Splitter["Query Decomposition"]
    Splitter --> Dense["1. ChromaDB Vector Search (Embeddings)"]
    Splitter --> Sparse["2. BM25 Sparse Search (Keywords)"]
    Splitter --> Graph["3. LadybugDB Cypher Graph Traversal"]
    
    Dense --> RRF["Reciprocal Rank Fusion (RRF) Re-Ranker"]
    Sparse --> RRF
    Graph --> RRF
    
    RRF --> Envelope["Unified Grounding Envelope (Citations + Cypher Subgraph)"]
```

### 1. LadybugDB Graph Schema (`core/retrieval/knowledge_graph.py`)
- Nodes and relationships are stored in embedded LadybugDB property graph format:
  - **Node Labels**: `PolicySection`, `RuleCondition`, `DisputeCategory`, `TransactionType`, `EvidenceType`, `ActionAuthority`.
  - **Rel Types**: `REGULATES`, `REQUIRES_CHECK`, `EXEMPTS`, `SUPERSEDES`, `EVALUATES_FACT`.
- Cypher Query Example:
  ```cypher
  MATCH (c:DisputeCategory {id: 'UNRECOGNIZED_CARD'})-[:REGULATES]->(p:PolicySection)-[:REQUIRES_CHECK]->(r:RuleCondition)
  RETURN p, r
  ```

### 2. Hybrid Retrieval Components
- **Dense Vector Search**: ChromaDB semantic distance search over policy manual chunks.
- **Sparse BM25 Search**: Exact keyword match scoring over policy prose and code condition identifiers.
- **LadybugDB Cypher Traversal**: Executes structured Cypher queries matching intake entities to retrieve policy preconditions and dependencies.

### 3. Reciprocal Rank Fusion (RRF) & Grounding Envelope
- Merges ranked lists from Vector, BM25, and LadybugDB graph queries using RRF.
- Produces a grounded evidence envelope containing source passages, document versions, confidence scores, and **interactive Cypher graph subgraphs** for visual inspection in the UI.

---

## Core Abstractions vs. Domain Knowledge Pack Responsibilities

| Core Abstraction | Core Platform Responsibility | Domain Knowledge Pack Responsibility |
|---|---|---|
| **`LadybugGraphEngine`** | Manages embedded LadybugDB `.lbug` database, Cypher query execution, and fallback graph traversal. | Defines domain-specific Cypher node tables, edge tables, and triples in `kg_triples.json`. |
| **`HybridRetriever`** | Orchestrates ChromaDB vector search, BM25 keyword search, LadybugDB Cypher queries, and RRF re-ranking. | Supplies policy manuals, FAQs, and chunking parameters. |
| **`DomainPackManifest`** | Validates schema version, identity, capabilities, and MCP tool bindings at startup. | Defines pack metadata, required facts schema, UI field mappings, and MCP tool registrations. |
| **`MCPServer` & `MCPClient`** | Runs Mock MCP Server, manages stdio/HTTP transport, discovers tools, and handles tool execution protocol. | Supplies mock data fixtures and tool definitions to the MCP Server. |
| **`WorkItem`** | Manages lifecycle, workflow status (`NEW`, `EVALUATING`, `AUTO_APPROVED`, `ESCALATED_HUMAN_REVIEW`, `ACTION_COMPLETED`), checkpoints, and audit trails. | Maps operational payloads into `WorkItem` facts envelope. |
| **`PolicyRule` & `AuthorizationGate`** | Executes rules deterministically; requires 100% PASS across all active rules for auto-action; fails closed on any FAIL/UNKNOWN/CONFLICT. | Defines domain-specific machine-evaluable functions linked to policy source passage IDs. |
| **`UIConfig`** | Renders generic workspace framework, monitors, evidence drawers, policy check matrix, Cypher KG visualizer, and MCP logs. | Provides dynamic labels, field formatting, navigation titles, and card layouts. |

---

## Core System Boundaries & Data Flow

1. **Boot & Ingestion**: Startup loads Domain Knowledge Pack `manifest.json`, indexes policy documents into ChromaDB & BM25 index, initializes LadybugDB property graph tables, and registers MCP server tools.
2. **MCP Data Ingestion**: Workflow starts for work item `TX-1001`. Core `MCPClient` executes `get_transaction_facts`, `get_customer_verification`, and `get_dispute_history` on `MCPServer`.
3. **Hybrid Retrieval & Grounding**: `HybridRetriever` executes 3-way search (ChromaDB + BM25 + LadybugDB Cypher traversal), applies Reciprocal Rank Fusion, and constructs the unified Grounding Envelope.
4. **Structured Reasoning**: LangGraph orchestrates LLM calls via LiteLLM (`gemini-3.1-flash-lite`, `gemini-2.5-flash`, `gemini-2.5-pro`) to classify items and extract evidence assessments matching the pack's Pydantic schemas.
5. **Deterministic Policy Gate Evaluation**: Core evaluates active domain rules loaded from the pack (for Banking: dispute window, amount limit, duplicate check, identity status, evidence conflicts, and confidence threshold). Model confidence is necessary but *never sufficient*.
6. **Action Execution via MCP or Human Escalation**:
   - **All Rules Pass**: Core invokes `mcp:create_mock_dispute_case` on `MCPServer` with idempotent key.
   - **Any Rule Fails / Unknown / Conflicting**: LangGraph pauses execution for human analyst review. Upon analyst approval, `mcp:create_mock_dispute_case` is dispatched to `MCPServer`.
7. **Audit & Telemetry**: Full execution lineage recorded in SQLite tagged with `domain_id`, `pack_version`, `hybrid_search_scores`, and `mcp_tool_invocation`; correlated traces emitted to LangSmith with secret/PII redaction.

---

## Proposed Project Directory Structure

```text
adaptive-knowledge-to-action-copilot2/
├── prd.md
├── usecase.md
├── mcp_server/                         # Standalone Mock MCP Server
│   ├── server.py                       # MCP Server Entrypoint (FastMCP / MCP Protocol)
│   ├── tools/                          # Exposed MCP Tools
│   │   ├── ingestion_tools.py          # get_transaction_facts, get_customer_verification, etc.
│   │   └── action_tools.py             # create_mock_dispute_case
│   └── data_store.py                   # In-memory / JSON Mock Enterprise Data Store
├── backend/
│   ├── pyproject.toml
│   ├── app/
│   │   ├── main.py                     # FastAPI application entrypoint
│   │   ├── config.py                   # Pydantic settings & boot validation
│   │   ├── api/                        # REST API routes (Domain-Agnostic)
│   │   │   ├── work_items.py           # Work item selection & execution
│   │   │   ├── knowledge.py            # Document ingestion & corpus stats
│   │   │   ├── metrics.py              # Telemetry & KPI dashboard
│   │   │   ├── mcp_telemetry.py        # MCP Tool invocation log API
│   │   │   ├── settings.py             # LiteLLM & TLS configuration
│   │   │   └── a2a.py                  # Dynamic A2A Agent Card export
│   │   ├── core/                       # Reusable Domain-Agnostic Platform Core
│   │   │   ├── domain_pack/            # Pack Interface & Registry System
│   │   │   │   ├── interface.py        # Base Abstract Classes & Schema Models
│   │   │   │   ├── registry.py         # Loader, Validator & Pack Context
│   │   │   │   └── validator.py        # Safety & Non-Bypass Contract Validator
│   │   │   ├── retrieval/              # Hybrid Search & Knowledge Graph Engine
│   │   │   │   ├── vector_store.py     # ChromaDB Client & Embeddings
│   │   │   │   ├── sparse_search.py    # BM25 Keyword Search Index
│   │   │   │   ├── ladybug_graph.py    # LadybugDB Embedded Property Graph (Cypher)
│   │   │   │   └── hybrid_retriever.py # RRF Fusion Re-ranker & Envelope Builder
│   │   │   ├── mcp_client.py           # Core MCP Client bridging to mcp_server
│   │   │   ├── orchestrator.py         # LangGraph workflow engine (WorkItem state)
│   │   │   ├── policy_gate.py          # Deterministic Rule Authorization Gate
│   │   │   ├── actions.py              # Idempotent MCP Action Execution Engine
│   │   │   ├── caching.py              # SQLite exact & semantic cache
│   │   │   ├── gateway.py              # LiteLLM router & LangChain model init
│   │   │   └── telemetry.py            # LangSmith tracing & redacted JSON logging
│   │   └── packs/                      # Pluggable Domain Knowledge Packs
│   │       └── card_dispute/           # Banking Domain Knowledge Pack (Demo)
│   │           ├── manifest.json       # Pack Manifest & MCP Tool Declarations
│   │           ├── schemas.py          # Domain Pydantic Schemas
│   │           ├── rules.py            # 6 Reviewed Operating Policy Rules
│   │           ├── prompts.py          # Grounding Prompts & Templates
│   │           ├── kg_triples.json     # Banking Cypher Node/Edge Definitions
│   │           ├── ui_config.json      # Dynamic UI Labels & Field Specs
│   │           ├── knowledge/          # Synthetic Operating Manuals
│   │           ├── fixtures/           # Synthetic Intake Transactions & Data Records
│   │           └── eval/               # Banking KPI Evaluation Suite
│   └── tests/
│       ├── test_mcp_server.py          # MCP Server & Tool Calling tests
│       ├── test_ladybug_graph.py       # LadybugDB Cypher query tests
│       ├── test_hybrid_search.py       # Vector + BM25 + LadybugDB RRF search tests
│       ├── test_pack_contract.py       # Validates Domain Knowledge Pack interface
│       ├── test_core_isolation.py      # Proves core has no domain leaks
│       ├── test_policy_gate.py         # Deterministic rule evaluation tests
│       └── test_card_dispute_pack.py   # Banking domain pack functional tests
└── ui/
    ├── package.json
    ├── vite.config.ts
    ├── tailwind.config.js
    ├── src/
    │   ├── main.tsx
    │   ├── App.tsx
    │   ├── components/
    │   │   ├── HeaderMonitor.tsx        # LLM token, cost & TLS banner monitor
    │   │   ├── SettingsDrawer.tsx       # LiteLLM gateway config
    │   │   ├── AnalystConsole.tsx       # Dynamic domain-configured workspace
    │   │   ├── GroundingInspector.tsx   # Evidence & passage citations
    │   │   ├── KnowledgeGraphViewer.tsx # Interactive Cypher Graph Subgraph Viewer
    │   │   ├── PolicyGateMatrix.tsx     # Dynamic rule outcome matrix
    │   │   ├── HumanReviewDrawer.tsx    # Pause/resume review controls
    │   │   ├── MCPConsole.tsx           # Live MCP tool invocation log inspector
    │   │   ├── KnowledgeManager.tsx     # Document upload & vector store stats
    │   │   └── Dashboard.tsx            # KPI baseline vs AI metrics
    │   ├── services/                    # API clients with Zod parsing
    │   └── tokens/                      # Semantic design tokens (light/dark)
```





---

## Proposed Changes

### Component 1: Reusable Platform Core (`backend/app/core/`)

#### [NEW] [orchestrator.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/core/orchestrator.py)
- Build bounded LangGraph workflow managing state transitions across acquisition, retrieval, rule evaluation, action authorization, and human review interrupts.
- Support durable SQLite checkpoints for pause/resume state.

#### [NEW] [grounding.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/core/grounding.py)
- Embedded ChromaDB vector store manager (daemonless, local folder).
- Ingestion engine with line-level chunking, version metadata, effective date tracking, and injection protection wrappers.

#### [NEW] [policy_gate.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/core/policy_gate.py)
- Deterministic authorization gate evaluating active domain pack rules.
- Guarantees fail-closed behavior: any `FAIL`, `UNKNOWN`, `STALE`, or `CONFLICTING` check prevents automatic action.

#### [NEW] [gateway.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/core/gateway.py)
- LiteLLM gateway integration with LangChain provider-agnostic initialization (`init_chat_model`).
- Enforces model role mapping (`gemini-3.1-flash-lite`, `gemini-2.5-flash`, `gemini-2.5-pro`) and Pydantic structured output validation with retries and exponential backoff.

#### [NEW] [caching.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/core/caching.py)
- SQLite exact-match & guarded semantic cache.
- Key invalidation by policy version, prompt version, model ID, and freshness. Prohibits semantic caching of action execution results.

#### [NEW] [telemetry.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/core/telemetry.py)
- LangSmith tracing hook and structured JSON logger with automatic PII/payment identifier redaction.

#### [NEW] [pack_loader.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/core/pack_loader.py)
- Domain pack validator verifying schema compliance, rule completeness, and contract immutability before activation.

---

### Component 2: Banking Domain Pack (`backend/app/domain_packs/card_dispute/`)

#### [NEW] [pack.json](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/domain_packs/card_dispute/pack.json)
- Pack descriptor containing identity (`card_dispute_ops`), version (`1.0.0`), terminology mapping, and declared A2A skills.

#### [NEW] [schemas.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/domain_packs/card_dispute/schemas.py)
- Structured Pydantic contracts for Cardholder Intake, Transaction Facts, Evidence Assessment, Policy Check Items, and Mock Case Creation.

#### [NEW] [rules.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/domain_packs/card_dispute/rules.py)
- Machine-evaluable rules:
  1. `CONFIDENCE_THRESHOLD`: Model confidence ≥ configured policy threshold.
  2. `DISPUTE_WINDOW`: Transaction age ≤ 60 days.
  3. `NO_DUPLICATE_DISPUTE`: Zero active/previous disputes for transaction.
  4. `AUTO_ACTION_LIMIT`: Amount ≤ \$500.00.
  5. `IDENTITY_VERIFICATION`: Identity verification passed.
  6. `NO_EVIDENCE_CONFLICT`: Zero conflicting authentication/merchant signals.

#### [NEW] [fixtures/](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/domain_packs/card_dispute/fixtures/)
- Synthetic card transactions, customer profiles, dispute histories, authentication logs, and synthetic operating policy manual documents.

#### [NEW] [eval/benchmark.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/domain_packs/card_dispute/eval/benchmark.py)
- Evaluation harness verifying KPI targets:
  - 50%+ handling time reduction vs baseline script.
  - 90%+ policy-check accuracy.
  - 100% action traceability.
  - **0 false automatic case creations** (Release Gate).

---

### Component 3: API & Interoperability Tier (`backend/app/api/`)

#### [NEW] [disputes.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/api/disputes.py)
- Endpoints to fetch synthetic transactions, launch dispute investigation graph, retrieve state, submit human approval/rejection.

#### [NEW] [knowledge.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/api/knowledge.py)
- Policy manual upload, chunk viewing, vector embedding status, and search preview.

#### [NEW] [metrics.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/api/metrics.py)
- Aggregate telemetry API: active model calls, token usage, cost estimation, cache ratios, handling time comparison.

#### [NEW] [a2a.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/api/a2a.py)
- Implements `/.well-known/agent-card.json` and standards-aligned A2A dispute resolution skill invocation point.

---

### Component 4: Frontend Presentation Tier (`ui/`)

#### [NEW] [HeaderMonitor.tsx](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/ui/src/components/HeaderMonitor.tsx)
- Real-time status header showing active LLM requests, cumulative tokens, dollar cost, cache hit ratio, system health, and non-dismissible TLS alert banner.

#### [NEW] [InvestigationConsole.tsx](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/ui/src/components/InvestigationConsole.tsx)
- Primary analyst view with transaction selection, evidence view, policy citation matrix, policy gate status, and case outcome panel.

#### [NEW] [PolicyGateMatrix.tsx](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/ui/src/components/PolicyGateMatrix.tsx)
- Visual break-down of all 6 policy checks with status (PASS/FAIL/UNKNOWN), source passage links, and authorization state.

#### [NEW] [HumanReviewDrawer.tsx](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/ui/src/components/HumanReviewDrawer.tsx)
- Human-in-the-loop review panel for escalated cases with decision rationale and idempotency-guaranteed submit actions.

#### [NEW] [Dashboard.tsx](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/ui/src/components/Dashboard.tsx)
- Executive metrics dashboard visualizing baseline vs AI handling times, accuracy rates, cost metrics, and zero-erroneous-action metrics.

---

## Verification Plan

### Automated Tests
1. **Contract Tests (`test_core_isolation.py`)**: Validate that domain packs cannot bypass platform policy gates, audit logging, or grounding envelopes.
2. **Policy Gate Unit Tests (`test_policy_gate.py`)**: Test each of the 6 policy checks individually and in combinatorial edge cases (boundary amounts, stale policies, conflicting evidence).
3. **Idempotency & Resilience Tests (`test_idempotency.py`)**: Execute graph recovery across interrupted nodes to prove case creation occurs at most once.
4. **KPI Evaluation Suite (`eval/benchmark.py`)**: Run synthetic evaluation dataset to verify:
   - Policy-check accuracy ≥ 90%
   - Erroneous automatic creations = 0
   - Traceability coverage = 100%

### Manual Verification
1. **Auto-Eligible Dispute Flow**: Select synthetic transaction `TX-1001` (under limit, within 60 days, verified identity, clear policy) -> Verify automatic mock case creation.
2. **Escalated Dispute Flow**: Select synthetic transaction `TX-1002` (over limit or conflicting evidence) -> Verify auto-gate blocks, LangGraph pauses, human review drawer opens, and analyst manual decision resumes workflow cleanly.
3. **Grounding & Ingestion**: Upload a new synthetic operating manual -> Verify ingestion progress, vector chunking, and immediate updating of policy citation links.
4. **Header Monitor & Settings**: Change LiteLLM settings and enable TLS bypass -> Verify persistent warning badge appears and cost/token counters update in real-time.
