"""
FastAPI Main Application Entry Point.
Initializes domain packs, registers API routes, and seeds hybrid retrieval index on startup.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os

from backend.app.api.work_items import router as work_items_router
from backend.app.api.knowledge import router as knowledge_router
from backend.app.api.metrics import router as metrics_router
from backend.app.api.mcp_telemetry import router as mcp_router
from backend.app.api.settings import router as settings_router
from backend.app.api.a2a import router as a2a_router

from backend.app.core.domain_pack.registry import pack_registry
from backend.app.core.retrieval.ladybug_graph import ladybug_engine
from backend.app.core.retrieval.vector_store import vector_store
from backend.app.core.retrieval.sparse_search import sparse_search_engine

app = FastAPI(
    title="Adaptive Knowledge-to-Action Copilot",
    description="Domain-agnostic platform core with pluggable Domain Knowledge Packs.",
    version="1.0.0"
)

# Enable CORS for local Vite development frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register API Routers
app.include_router(work_items_router)
app.include_router(knowledge_router)
app.include_router(metrics_router)
app.include_router(mcp_router)
app.include_router(settings_router)
app.include_router(a2a_router)


@app.on_event("startup")
def startup_event():
    """Startup initialization: load graph triples & index policy documents."""
    active_pack = pack_registry.get_active_pack()
    
    # 1. Load Cypher triples into LadybugDB
    triples = active_pack.get_kg_triples()
    ladybug_engine.load_triples(triples)

    # 2. Seed policy document into Vector & Sparse store if empty
    if not vector_store.documents:
        policy_file = os.path.join(active_pack.pack_dir, "knowledge/card_dispute_policy_v2.md")
        if os.path.exists(policy_file):
            with open(policy_file, "r", encoding="utf-8") as f:
                text = f.read()
            blocks = text.split("\n\n")
            chunks = []
            for idx, block in enumerate(blocks):
                if block.strip():
                    sec_id = f"SEC-{idx+1}"
                    if "SEC-3.1" in block: sec_id = "POL-CARD-OPS-v2#SEC-3.1"
                    elif "SEC-4.2" in block: sec_id = "POL-CARD-OPS-v2#SEC-4.2"
                    elif "SEC-5.1" in block: sec_id = "POL-CARD-OPS-v2#SEC-5.1"
                    elif "SEC-6.4" in block: sec_id = "POL-CARD-OPS-v2#SEC-6.4"
                    elif "SEC-2.3" in block: sec_id = "POL-CARD-OPS-v2#SEC-2.3"
                    elif "SEC-7.8" in block: sec_id = "POL-CARD-OPS-v2#SEC-7.8"
                    
                    chunks.append({
                        "chunk_id": f"CHUNK-POL-CARD-OPS-{idx+1}",
                        "content": block.strip(),
                        "section_id": sec_id,
                        "source_passage_id": sec_id,
                        "version": "v2.0"
                    })
            vector_store.add_document_chunks("card_dispute_policy_v2.md", chunks)
            sparse_search_engine.index_documents(vector_store.documents)


@app.get("/health")
def health_check():
    active_pack = pack_registry.get_active_pack()
    return {
        "status": "healthy",
        "active_domain_pack": active_pack.manifest.domain_id,
        "pack_version": active_pack.manifest.version
    }
