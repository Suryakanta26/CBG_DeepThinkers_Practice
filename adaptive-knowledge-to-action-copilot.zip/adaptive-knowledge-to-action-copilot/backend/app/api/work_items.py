"""
Work Items REST API Routes.
Endpoints for transaction selection, workflow execution, state retrieval, and human review decisions.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
from mcp_server.data_store import SYNTHETIC_TRANSACTIONS
from backend.app.core.orchestrator import orchestrator, WORK_ITEM_STATES

router = APIRouter(prefix="/api/v1/work-items", tags=["Work Items"])


class StartInvestigationRequest(BaseModel):
    transaction_id: str
    cardholder_statement: Optional[str] = "I do not recognize this charge on my statement."


class ResumeReviewRequest(BaseModel):
    action: str  # APPROVE or REJECT
    notes: Optional[str] = ""


from backend.app.core.domain_pack.registry import pack_registry
from backend.app.core.retrieval.ladybug_graph import ladybug_engine
from backend.app.core.retrieval.vector_store import vector_store
from backend.app.core.retrieval.sparse_search import sparse_search_engine
import os


class SelectDomainPackRequest(BaseModel):
    domain_id: str


@router.get("/domain-packs")
def list_available_domain_packs():
    """List all registered Domain Knowledge Packs (Banking, Retail, etc.)."""
    return pack_registry.list_packs()


@router.post("/domain-packs/select")
def select_active_domain_pack(req: SelectDomainPackRequest):
    """Hot-swap the active Domain Knowledge Pack in real-time."""
    pack_registry.set_active_pack(req.domain_id)
    active_pack = pack_registry.get_active_pack()

    # 1. Reload LadybugDB Cypher Triples
    triples = active_pack.get_kg_triples()
    ladybug_engine.load_triples(triples)

    # 2. Re-index Knowledge Base
    vector_store.documents = []
    policy_dir = os.path.join(active_pack.pack_dir, "knowledge")
    if os.path.exists(policy_dir):
        for fname in os.listdir(policy_dir):
            if fname.endswith(".md"):
                fpath = os.path.join(policy_dir, fname)
                with open(fpath, "r", encoding="utf-8") as f:
                    text = f.read()
                blocks = text.split("\n\n")
                chunks = [
                    {
                        "chunk_id": f"{fname}_{i}",
                        "content": b.strip(),
                        "section_id": f"SEC-{i+1}",
                        "source_passage_id": f"{fname}#SEC-{i+1}",
                        "version": "v1.0"
                    }
                    for i, b in enumerate(blocks) if b.strip()
                ]
                vector_store.add_document_chunks(fname, chunks)
        sparse_search_engine.index_documents(vector_store.documents)

    return {
        "message": f"Successfully activated domain pack '{active_pack.manifest.name}'",
        "active_domain_id": active_pack.manifest.domain_id,
        "ui_config": active_pack.get_ui_config()
    }


@router.get("/ui-config")
def get_ui_config():
    """Retrieve active domain pack dynamic UI configuration."""
    active_pack = pack_registry.get_active_pack()
    return active_pack.get_ui_config()


@router.get("/synthetic-transactions")
def list_synthetic_transactions():
    """List synthetic transactions available for testing filtered by active domain."""
    active_pack = pack_registry.get_active_pack()
    all_tx = list(SYNTHETIC_TRANSACTIONS.values())
    if active_pack.manifest.domain_id == "retail_returns_ops":
        return [t for t in all_tx if t["transaction_id"].startswith("ORD-")]
    return [t for t in all_tx if t["transaction_id"].startswith("TX-")]


@router.post("/start")
def start_investigation(req: StartInvestigationRequest):
    """Launch LangGraph investigation workflow for target transaction."""
    try:
        state = orchestrator.start_investigation(req.transaction_id, req.cardholder_statement or "")
        return {
            "work_item_id": state.work_item_id,
            "status": state.status,
            "is_authorized": state.is_authorized,
            "decision_reason": state.decision_reason,
            "policy_check_matrix": state.policy_check_matrix,
            "evidence_assessment": state.evidence_assessment.model_dump() if state.evidence_assessment else None,
            "action_record": state.action_record,
            "grounding_envelope": state.grounding_envelope
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{work_item_id}")
def get_work_item_state(work_item_id: str):
    """Retrieve full execution state for a work item."""
    state = orchestrator.get_state(work_item_id)
    if not state:
        raise HTTPException(status_code=404, detail=f"Work item '{work_item_id}' not found.")
    
    return {
        "work_item_id": state.work_item_id,
        "transaction_id": state.transaction_id,
        "cardholder_statement": state.cardholder_statement,
        "status": state.status,
        "is_authorized": state.is_authorized,
        "decision_reason": state.decision_reason,
        "domain_facts": state.domain_facts.model_dump() if state.domain_facts else None,
        "policy_check_matrix": state.policy_check_matrix,
        "evidence_assessment": state.evidence_assessment.model_dump() if state.evidence_assessment else None,
        "action_record": state.action_record,
        "grounding_envelope": state.grounding_envelope,
        "human_review_notes": state.human_review_notes,
        "created_at": state.created_at,
        "updated_at": state.updated_at
    }


@router.post("/{work_item_id}/resume")
def resume_human_review(work_item_id: str, req: ResumeReviewRequest):
    """Submit human review decision (APPROVE/REJECT) to resume paused workflow."""
    try:
        state = orchestrator.resume_human_review(work_item_id, req.action, req.notes or "")
        return {
            "work_item_id": state.work_item_id,
            "status": state.status,
            "decision_reason": state.decision_reason,
            "action_record": state.action_record,
            "human_review_notes": state.human_review_notes
        }
    except KeyError:
        raise HTTPException(status_code=404, detail=f"Work item '{work_item_id}' not found.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
