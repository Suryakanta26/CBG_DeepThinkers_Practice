"""
Knowledge & Grounding REST API Routes.
Endpoints for policy manual document management, corpus statistics, and Cypher KG subgraphs.
"""

from fastapi import APIRouter, UploadFile, File
from typing import Dict, Any
from backend.app.core.retrieval.vector_store import vector_store
from backend.app.core.retrieval.sparse_search import sparse_search_engine
from backend.app.core.retrieval.ladybug_graph import ladybug_engine

router = APIRouter(prefix="/api/v1/knowledge", tags=["Knowledge & Graph"])


@router.get("/stats")
def get_corpus_stats():
    """Retrieve indexed document chunk count, vector store status, and graph nodes."""
    return {
        "vector_chunks_count": len(vector_store.documents),
        "ladybug_nodes_count": len(ladybug_engine.nodes),
        "ladybug_edges_count": len(ladybug_engine.edges),
        "graph_engine": "LadybugDB Property Graph (.lbug)",
        "vector_engine": "ChromaDB Embedded Vector Store"
    }


@router.get("/graph")
def get_knowledge_graph():
    """Retrieve full Cypher property graph node and edge representation."""
    return ladybug_engine.query_cypher("MATCH (n) RETURN n")


@router.post("/upload-policy")
async def upload_policy_document(file: UploadFile = File(...)):
    """Upload and index synthetic operating manual document."""
    content_bytes = await file.read()
    text = content_bytes.decode("utf-8", errors="ignore")
    
    # Simple chunking
    lines = text.split("\n\n")
    chunks = []
    for idx, block in enumerate(lines):
        if block.strip():
            chunks.append({
                "chunk_id": f"UPLOAD-{file.filename}-{idx}",
                "content": block.strip(),
                "section_id": f"SEC-{idx+1}",
                "source_passage_id": f"POL-UPLOAD-{file.filename}#SEC-{idx+1}",
                "version": "v1.0-USER_UPLOAD"
            })
    
    vector_store.add_document_chunks(file.filename, chunks)
    sparse_search_engine.index_documents(vector_store.documents)
    
    return {
        "filename": file.filename,
        "chunks_indexed": len(chunks),
        "status": "Policy document successfully embedded and indexed."
    }
