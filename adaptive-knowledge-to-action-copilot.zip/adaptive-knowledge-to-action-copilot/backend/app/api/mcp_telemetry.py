"""
MCP Telemetry REST API Routes.
Exposes live MCP tool invocation logs and registered MCP tools.
"""

from fastapi import APIRouter
from backend.app.core.mcp_client import mcp_client

router = APIRouter(prefix="/api/v1/mcp", tags=["MCP Telemetry"])


@router.get("/tools")
def list_mcp_tools():
    """List tools registered on the Mock MCP Server."""
    return mcp_client.discover_tools()


@router.get("/logs")
def get_mcp_invocation_logs():
    """Retrieve live MCP tool invocation history."""
    return mcp_client.get_telemetry_logs()
