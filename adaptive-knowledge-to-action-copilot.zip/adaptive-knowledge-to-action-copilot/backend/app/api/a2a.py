"""
A2A (Agent-to-Agent) Interoperability Protocol REST API Routes.
Exposes /.well-known/agent-card.json and agent skill invocation endpoint.
"""

from fastapi import APIRouter
from backend.app.core.domain_pack.registry import pack_registry

router = APIRouter(tags=["A2A Protocol"])


@router.get("/.well-known/agent-card.json")
def get_agent_card():
    """Returns dynamic A2A Agent Card based on active domain pack manifest."""
    active_pack = pack_registry.get_active_pack()
    manifest = active_pack.manifest
    
    return {
        "agent_name": manifest.name,
        "domain_id": manifest.domain_id,
        "version": manifest.version,
        "description": manifest.description,
        "protocol_version": "1.0",
        "skills": manifest.a2a_skills,
        "mcp_tool_bindings": manifest.mcp_tool_bindings,
        "security_policy": {
          "fail_closed_authorization": True,
          "requires_human_approval_on_exception": True
        }
    }
