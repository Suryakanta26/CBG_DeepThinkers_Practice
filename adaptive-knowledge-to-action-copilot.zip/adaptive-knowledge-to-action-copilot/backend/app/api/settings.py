"""
Settings & TLS Configuration REST API Routes.
Manages LiteLLM router credentials and TLS verification settings.
"""

from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from backend.app.core.gateway import model_gateway

router = APIRouter(prefix="/api/v1/settings", tags=["Settings"])


class UpdateSettingsRequest(BaseModel):
    primary_model: Optional[str] = None
    api_key: Optional[str] = None
    tls_verify: bool = True


@router.get("/")
def get_settings():
    return model_gateway.get_status()


@router.post("/")
def update_settings(req: UpdateSettingsRequest):
    model_gateway.update_settings(
        primary_model=req.primary_model or "",
        api_key=req.api_key or "",
        tls_verify=req.tls_verify
    )
    return model_gateway.get_status()
