"""
LiteLLM Router & Model Initializer Gateway.
Manages provider-agnostic model calls and LLM configuration settings.
"""

from typing import Dict, Any, Optional
import os


class ModelGateway:
    """LiteLLM Gateway Manager."""

    def __init__(self):
        self.primary_model = "gemini-3.1-flash-lite"
        self.fast_model = "gemini-2.5-flash"
        self.reasoning_model = "gemini-2.5-pro"
        self.api_key = os.getenv("LLM_API_KEY", "mock-litellm-key")
        self.tls_verify = True
        self.total_tokens_used = 0
        self.total_cost_usd = 0.0

    def update_settings(self, primary_model: str, api_key: str, tls_verify: bool):
        if primary_model:
            self.primary_model = primary_model
        if api_key:
            self.api_key = api_key
        self.tls_verify = tls_verify

    def get_status(self) -> Dict[str, Any]:
        return {
            "primary_model": self.primary_model,
            "fast_model": self.fast_model,
            "reasoning_model": self.reasoning_model,
            "tls_verify": self.tls_verify,
            "api_key_configured": bool(self.api_key and self.api_key != "mock-litellm-key"),
            "total_tokens": self.total_tokens_used,
            "estimated_cost_usd": round(self.total_cost_usd, 4)
        }

    def record_usage(self, prompt_tokens: int, completion_tokens: int, model_name: str = ""):
        total = prompt_tokens + completion_tokens
        self.total_tokens_used += total
        # Cost estimate: ~$0.00015 per 1K tokens
        self.total_cost_usd += (total / 1000.0) * 0.00015


# Singleton instance
model_gateway = ModelGateway()
