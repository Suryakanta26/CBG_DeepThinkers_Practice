"""
LangGraph Bounded Workflow Engine & Investigation State Machine.
Manages work item lifecycle state, 3-way hybrid retrieval, deterministic policy gate evaluation,
human-in-the-loop pause/resume interrupts, and action execution.
"""

from typing import Dict, Any, Optional, List
import uuid
import datetime

from backend.app.core.mcp_client import mcp_client
from backend.app.core.retrieval.hybrid_retriever import hybrid_retriever
from backend.app.core.policy_gate import policy_gate
from backend.app.core.actions import action_engine
from backend.app.core.gateway import model_gateway
from backend.app.domain_packs.card_dispute.schemas import (
    DomainFacts, TransactionFacts, CustomerVerificationFacts,
    DisputeHistoryFacts, AuthenticationLogFacts, EvidenceAssessment
)
from backend.app.domain_packs.card_dispute.rules import evaluate_all_rules


class WorkItemState:
    """Represents state of a WorkItem investigation graph execution."""

    def __init__(self, work_item_id: str, transaction_id: str, cardholder_statement: str):
        self.work_item_id = work_item_id
        self.transaction_id = transaction_id
        self.cardholder_statement = cardholder_statement
        self.status = "NEW"  # NEW, ACQUIRING_FACTS, GROUNDING, EVALUATING_GATE, AUTO_APPROVED, ESCALATED_HUMAN_REVIEW, ACTION_COMPLETED, REJECTED
        self.domain_facts: Optional[DomainFacts] = None
        self.grounding_envelope: Optional[Dict[str, Any]] = None
        self.evidence_assessment: Optional[EvidenceAssessment] = None
        self.policy_check_matrix: List[Dict[str, Any]] = []
        self.is_authorized: bool = False
        self.decision_reason: str = ""
        self.action_record: Optional[Dict[str, Any]] = None
        self.idempotency_key = f"IDEM-{transaction_id}-{uuid.uuid4().hex[:8]}"
        self.created_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self.updated_at = self.created_at
        self.human_review_notes: str = ""


# In-memory execution state store
WORK_ITEM_STATES: Dict[str, WorkItemState] = {}


class CopilotOrchestrator:
    """Orchestrates investigation workflow from intake to action execution."""

    def start_investigation(self, transaction_id: str, statement: str = "I do not recognize this charge on my statement.") -> WorkItemState:
        work_item_id = f"WORK-{transaction_id}-{uuid.uuid4().hex[:6]}"
        state = WorkItemState(work_item_id, transaction_id, statement)
        WORK_ITEM_STATES[work_item_id] = state

        # Step 1: Fact Acquisition via MCP Ingestion Tools
        state.status = "ACQUIRING_FACTS"
        tx_res = mcp_client.execute_tool("get_transaction_facts", {"transaction_id": transaction_id})
        
        if "error" in tx_res.get("result", {}):
            state.status = "REJECTED"
            state.decision_reason = f"Fact Acquisition Failed: {tx_res['result']['error']}"
            return state
        
        tx_data = tx_res["result"]["transaction"]
        cust_data = tx_res["result"]["customer"]
        auth_data = tx_res["result"]["auth_log"] or {}

        disp_res = mcp_client.execute_tool(
            "get_dispute_history",
            {"customer_id": cust_data["customer_id"], "transaction_id": transaction_id}
        )
        disp_data = disp_res["result"]

        domain_facts = DomainFacts(
            transaction=TransactionFacts(**tx_data),
            customer=CustomerVerificationFacts(**cust_data),
            dispute_history=DisputeHistoryFacts(**disp_data),
            auth_log=AuthenticationLogFacts(**auth_data)
        )
        state.domain_facts = domain_facts

        # Step 2: 3-Way Hybrid Retrieval & Grounding Envelope
        state.status = "GROUNDING"
        query = f"Dispute rules for {domain_facts.transaction.merchant_name} amount {domain_facts.transaction.amount}"
        envelope = hybrid_retriever.retrieve_grounding_envelope(query=query)
        state.grounding_envelope = envelope

        # Record LLM Gateway token simulation
        model_gateway.record_usage(prompt_tokens=450, completion_tokens=180)

        # Step 3: Evidence Assessment & Model Grounding Score
        confidence = 0.94 if not domain_facts.auth_log.conflicting_evidence_signals else 0.72
        assessment = EvidenceAssessment(
            classification="UNRECOGNIZED_CARD_TRANSACTION",
            confidence=confidence,
            summary=f"Dispute intake for {domain_facts.transaction.merchant_name} (${domain_facts.transaction.amount:.2f}).",
            conflicting_signals=domain_facts.auth_log.conflicting_evidence_signals,
            key_findings=[
                f"Transaction age: {domain_facts.transaction.transaction_age_days} days.",
                f"Merchant: {domain_facts.transaction.merchant_name}.",
                f"Identity state: {domain_facts.customer.identity_verification_status}."
            ],
            recommended_action="AUTO_APPROVE_DISPUTE" if confidence >= 0.85 else "ESCALATE_HUMAN_REVIEW"
        )
        state.evidence_assessment = assessment

        # Step 4: Deterministic Policy Authorization Gate Evaluation
        state.status = "EVALUATING_GATE"
        from backend.app.core.domain_pack.registry import pack_registry
        active_pack = pack_registry.get_active_pack()
        checks = active_pack.evaluate_rules(domain_facts, confidence)
        is_auth, reason, check_matrix = policy_gate.evaluate_gate(checks)
        
        state.is_authorized = is_auth
        state.decision_reason = reason
        state.policy_check_matrix = check_matrix

        # Step 5: Action Execution or Pause for Human Review
        if is_auth:
            state.status = "AUTO_APPROVED"
            action_res = action_engine.dispatch_mock_dispute_case(
                transaction_id=transaction_id,
                dispute_reason="UNRECOGNIZED_CARD_TRANSACTION",
                amount=domain_facts.transaction.amount,
                idempotency_key=state.idempotency_key,
                authorized_by="DETERMINISTIC_POLICY_AUTO_GATE"
            )
            state.action_record = action_res.get("result", {}).get("case_record")
            state.status = "ACTION_COMPLETED"
        else:
            state.status = "ESCALATED_HUMAN_REVIEW"

        state.updated_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        return state

    def resume_human_review(self, work_item_id: str, action: str, analyst_notes: str = "") -> WorkItemState:
        """Resumes an escalated workflow following analyst review."""
        if work_item_id not in WORK_ITEM_STATES:
            raise KeyError(f"Work item '{work_item_id}' not found.")

        state = WORK_ITEM_STATES[work_item_id]
        state.human_review_notes = analyst_notes

        if action == "APPROVE":
            action_res = action_engine.dispatch_mock_dispute_case(
                transaction_id=state.transaction_id,
                dispute_reason="UNRECOGNIZED_CARD_TRANSACTION_ANALYST_OVERRIDE",
                amount=state.domain_facts.transaction.amount if state.domain_facts else 0.0,
                idempotency_key=state.idempotency_key,
                authorized_by=f"HUMAN_ANALYST_REVIEW: {analyst_notes}"
            )
            state.action_record = action_res.get("result", {}).get("case_record")
            state.status = "ACTION_COMPLETED"
            state.decision_reason = f"HUMAN_APPROVED: Analyst override approved case creation. Notes: {analyst_notes}"
        else:
            state.status = "REJECTED"
            state.decision_reason = f"HUMAN_REJECTED: Analyst declined dispute case creation. Notes: {analyst_notes}"

        state.updated_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
        return state

    def get_state(self, work_item_id: str) -> Optional[WorkItemState]:
        return WORK_ITEM_STATES.get(work_item_id)


# Singleton instance
orchestrator = CopilotOrchestrator()
