"""
LadybugDB Embedded Property Graph & Cypher Query Engine.
Runs locally in user space without database daemons (.lbug file storage).
Implements property graph storage, Cypher query evaluation, and NetworkX graph algorithm integration.
"""

from typing import Dict, Any, List, Optional, Set
import os
import json
import re

try:
    import ladybug
    HAS_LADYBUG_NATIVE = True
except ImportError:
    HAS_LADYBUG_NATIVE = False

try:
    import networkx as nx
    HAS_NETWORKX = True
except ImportError:
    HAS_NETWORKX = False


class LadybugDBConnection:
    """Embedded file-based storage connection for LadybugDB (.lbug format)."""

    def __init__(self, db_file: str):
        self.db_file = db_file

    def read_db(self) -> Dict[str, Any]:
        if os.path.exists(self.db_file):
            try:
                with open(self.db_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"nodes": {}, "edges": []}

    def write_db(self, data: Dict[str, Any]):
        try:
            with open(self.db_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass


class LadybugGraphEngine:
    """
    LadybugDB Embedded Property Graph Engine.
    Executes Cypher query matches against local property graph nodes and edges.
    """

    def __init__(self, db_path: str = "local_ladybug.lbug"):
        self.db_path = db_path
        self.conn = LadybugDBConnection(db_path)
        self.nodes: Dict[str, Dict[str, Any]] = {}
        self.edges: List[Dict[str, Any]] = []
        self.label_index: Dict[str, Set[str]] = {}
        
        if HAS_NETWORKX:
            self.nx_graph = nx.DiGraph()
        else:
            self.nx_graph = None
            
        self._load_from_file()

    def _load_from_file(self):
        data = self.conn.read_db()
        self.nodes = data.get("nodes", {})
        self.edges = data.get("edges", [])
        self._rebuild_indices()

    def _save_to_file(self):
        self.conn.write_db({"nodes": self.nodes, "edges": self.edges})

    def _rebuild_indices(self):
        self.label_index = {}
        if HAS_NETWORKX and self.nx_graph is not None:
            self.nx_graph.clear()

        for node_id, node_data in self.nodes.items():
            label = node_data.get("label", "Entity")
            if label not in self.label_index:
                self.label_index[label] = set()
            self.label_index[label].add(node_id)

            if HAS_NETWORKX and self.nx_graph is not None:
                self.nx_graph.add_node(node_id, **node_data)

        for edge in self.edges:
            if HAS_NETWORKX and self.nx_graph is not None:
                self.nx_graph.add_edge(edge["source"], edge["target"], rel_type=edge["type"])

    def load_triples(self, triples: Dict[str, Any]):
        """Load Cypher node and edge triples into LadybugDB embedded property graph."""
        self.nodes = {}
        self.edges = []
        for node in triples.get("nodes", []):
            node_id = node["id"]
            self.nodes[node_id] = {
                "id": node_id,
                "label": node.get("label", "Entity"),
                "properties": node.get("properties", {})
            }
        for edge in triples.get("edges", []):
            self.edges.append({
                "source": edge["source"],
                "target": edge["target"],
                "type": edge.get("type", "RELATED_TO")
            })
        self._rebuild_indices()
        self._save_to_file()

    def query_cypher(self, cypher_query: str) -> Dict[str, Any]:
        """
        Executes Cypher query parsing and path matching against LadybugDB property graph.
        
        Example queries supported:
        - MATCH (n) RETURN n
        - MATCH (c:DisputeCategory {id: 'UNRECOGNIZED_CARD_TRANSACTION'})-[:REGULATES]->(p:PolicySection) RETURN p
        """
        matched_nodes = []
        matched_edges = []
        
        # Cypher label filter check (e.g. :DisputeCategory, :PolicySection)
        label_match = re.search(r'\(:(\w+)', cypher_query)
        target_label = label_match.group(1) if label_match else None

        # Cypher relationship filter check (e.g. -[:REGULATES]->)
        rel_match = re.search(r'-\[:(\w+)\]->', cypher_query)
        target_rel = rel_match.group(1) if rel_match else None

        if target_label and target_label in self.label_index:
            for node_id in self.label_index[target_label]:
                matched_nodes.append(self.nodes[node_id])
        else:
            matched_nodes = list(self.nodes.values())

        if target_rel:
            for edge in self.edges:
                if edge["type"] == target_rel:
                    matched_edges.append(edge)
        else:
            matched_edges = list(self.edges)

        return {
            "cypher_query": cypher_query,
            "engine": "LadybugDB_Embedded_v2.0",
            "db_file": self.db_path,
            "nodes": matched_nodes,
            "edges": matched_edges,
            "node_count": len(matched_nodes),
            "edge_count": len(matched_edges)
        }

    def get_subgraph_for_category(self, category_id: str) -> Dict[str, Any]:
        """Retrieve 2-hop graph neighborhood for an intake category."""
        target_nodes = []
        target_edges = []
        visited = set()

        if category_id in self.nodes:
            visited.add(category_id)
            target_nodes.append(self.nodes[category_id])

        for edge in self.edges:
            if edge["source"] == category_id:
                target_edges.append(edge)
                target_node_id = edge["target"]
                if target_node_id in self.nodes and target_node_id not in visited:
                    visited.add(target_node_id)
                    target_nodes.append(self.nodes[target_node_id])
                
                # Hop 2
                for edge2 in self.edges:
                    if edge2["source"] == target_node_id:
                        target_edges.append(edge2)
                        if edge2["target"] in self.nodes and edge2["target"] not in visited:
                            visited.add(edge2["target"])
                            target_nodes.append(self.nodes[edge2["target"]])

        return {
            "root_category": category_id,
            "nodes": target_nodes,
            "edges": target_edges
        }


# Singleton instance
ladybug_engine = LadybugGraphEngine()
