"""
Embedded Vector Store Manager (ChromaDB / Cosine Similarity).
Runs locally in user space without database daemons or external servers.
"""

from typing import List, Dict, Any, Optional
import math
import os
import json


def _simple_text_embedding(text: str) -> List[float]:
    """Lightweight deterministic text embedding generator for daemonless local runtime."""
    words = text.lower().split()
    vector = [0.0] * 64
    for word in words:
        for i, char in enumerate(word[:10]):
            vector[(ord(char) * (i + 1)) % 64] += 1.0
    norm = math.sqrt(sum(x * x for x in vector)) or 1.0
    return [x / norm for x in vector]


def _cosine_similarity(v1: List[float], v2: List[float]) -> float:
    dot = sum(a * b for a, b in zip(v1, v2))
    return max(0.0, min(1.0, dot))


class VectorStoreManager:
    """Embedded Vector Store for policy document chunk retrieval."""

    def __init__(self, persist_dir: str = "local_vector_db"):
        self.persist_dir = persist_dir
        self.documents: List[Dict[str, Any]] = []
        self._load_index()

    def _load_index(self):
        index_file = os.path.join(self.persist_dir, "index.json")
        if os.path.exists(index_file):
            try:
                with open(index_file, "r", encoding="utf-8") as f:
                    self.documents = json.load(f)
            except Exception:
                pass

    def _save_index(self):
        os.makedirs(self.persist_dir, exist_ok=True)
        index_file = os.path.join(self.persist_dir, "index.json")
        try:
            with open(index_file, "w", encoding="utf-8") as f:
                json.dump(self.documents, f, indent=2)
        except Exception:
            pass

    def add_document_chunks(self, document_id: str, chunks: List[Dict[str, Any]]):
        """Add policy document chunks with embeddings."""
        for chunk in chunks:
            text = chunk["content"]
            emb = _simple_text_embedding(text)
            self.documents.append({
                "chunk_id": chunk.get("chunk_id", f"{document_id}_{len(self.documents)}"),
                "document_id": document_id,
                "content": text,
                "section_id": chunk.get("section_id", "GENERAL"),
                "source_passage_id": chunk.get("source_passage_id", "POL-DOC#SEC-1"),
                "version": chunk.get("version", "1.0"),
                "embedding": emb
            })
        self._save_index()

    def search_dense(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Perform dense vector similarity search."""
        if not self.documents:
            return []
        
        q_emb = _simple_text_embedding(query)
        scored = []
        for doc in self.documents:
            sim = _cosine_similarity(q_emb, doc["embedding"])
            scored.append({
                "chunk_id": doc["chunk_id"],
                "content": doc["content"],
                "section_id": doc["section_id"],
                "source_passage_id": doc["source_passage_id"],
                "vector_score": float(sim)
            })
        
        scored.sort(key=lambda x: x["vector_score"], reverse=True)
        return scored[:top_k]


# Singleton instance
vector_store = VectorStoreManager()
