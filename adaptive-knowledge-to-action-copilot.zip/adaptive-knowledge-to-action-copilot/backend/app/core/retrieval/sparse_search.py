"""
BM25 Keyword Search Engine.
Provides sparse keyword matching for exact policy identifiers and terms.
"""

from typing import List, Dict, Any
import math
from collections import Counter


class BM25SparseSearchEngine:
    """BM25 sparse keyword search implementation."""

    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self.documents: List[Dict[str, Any]] = []
        self.doc_len: List[int] = []
        self.avg_doc_len: float = 0.0
        self.doc_freqs: List[Counter] = []
        self.idf: Dict[str, float] = {}

    def index_documents(self, documents: List[Dict[str, Any]]):
        self.documents = documents
        self.doc_len = [len(doc["content"].lower().split()) for doc in documents]
        self.avg_doc_len = sum(self.doc_len) / len(self.doc_len) if self.doc_len else 1.0
        
        self.doc_freqs = [Counter(doc["content"].lower().split()) for doc in documents]
        
        df = Counter()
        for freqs in self.doc_freqs:
            for word in freqs.keys():
                df[word] += 1
                
        num_docs = len(documents)
        self.idf = {}
        for word, count in df.items():
            self.idf[word] = math.log((num_docs - count + 0.5) / (count + 0.5) + 1.0)

    def search_sparse(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        if not self.documents:
            return []
        
        q_words = query.lower().split()
        scores = [0.0] * len(self.documents)
        
        for i, doc_freq in enumerate(self.doc_freqs):
            dl = self.doc_len[i]
            score = 0.0
            for word in q_words:
                if word in doc_freq:
                    freq = doc_freq[word]
                    word_idf = self.idf.get(word, 0.5)
                    num = freq * (self.k1 + 1)
                    denom = freq + self.k1 * (1 - self.b + self.b * (dl / self.avg_doc_len))
                    score += word_idf * (num / denom)
            scores[i] = score

        results = []
        for i, doc in enumerate(self.documents):
            results.append({
                "chunk_id": doc["chunk_id"],
                "content": doc["content"],
                "section_id": doc["section_id"],
                "source_passage_id": doc["source_passage_id"],
                "bm25_score": float(scores[i])
            })
            
        results.sort(key=lambda x: x["bm25_score"], reverse=True)
        return results[:top_k]


# Singleton instance
sparse_search_engine = BM25SparseSearchEngine()
