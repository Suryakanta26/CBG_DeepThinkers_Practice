"""
3-Way Hybrid Search Retriever & Reciprocal Rank Fusion (RRF) Engine.
Combines Dense Vector (ChromaDB), Sparse Keyword (BM25), and Cypher Graph (LadybugDB).
"""

from typing import List, Dict, Any
from backend.app.core.retrieval.vector_store import vector_store
from backend.app.core.retrieval.sparse_search import sparse_search_engine
from backend.app.core.retrieval.ladybug_graph import ladybug_engine


class HybridRetriever:
    """Orchestrates 3-way hybrid search and builds grounded evidence envelopes."""

    def __init__(self, rrf_k: int = 60):
        self.rrf_k = rrf_k

    def reciprocal_rank_fusion(
        self,
        dense_results: List[Dict[str, Any]],
        sparse_results: List[Dict[str, Any]],
        top_n: int = 5
    ) -> List[Dict[str, Any]]:
        """Combine dense and sparse search rankings via Reciprocal Rank Fusion."""
        rrf_scores: Dict[str, float] = {}
        content_map: Dict[str, Dict[str, Any]] = {}

        for rank, item in enumerate(dense_results):
            cid = item["chunk_id"]
            content_map[cid] = item
            rrf_scores[cid] = rrf_scores.get(cid, 0.0) + (1.0 / (self.rrf_k + rank + 1))

        for rank, item in enumerate(sparse_results):
            cid = item["chunk_id"]
            if cid not in content_map:
                content_map[cid] = item
            rrf_scores[cid] = rrf_scores.get(cid, 0.0) + (1.0 / (self.rrf_k + rank + 1))

        sorted_cids = sorted(rrf_scores.keys(), key=lambda x: rrf_scores[x], reverse=True)
        
        fused = []
        for cid in sorted_cids[:top_n]:
            entry = dict(content_map[cid])
            entry["rrf_score"] = float(rrf_scores[cid])
            fused.append(entry)

        return fused

    def retrieve_grounding_envelope(
        self,
        query: str,
        category_id: str = "UNRECOGNIZED_CARD_TRANSACTION",
        top_k: int = 5
    ) -> Dict[str, Any]:
        """
        Executes 3-way hybrid retrieval:
        1. Vector search (ChromaDB)
        2. Sparse search (BM25)
        3. LadybugDB Cypher graph traversal
        Returns unified evidence envelope with citations and subgraph.
        """
        dense_res = vector_store.search_dense(query, top_k=top_k)
        sparse_res = sparse_search_engine.search_sparse(query, top_k=top_k)
        fused_passages = self.reciprocal_rank_fusion(dense_res, sparse_res, top_n=top_k)
        
        # Cypher graph traversal
        cypher_query = f"MATCH (c:DisputeCategory {{id: '{category_id}'}})-[:REGULATES]->(p:PolicySection)-[:REQUIRES_CHECK]->(r:RuleCondition) RETURN p, r"
        graph_subgraph = ladybug_engine.get_subgraph_for_category(category_id)

        citations = []
        for item in fused_passages:
            citations.append({
                "source_passage_id": item.get("source_passage_id", "POL-CARD-OPS-v2#SEC-1"),
                "content": item.get("content", ""),
                "rrf_score": item.get("rrf_score", 0.0)
            })

        return {
            "query": query,
            "fused_passages": fused_passages,
            "citations": citations,
            "cypher_query": cypher_query,
            "graph_subgraph": graph_subgraph,
            "evidence_count": len(fused_passages)
        }


# Singleton instance
hybrid_retriever = HybridRetriever()
