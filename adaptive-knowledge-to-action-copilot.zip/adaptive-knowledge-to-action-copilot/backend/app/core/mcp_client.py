"""
Core MCP Client Adapter.
Connects the domain-agnostic platform core to the standalone Mock MCP Server.
"""

from typing import Dict, Any, List
from mcp_server.server import mcp_server_instance


class MCPClient:
    """Core Client bridging platform requests to the Mock MCP Server."""

    def __init__(self):
        self.server = mcp_server_instance
        self.invocation_logs: List[Dict[str, Any]] = []

    def discover_tools(self) -> List[Dict[str, Any]]:
        return self.server.list_tools()

    def execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Execute tool on MCP Server and log telemetry."""
        response = self.server.call_tool(tool_name, arguments)
        
        log_entry = {
            "tool_name": tool_name,
            "arguments": arguments,
            "response": response,
            "status": response.get("status", "unknown")
        }
        self.invocation_logs.append(log_entry)
        return response

    def get_telemetry_logs(self, limit: int = 50) -> List[Dict[str, Any]]:
        return self.invocation_logs[-limit:]


# Singleton instance
mcp_client = MCPClient()
