"""
Deterministic Policy Authorization Gate.
Evaluates machine-evaluable domain rules and enforces fail-closed authorization.
Model confidence is necessary but NEVER sufficient to authorize automatic action.
"""

from typing import List, Dict, Any, Tuple
from backend.app.domain_packs.card_dispute.schemas import PolicyCheckItem


class PolicyAuthorizationGate:
    """Deterministic Authorization Gate enforcing strict non-bypass safety rules."""

    def evaluate_gate(
        self,
        checks: List[PolicyCheckItem]
    ) -> Tuple[bool, str, List[Dict[str, Any]]]:
        """
        Evaluates list of policy check items.
        Returns:
            - is_authorized (bool): True ONLY if ALL checks have status == 'PASS'.
            - decision_reason (str): Summary reason for approval or escalation.
            - check_matrix (list): Formatted check details for UI matrix.
        """
        check_matrix = []
        failed_checks = []
        conflicting_checks = []
        unknown_checks = []

        for check in checks:
            check_data = {
                "rule_id": check.rule_id,
                "rule_name": check.rule_name,
                "status": check.status,
                "details": check.details,
                "source_passage_id": check.source_passage_id,
                "policy_citation": check.policy_citation
            }
            check_matrix.append(check_data)

            if check.status == "FAIL":
                failed_checks.append(check.rule_name)
            elif check.status == "CONFLICTING":
                conflicting_checks.append(check.rule_name)
            elif check.status == "UNKNOWN":
                unknown_checks.append(check.rule_name)

        if not failed_checks and not conflicting_checks and not unknown_checks:
            return True, "AUTO_AUTHORIZED: All 6 deterministic policy rules PASSED.", check_matrix
        
        reasons = []
        if failed_checks:
            reasons.append(f"Failed policy checks: {', '.join(failed_checks)}")
        if conflicting_checks:
            reasons.append(f"Conflicting signals detected in: {', '.join(conflicting_checks)}")
        if unknown_checks:
            reasons.append(f"Incomplete/Unknown checks: {', '.join(unknown_checks)}")

        reason_str = "HUMAN_REVIEW_ESCALATION: " + "; ".join(reasons)
        return False, reason_str, check_matrix


# Singleton instance
policy_gate = PolicyAuthorizationGate()
