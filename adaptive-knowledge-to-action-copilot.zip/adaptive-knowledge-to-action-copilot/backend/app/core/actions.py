"""
Idempotent Action Engine.
Executes approved domain actions via MCP protocol with idempotency protection.
"""

from typing import Dict, Any
from backend.app.core.mcp_client import mcp_client


class ActionExecutionEngine:
    """Executes authorized actions via MCP protocol."""

    def dispatch_mock_dispute_case(
        self,
        transaction_id: str,
        dispute_reason: str,
        amount: float,
        idempotency_key: str,
        authorized_by: str
    ) -> Dict[str, Any]:
        """Dispatch mock dispute case creation to MCP Server."""
        args = {
            "transaction_id": transaction_id,
            "dispute_reason": dispute_reason,
            "amount": amount,
            "idempotency_key": idempotency_key,
            "authorized_by": authorized_by
        }
        return mcp_client.execute_tool("create_mock_dispute_case", args)


# Singleton instance
action_engine = ActionExecutionEngine()
