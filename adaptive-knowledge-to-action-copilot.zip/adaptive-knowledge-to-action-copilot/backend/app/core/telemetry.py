"""
LangSmith Tracing Hook & Redacted Telemetry Logger.
Redacts PII, payment card numbers, and auth credentials.
"""

import re
import json
import logging
from typing import Dict, Any

logger = logging.getLogger("copilot_telemetry")
logger.setLevel(logging.INFO)


def redact_pii(text: str) -> str:
    """Redacts card numbers, SSNs, and email addresses."""
    # Redact 16-digit card numbers
    text = re.sub(r'\b(?:\d[ -]*?){13,16}\b', '[REDACTED_CARD_NUMBER]', text)
    # Redact SSN
    text = re.sub(r'\b\d{3}-\d{2}-\d{4}\b', '[REDACTED_SSN]', text)
    # Redact emails
    text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '[REDACTED_EMAIL]', text)
    return text


def log_telemetry_event(event_type: str, data: Dict[str, Any]):
    """Logs structured telemetry event with PII redaction."""
    json_str = json.dumps(data, default=str)
    redacted_json = redact_pii(json_str)
    logger.info(f"[TELEMETRY::{event_type}] {redacted_json}")
