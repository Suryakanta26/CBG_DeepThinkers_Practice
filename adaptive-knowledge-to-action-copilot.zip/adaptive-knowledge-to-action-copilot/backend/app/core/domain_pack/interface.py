"""
Base Abstract Interface for Domain Knowledge Packs.
Enforces domain neutrality of platform core.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List
from pydantic import BaseModel


class DomainPackManifestModel(BaseModel):
    domain_id: str
    name: str
    version: str
    description: str
    active: bool = True
    required_facts_schema: str
    default_llm_confidence_threshold: float = 0.85
    mcp_tool_bindings: Dict[str, List[str]]
    a2a_skills: List[Dict[str, Any]] = []


class BaseDomainPack(ABC):
    """Abstract base class that all Domain Knowledge Packs must implement."""

    @property
    @abstractmethod
    def manifest(self) -> DomainPackManifestModel:
        pass

    @abstractmethod
    def evaluate_rules(self, facts: Any, confidence: float) -> List[Any]:
        pass

    @abstractmethod
    def get_prompts(self) -> Dict[str, str]:
        pass

    @abstractmethod
    def get_kg_triples(self) -> Dict[str, Any]:
        pass

    @abstractmethod
    def get_ui_config(self) -> Dict[str, Any]:
        pass
