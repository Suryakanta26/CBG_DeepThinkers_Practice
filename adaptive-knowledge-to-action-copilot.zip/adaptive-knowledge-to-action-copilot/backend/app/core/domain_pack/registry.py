"""
Domain Knowledge Pack Registry and Loader.
Validates, loads, and manages active domain knowledge packs.
Supports dynamic hot-swapping between Banking (Card Dispute) and Retail (Returns & Refunds).
"""

import json
import os
from typing import Dict, Any, Optional, List
from backend.app.core.domain_pack.interface import DomainPackManifestModel
from backend.app.domain_packs.card_dispute.rules import evaluate_all_rules as evaluate_card_rules
from backend.app.domain_packs.card_dispute.schemas import DomainFacts as CardDomainFacts

from backend.app.domain_packs.retail_returns.rules import evaluate_all_retail_rules
from backend.app.domain_packs.retail_returns.schemas import DomainFacts as RetailDomainFacts


class CardDisputeDomainPackWrapper:
    """Banking Card Dispute Domain Pack Implementation Wrapper."""

    def __init__(self, pack_dir: str):
        self.pack_dir = pack_dir
        self._manifest = self._load_manifest()

    def _load_manifest(self) -> DomainPackManifestModel:
        manifest_path = os.path.join(self.pack_dir, "manifest.json")
        with open(manifest_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return DomainPackManifestModel(**data)

    @property
    def manifest(self) -> DomainPackManifestModel:
        return self._manifest

    def evaluate_rules(self, facts: CardDomainFacts, confidence: float) -> List[Any]:
        threshold = self._manifest.default_llm_confidence_threshold
        return evaluate_card_rules(facts, confidence, confidence_threshold=threshold)

    def get_prompts(self) -> Dict[str, str]:
        from backend.app.domain_packs.card_dispute.prompts import SYSTEM_GROUNDING_PROMPT, CLASSIFICATION_PROMPT_TEMPLATE
        return {
            "system_grounding": SYSTEM_GROUNDING_PROMPT,
            "classification_template": CLASSIFICATION_PROMPT_TEMPLATE
        }

    def get_kg_triples(self) -> Dict[str, Any]:
        kg_path = os.path.join(self.pack_dir, "kg_triples.json")
        if os.path.exists(kg_path):
            with open(kg_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"nodes": [], "edges": []}

    def get_ui_config(self) -> Dict[str, Any]:
        ui_path = os.path.join(self.pack_dir, "ui_config.json")
        if os.path.exists(ui_path):
            with open(ui_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}


class RetailReturnsDomainPackWrapper:
    """Retail Returns & Refund Operations Domain Pack Implementation Wrapper."""

    def __init__(self, pack_dir: str):
        self.pack_dir = pack_dir
        self._manifest = self._load_manifest()

    def _load_manifest(self) -> DomainPackManifestModel:
        manifest_path = os.path.join(self.pack_dir, "manifest.json")
        with open(manifest_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return DomainPackManifestModel(**data)

    @property
    def manifest(self) -> DomainPackManifestModel:
        return self._manifest

    def evaluate_rules(self, facts: Any, confidence: float) -> List[Any]:
        threshold = self._manifest.default_llm_confidence_threshold
        return evaluate_all_retail_rules(facts, confidence, confidence_threshold=threshold)

    def get_prompts(self) -> Dict[str, str]:
        return {
            "system_grounding": "You are a Retail Returns & Refund Operations Copilot AI.",
            "classification_template": "Analyze customer order facts and return policy eligibility."
        }

    def get_kg_triples(self) -> Dict[str, Any]:
        kg_path = os.path.join(self.pack_dir, "kg_triples.json")
        if os.path.exists(kg_path):
            with open(kg_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"nodes": [], "edges": []}

    def get_ui_config(self) -> Dict[str, Any]:
        ui_path = os.path.join(self.pack_dir, "ui_config.json")
        if os.path.exists(ui_path):
            with open(ui_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}


class PackRegistry:
    """Registry to load and hold active domain knowledge packs."""

    def __init__(self):
        self._packs: Dict[str, Any] = {}
        self._active_pack_id: Optional[str] = None

    def register_pack(self, pack_id: str, pack: Any):
        self._packs[pack_id] = pack
        if not self._active_pack_id and pack.manifest.active:
            self._active_pack_id = pack_id

    def set_active_pack(self, pack_id: str):
        if pack_id not in self._packs:
            raise ValueError(f"Pack '{pack_id}' is not registered.")
        if not self._packs[pack_id].manifest.active:
            raise ValueError(f"Pack '{pack_id}' is disabled in its manifest (active: false).")
        self._active_pack_id = pack_id

    def get_active_pack(self) -> Any:
        if not self._active_pack_id or self._active_pack_id not in self._packs:
            # Fallback to first active pack
            for p in self._packs.values():
                if p.manifest.active:
                    self._active_pack_id = p.manifest.domain_id
                    return p
            raise RuntimeError("No active domain pack loaded.")
        return self._packs[self._active_pack_id]

    def list_packs(self) -> List[Dict[str, Any]]:
        return [
            {
                "domain_id": p.manifest.domain_id,
                "name": p.manifest.name,
                "version": p.manifest.version,
                "active": p.manifest.active,
                "is_active": p.manifest.domain_id == self._active_pack_id
            }
            for p in self._packs.values()
        ]


# Singleton instance
pack_registry = PackRegistry()

# Initialize Banking Card Dispute Pack
card_dispute_dir = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "../../domain_packs/card_dispute")
)
if os.path.exists(card_dispute_dir):
    card_pack = CardDisputeDomainPackWrapper(card_dispute_dir)
    pack_registry.register_pack(card_pack.manifest.domain_id, card_pack)

# Initialize Retail Returns Pack
retail_dir = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "../../domain_packs/retail_returns")
)
if os.path.exists(retail_dir):
    retail_pack = RetailReturnsDomainPackWrapper(retail_dir)
    pack_registry.register_pack(retail_pack.manifest.domain_id, retail_pack)
