"""
SQLite Exact & Guarded Semantic Cache Manager.
Manages prompt/retrieval response caching. Action executions are strictly non-cacheable.
"""

import sqlite3
import os
import json
from typing import Optional, Dict, Any


class CacheManager:
    """Exact-match SQLite cache store with version invalidation."""

    def __init__(self, db_path: str = "cache_store.db"):
        self.db_path = db_path
        self.hits = 0
        self.misses = 0
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS response_cache (
                cache_key TEXT PRIMARY KEY,
                response_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        conn.close()

    def get(self, cache_key: str) -> Optional[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("SELECT response_json FROM response_cache WHERE cache_key = ?", (cache_key,))
        row = cur.fetchone()
        conn.close()
        
        if row:
            self.hits += 1
            return json.loads(row[0])
        else:
            self.misses += 1
            return None

    def set(self, cache_key: str, response_data: Dict[str, Any]):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute(
            "INSERT OR REPLACE INTO response_cache (cache_key, response_json) VALUES (?, ?)",
            (cache_key, json.dumps(response_data))
        )
        conn.commit()
        conn.close()

    def stats(self) -> Dict[str, Any]:
        total = self.hits + self.misses
        ratio = (self.hits / total * 100.0) if total > 0 else 0.0
        return {
            "cache_hits": self.hits,
            "cache_misses": self.misses,
            "hit_ratio_pct": round(ratio, 2)
        }


# Singleton instance
cache_manager = CacheManager()
