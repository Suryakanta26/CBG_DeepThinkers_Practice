"""
Reviewed machine-evaluable operating policy rules for Card Dispute Domain Pack.
Evaluates domain facts against versioned policy limits.
"""

from typing import List, Dict, Any
from backend.app.domain_packs.card_dispute.schemas import DomainFacts, PolicyCheckItem


def evaluate_confidence_threshold(facts: DomainFacts, confidence: float, threshold: float = 0.85) -> PolicyCheckItem:
    passed = confidence >= threshold
    status = "PASS" if passed else "FAIL"
    return PolicyCheckItem(
        rule_id="RULE-001-CONFIDENCE",
        rule_name="Model Grounding Confidence Threshold",
        status=status,
        details=f"Model confidence score {confidence:.2f} (Required: ≥ {threshold:.2f})",
        source_passage_id="POL-CARD-OPS-v2#SEC-3.1",
        policy_citation="Section 3.1: Model assessment confidence must equal or exceed 0.85 for automated case processing."
    )


def evaluate_dispute_window(facts: DomainFacts) -> PolicyCheckItem:
    age_days = facts.transaction.transaction_age_days
    max_days = 60
    passed = age_days <= max_days
    status = "PASS" if passed else "FAIL"
    return PolicyCheckItem(
        rule_id="RULE-002-DISPUTE_WINDOW",
        rule_name="Dispute Filing Time Window (≤ 60 Days)",
        status=status,
        details=f"Transaction age: {age_days} days (Maximum allowed: {max_days} days)",
        source_passage_id="POL-CARD-OPS-v2#SEC-4.2",
        policy_citation="Section 4.2: Unrecognized transaction dispute reports must be submitted within 60 calendar days of transaction settlement date."
    )


def evaluate_no_duplicate_dispute(facts: DomainFacts) -> PolicyCheckItem:
    is_dup = facts.dispute_history.is_duplicate_for_transaction
    status = "PASS" if not is_dup else "FAIL"
    return PolicyCheckItem(
        rule_id="RULE-003-NO_DUPLICATE",
        rule_name="Duplicate Dispute Filing Check",
        status=status,
        details="Zero prior disputes found for transaction" if not is_dup else "Duplicate active dispute case already registered for transaction",
        source_passage_id="POL-CARD-OPS-v2#SEC-5.1",
        policy_citation="Section 5.1: Multiple active dispute filings against a single settled transaction ID are strictly prohibited."
    )


def evaluate_auto_action_limit(facts: DomainFacts, max_amount: float = 500.0) -> PolicyCheckItem:
    amount = facts.transaction.amount
    passed = amount <= max_amount
    status = "PASS" if passed else "FAIL"
    return PolicyCheckItem(
        rule_id="RULE-004-AUTO_LIMIT",
        rule_name="Automatic Action Maximum Amount Limit",
        status=status,
        details=f"Disputed transaction amount ${amount:.2f} (Automatic threshold limit: ≤ ${max_amount:.2f})",
        source_passage_id="POL-CARD-OPS-v2#SEC-6.4",
        policy_citation="Section 6.4: Automatic mock dispute case creation and provisional credit authorization is restricted to transactions equal to or under $500.00 USD."
    )


def evaluate_identity_verification(facts: DomainFacts) -> PolicyCheckItem:
    verification_status = facts.customer.identity_verification_status
    valid_statuses = ["VERIFIED_2FA", "VERIFIED_OTP", "VERIFIED_PASSCODE"]
    passed = verification_status in valid_statuses
    status = "PASS" if passed else "FAIL"
    return PolicyCheckItem(
        rule_id="RULE-005-IDENTITY_VERIFICATION",
        rule_name="Customer Identity Verification Status",
        status=status,
        details=f"Customer identity verification state: '{verification_status}'",
        source_passage_id="POL-CARD-OPS-v2#SEC-2.3",
        policy_citation="Section 2.3: Strong identity authentication (2FA, OTP, or Passcode) must be recorded for cardholder intake."
    )


def evaluate_no_evidence_conflict(facts: DomainFacts) -> PolicyCheckItem:
    conflicts = facts.auth_log.conflicting_evidence_signals
    passed = len(conflicts) == 0
    status = "PASS" if passed else "CONFLICTING"
    conflict_desc = "; ".join(conflicts) if conflicts else "No conflicting authentication signals or merchant evidence detected."
    return PolicyCheckItem(
        rule_id="RULE-006-NO_CONFLICT",
        rule_name="Conflicting Evidence & Authentication Signal Check",
        status=status,
        details=conflict_desc,
        source_passage_id="POL-CARD-OPS-v2#SEC-7.8",
        policy_citation="Section 7.8: Any conflicting evidence signal (e.g. valid OTP device match or physical EMV chip insert) requires mandatory human analyst review."
    )


def evaluate_all_rules(facts: DomainFacts, confidence: float, confidence_threshold: float = 0.85, max_amount: float = 500.0) -> List[PolicyCheckItem]:
    """Evaluates all 6 machine-evaluable policy rules in sequence."""
    return [
        evaluate_confidence_threshold(facts, confidence, confidence_threshold),
        evaluate_dispute_window(facts),
        evaluate_no_duplicate_dispute(facts),
        evaluate_auto_action_limit(facts, max_amount),
        evaluate_identity_verification(facts),
        evaluate_no_evidence_conflict(facts)
    ]
