# BANK OPERATING POLICY MANUAL: CARD DISPUTE OPERATIONS (v2.0)

Document ID: POL-CARD-OPS-v2
Effective Date: 2026-01-01
Status: ACTIVE
Classification: INTERNAL OPERATING PROCEDURE

## Section 1: Overview and Scope
This document defines the operating procedures and deterministic authorization rules for processing cardholder claims regarding unrecognized or unauthorized credit and debit card transactions.

## Section 2: Identity & Authentication Verification Standards
- **SEC-2.1**: All dispute claims submitted by a cardholder must undergo identity validation.
- **SEC-2.3**: Strong identity authentication (such as 2FA, OTP verification, or authenticated mobile passcode) must be recorded for cardholder intake before processing any dispute request.

## Section 3: AI Grounding & Confidence Requirements
- **SEC-3.1**: Model assessment confidence must equal or exceed 0.85 (85%) for automated case processing. If confidence is below 0.85, the case must be escalated to a human analyst.

## Section 4: Dispute Filing Time Windows
- **SEC-4.1**: Under Regulation E and Visa/Mastercard operating rules, dispute claims must be filed in a timely manner.
- **SEC-4.2**: Unrecognized transaction dispute reports must be submitted within 60 calendar days of transaction settlement date. Transactions older than 60 calendar days cannot be automatically processed for chargeback and require manual compliance exception review.

## Section 5: Duplicate Filing Restrictions
- **SEC-5.1**: Multiple active dispute filings against a single settled transaction ID are strictly prohibited. The system must verify that no prior active dispute case exists for the target transaction ID.

## Section 6: Automatic Action Thresholds & Provisional Credit
- **SEC-6.1**: Small-dollar unrecognized transactions eligible for auto-dispute receive immediate mock case registration and provisional credit.
- **SEC-6.4**: Automatic mock dispute case creation and provisional credit authorization is restricted to transactions equal to or under $500.00 USD. Transactions exceeding $500.00 USD require mandatory human analyst approval before case creation.

## Section 7: Authentication Signals & Conflicting Evidence
- **SEC-7.1**: Authentication logs and POS entry modes must be evaluated for merchant or cardholder signals.
- **SEC-7.8**: Any conflicting evidence signal (e.g. valid 3DS OTP device match recorded during purchase or physical EMV chip insert with PIN at terminal) requires mandatory human analyst review and cannot be auto-approved.
