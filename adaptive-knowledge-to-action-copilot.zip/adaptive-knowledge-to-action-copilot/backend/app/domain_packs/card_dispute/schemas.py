"""
Pydantic contracts for Card Dispute Domain Pack.
Defines intake data, transaction facts, evidence assessment, and policy check items.
"""

from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any


class CardholderIntakePayload(BaseModel):
    transaction_id: str = Field(..., description="Target transaction ID e.g. TX-1001")
    cardholder_statement: str = Field(..., description="Statement provided by cardholder")
    dispute_category: str = Field(default="UNRECOGNIZED_CARD_TRANSACTION")
    channel: str = Field(default="MOBILE_APP")


class TransactionFacts(BaseModel):
    transaction_id: str
    cardholder_id: str
    card_last4: str
    merchant_name: str
    merchant_category: str
    amount: float
    currency: str = "USD"
    timestamp: str
    transaction_age_days: int
    channel: str
    pos_entry_mode: str
    billing_country: str
    shipping_country: str
    is_recurring: bool
    status: str


class CustomerVerificationFacts(BaseModel):
    customer_id: str
    full_name: str
    identity_verification_status: str
    kyc_tier: str
    account_tenure_months: int
    risk_segment: str


class DisputeHistoryFacts(BaseModel):
    customer_id: str
    previous_disputes_count: int
    dispute_history: List[Dict[str, Any]] = []
    is_duplicate_for_transaction: bool = False


class AuthenticationLogFacts(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    
    three_ds_auth_status: str = Field(alias="3ds_auth_status", default="NOT_ATTEMPTED")
    avs_match: str = "UNKNOWN"
    cvv_match: str = "UNKNOWN"
    ip_geolocation: str = ""
    device_fingerprint: str = ""
    conflicting_evidence_signals: List[str] = []


class DomainFacts(BaseModel):
    transaction: TransactionFacts
    customer: CustomerVerificationFacts
    dispute_history: DisputeHistoryFacts
    auth_log: AuthenticationLogFacts


class PolicyCheckItem(BaseModel):
    rule_id: str
    rule_name: str
    status: str  # PASS, FAIL, UNKNOWN, CONFLICTING
    details: str
    source_passage_id: str
    policy_citation: str


class EvidenceAssessment(BaseModel):
    classification: str
    confidence: float
    summary: str
    conflicting_signals: List[str] = []
    key_findings: List[str] = []
    recommended_action: str  # AUTO_APPROVE_DISPUTE or ESCALATE_HUMAN_REVIEW


class DisputeCaseRecord(BaseModel):
    case_id: str
    transaction_id: str
    dispute_reason: str
    disputed_amount: float
    idempotency_key: str
    created_by: str
    created_at: str
    status: str
    stage: str
    provisional_credit_issued: bool
