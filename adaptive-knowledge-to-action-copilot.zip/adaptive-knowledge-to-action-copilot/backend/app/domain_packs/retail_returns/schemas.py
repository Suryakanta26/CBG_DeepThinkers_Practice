"""
Pydantic contracts for Retail Return & Refund Operations Domain Pack.
"""

from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any


class CustomerReturnIntakePayload(BaseModel):
    order_id: str = Field(..., description="Target Order ID e.g. ORD-5001")
    customer_statement: str = Field(..., description="Statement / reason provided by customer")
    return_reason_code: str = Field(default="DAMAGED_IN_SHIPPING")
    channel: str = Field(default="ONLINE_PORTAL")


class OrderFacts(BaseModel):
    transaction_id: str  # maps to work item identifier
    cardholder_id: str   # maps to customer identifier
    card_last4: str      # SKU or tracking identifier
    merchant_name: str   # Item description / Product name
    merchant_category: str # Item category (Electronics, Apparel, Final Sale)
    amount: float
    currency: str = "USD"
    timestamp: str
    transaction_age_days: int # Days since delivery
    channel: str
    pos_entry_mode: str  # Fulfillment warehouse / store
    billing_country: str
    shipping_country: str
    is_recurring: bool   # Subscription or one-off
    status: str          # DELIVERED, SHIPPED, etc.


class CustomerProfileFacts(BaseModel):
    customer_id: str
    full_name: str
    identity_verification_status: str # VERIFIED_ACCOUNT, GUEST
    kyc_tier: str # VIP_TIER, STANDARD_TIER
    account_tenure_months: int
    risk_segment: str # LOW_RETURN_RATE, HIGH_RETURN_RATE


class ReturnHistoryFacts(BaseModel):
    customer_id: str
    previous_disputes_count: int
    dispute_history: List[Dict[str, Any]] = []
    is_duplicate_for_transaction: bool = False


class ItemInspectionFacts(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    three_ds_auth_status: str = Field(alias="3ds_auth_status", default="SERIAL_VERIFIED")
    avs_match: str = "PASS"
    cvv_match: str = "PASS"
    ip_geolocation: str = ""
    device_fingerprint: str = ""
    conflicting_evidence_signals: List[str] = []


class DomainFacts(BaseModel):
    transaction: OrderFacts
    customer: CustomerProfileFacts
    dispute_history: ReturnHistoryFacts
    auth_log: ItemInspectionFacts


class PolicyCheckItem(BaseModel):
    rule_id: str
    rule_name: str
    status: str  # PASS, FAIL, UNKNOWN, CONFLICTING
    details: str
    source_passage_id: str
    policy_citation: str


class EvidenceAssessment(BaseModel):
    classification: str
    confidence: float
    summary: str
    conflicting_signals: List[str] = []
    key_findings: List[str] = []
    recommended_action: str  # AUTO_APPROVE_REFUND or ESCALATE_HUMAN_REVIEW
