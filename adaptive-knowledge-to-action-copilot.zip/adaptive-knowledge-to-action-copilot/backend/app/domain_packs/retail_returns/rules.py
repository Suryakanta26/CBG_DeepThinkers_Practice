"""
Reviewed machine-evaluable operating policy rules for Retail Returns & Refund Domain Pack.
"""

from typing import List, Dict, Any
from backend.app.domain_packs.retail_returns.schemas import DomainFacts, PolicyCheckItem


def evaluate_confidence_threshold(facts: DomainFacts, confidence: float, threshold: float = 0.85) -> PolicyCheckItem:
    passed = confidence >= threshold
    status = "PASS" if passed else "FAIL"
    return PolicyCheckItem(
        rule_id="RULE-RET-001-CONFIDENCE",
        rule_name="AI Model Grounding Confidence Threshold",
        status=status,
        details=f"Model confidence score {confidence:.2f} (Required: ≥ {threshold:.2f})",
        source_passage_id="POL-RET-OPS-v1#SEC-1.2",
        policy_citation="Section 1.2: AI classification and defect assessment confidence must equal or exceed 0.85."
    )


def evaluate_return_window(facts: DomainFacts) -> PolicyCheckItem:
    age_days = facts.transaction.transaction_age_days
    max_days = 30
    passed = age_days <= max_days
    status = "PASS" if passed else "FAIL"
    return PolicyCheckItem(
        rule_id="RULE-RET-002-RETURN_WINDOW",
        rule_name="Standard Return Window (≤ 30 Days from Delivery)",
        status=status,
        details=f"Days since delivery: {age_days} days (Maximum allowed: {max_days} days)",
        source_passage_id="POL-RET-OPS-v1#SEC-2.1",
        policy_citation="Section 2.1: Products are eligible for refund/return within 30 calendar days of delivery date."
    )


def evaluate_non_final_sale(facts: DomainFacts) -> PolicyCheckItem:
    category = facts.transaction.merchant_category.upper()
    is_final_sale = "FINAL_SALE" in category or "CLEARANCE" in category
    status = "PASS" if not is_final_sale else "FAIL"
    return PolicyCheckItem(
        rule_id="RULE-RET-003-NON_FINAL_SALE",
        rule_name="Non-Final Sale Inventory Category Check",
        status=status,
        details=f"Item category: '{facts.transaction.merchant_name}'" if not is_final_sale else "Item is marked FINAL_SALE / Clearance Non-Returnable",
        source_passage_id="POL-RET-OPS-v1#SEC-3.4",
        policy_citation="Section 3.4: Clearance and Final Sale items cannot be returned or refunded unless received defective with photo proof."
    )


def evaluate_auto_refund_limit(facts: DomainFacts, max_amount: float = 200.0) -> PolicyCheckItem:
    amount = facts.transaction.amount
    passed = amount <= max_amount
    status = "PASS" if passed else "FAIL"
    return PolicyCheckItem(
        rule_id="RULE-RET-004-AUTO_REFUND_LIMIT",
        rule_name="Instant Auto-Refund Maximum Amount Limit",
        status=status,
        details=f"Order refund total: ${amount:.2f} (Instant auto-refund limit: ≤ ${max_amount:.2f})",
        source_passage_id="POL-RET-OPS-v1#SEC-4.1",
        policy_citation="Section 4.1: Instant automated refund without manager escalation is restricted to orders equal to or under $200.00 USD."
    )


def evaluate_customer_fraud_abuse(facts: DomainFacts) -> PolicyCheckItem:
    risk = facts.customer.risk_segment
    passed = "HIGH" not in risk.upper()
    status = "PASS" if passed else "FAIL"
    return PolicyCheckItem(
        rule_id="RULE-RET-005-ABUSE_CHECK",
        rule_name="Customer Return Frequency & Abuse Risk Check",
        status=status,
        details=f"Customer risk profile: '{risk}'",
        source_passage_id="POL-RET-OPS-v1#SEC-5.2",
        policy_citation="Section 5.2: Accounts flagged for high return-rate abuse or repeated wardrobing claims require supervisor review."
    )


def evaluate_item_condition_signals(facts: DomainFacts) -> PolicyCheckItem:
    conflicts = facts.auth_log.conflicting_evidence_signals
    passed = len(conflicts) == 0
    status = "PASS" if passed else "CONFLICTING"
    desc = "; ".join(conflicts) if conflicts else "Serial number and barcode match delivered warehouse scan. No fraud signals detected."
    return PolicyCheckItem(
        rule_id="RULE-RET-006-CONDITION_VERIFICATION",
        rule_name="Serial Match & Package Scan Verification",
        status=status,
        details=desc,
        source_passage_id="POL-RET-OPS-v1#SEC-6.3",
        policy_citation="Section 6.3: Any serial number mismatch or package weight discrepancy blocks automated refund."
    )


def evaluate_all_retail_rules(facts: DomainFacts, confidence: float, confidence_threshold: float = 0.85, max_amount: float = 200.0) -> List[PolicyCheckItem]:
    """Evaluates all 6 retail operating rules in sequence."""
    return [
        evaluate_confidence_threshold(facts, confidence, confidence_threshold),
        evaluate_return_window(facts),
        evaluate_non_final_sale(facts),
        evaluate_auto_refund_limit(facts, max_amount),
        evaluate_customer_fraud_abuse(facts),
        evaluate_item_condition_signals(facts)
    ]
