"""
Tests for Standalone Mock MCP Server and Tool Protocol.
"""

from mcp_server.server import mcp_server_instance
from backend.app.core.mcp_client import mcp_client


def test_mcp_tool_discovery():
    tools = mcp_server_instance.list_tools()
    tool_names = [t["name"] for t in tools]
    assert "get_transaction_facts" in tool_names
    assert "get_customer_verification" in tool_names
    assert "get_dispute_history" in tool_names
    assert "create_mock_dispute_case" in tool_names


def test_mcp_ingestion_tools():
    res = mcp_server_instance.call_tool("get_transaction_facts", {"transaction_id": "TX-1001"})
    assert res["status"] == "success"
    data = res["result"]
    assert data["transaction"]["transaction_id"] == "TX-1001"
    assert data["customer"]["full_name"] == "Alex Mercer"


def test_mcp_action_tool_idempotency():
    key = "TEST-IDEM-9999"
    args = {
        "transaction_id": "TX-1001",
        "dispute_reason": "UNRECOGNIZED_CARD_TRANSACTION",
        "amount": 349.99,
        "idempotency_key": key,
        "authorized_by": "TEST_GATE"
    }
    res1 = mcp_server_instance.call_tool("create_mock_dispute_case", args)
    assert res1["status"] == "success"
    case1 = res1["result"]["case_record"]["case_id"]

    # Re-call with same idempotency key
    res2 = mcp_server_instance.call_tool("create_mock_dispute_case", args)
    assert res2["status"] == "success"
    case2 = res2["result"]["case_record"]["case_id"]

    assert case1 == case2


def test_mcp_client_methods():
    tools = mcp_client.discover_tools()
    assert len(tools) >= 4
    
    # Execute a tool via client
    res = mcp_client.execute_tool("get_transaction_facts", {"transaction_id": "TX-1001"})
    assert res["status"] == "success"
    
    logs = mcp_client.get_telemetry_logs()
    assert len(logs) > 0
    assert logs[-1]["tool_name"] == "get_transaction_facts"
