"""
Tests for Deterministic Policy Authorization Gate & Rule Evaluation.
"""

from backend.app.core.policy_gate import PolicyAuthorizationGate
from backend.app.domain_packs.card_dispute.schemas import PolicyCheckItem


def test_policy_gate_all_pass():
    gate = PolicyAuthorizationGate()
    checks = [
        PolicyCheckItem(rule_id="R1", rule_name="Confidence Check", status="PASS", details="Score 0.95 >= 0.85", source_passage_id="P1", policy_citation="Cit 1"),
        PolicyCheckItem(rule_id="R2", rule_name="Time Window", status="PASS", details="Age 14 <= 60", source_passage_id="P2", policy_citation="Cit 2")
    ]
    is_auth, reason, matrix = gate.evaluate_gate(checks)
    assert is_auth is True
    assert "AUTO_AUTHORIZED" in reason


def test_policy_gate_fails_closed_on_fail_or_conflict():
    gate = PolicyAuthorizationGate()
    checks = [
        PolicyCheckItem(rule_id="R1", rule_name="Confidence Check", status="PASS", details="Score 0.95 >= 0.85", source_passage_id="P1", policy_citation="Cit 1"),
        PolicyCheckItem(rule_id="R2", rule_name="Auto Amount Limit", status="FAIL", details="Amount $1250 > $500", source_passage_id="P2", policy_citation="Cit 2")
    ]
    is_auth, reason, matrix = gate.evaluate_gate(checks)
    assert is_auth is False
    assert "HUMAN_REVIEW_ESCALATION" in reason
