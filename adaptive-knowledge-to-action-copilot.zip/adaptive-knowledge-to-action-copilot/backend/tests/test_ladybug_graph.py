"""
Tests for LadybugDB Embedded Property Graph & Cypher Query Engine.
"""

from backend.app.core.retrieval.ladybug_graph import LadybugGraphEngine


def test_ladybug_cypher_traversal():
    engine = LadybugGraphEngine(db_path="test_ladybug.lbug")
    triples = {
        "nodes": [
            {"id": "UNRECOGNIZED_CARD", "label": "DisputeCategory", "properties": {"name": "Unrecognized Card"}},
            {"id": "POL-SEC-3.1", "label": "PolicySection", "properties": {"title": "Confidence Limit"}},
            {"id": "RULE-001", "label": "RuleCondition", "properties": {"threshold": 0.85}}
        ],
        "edges": [
            {"source": "UNRECOGNIZED_CARD", "target": "POL-SEC-3.1", "type": "REGULATES"},
            {"source": "POL-SEC-3.1", "target": "RULE-001", "type": "REQUIRES_CHECK"}
        ]
    }
    engine.load_triples(triples)
    
    subgraph = engine.get_subgraph_for_category("UNRECOGNIZED_CARD")
    assert len(subgraph["nodes"]) == 3
    assert len(subgraph["edges"]) == 2
