# Adaptive Knowledge-to-Action Copilot — System Architecture & Code Implementation

Here is the updated **Dual-Stream Architecture Diagram** with **Domain Configuration** and clear directional flow arrows:

![Adaptive Knowledge-to-Action Copilot Architecture](docs/architecture_diagram.jpg)

---

## Interactive Architecture Flow (Mermaid)

```mermaid
graph TD
    classDef fe fill:#e0f2fe,stroke:#0284c7,stroke-width:2px,color:#0369a1;
    classDef know fill:#ecfdf5,stroke:#059669,stroke-width:2px,color:#047857;
    classDef mcp_in fill:#dbeafe,stroke:#2563eb,stroke-width:2px,color:#1d4ed8;
    classDef core fill:#f3e8ff,stroke:#9333ea,stroke-width:2px,color:#6b21a8;
    classDef gate fill:#fef3c7,stroke:#d97706,stroke-width:2px,color:#b45309;
    classDef auto fill:#dcfce7,stroke:#16a34a,stroke-width:2px,color:#15803d;
    classDef human fill:#ffe4e6,stroke:#e11d48,stroke-width:2px,color:#be123c;
    classDef kpi fill:#f8fafc,stroke:#475569,stroke-width:2px,color:#0f172a;

    subgraph Tier1["Tier 1: Frontend Tier (React + TypeScript + Vite)"]
        UI_Config["Domain Configuration"]:::fe
        UI_Matrix["Policy Gate Matrix"]:::fe
        UI_Graph["Graph Visualizer"]:::fe
        UI_Console["MCP Console"]:::fe
    end

    subgraph DualStream["Dual-Source Grounding Streams"]
        subgraph StaticKnowledge["Static Policy Knowledge Engine"]
            VEC[("Vector Store")]:::know
            BM25[("BM25 Index")]:::know
            LBUG[("LadybugDB .lbug Cypher Graph")]:::know
        end

        subgraph LiveMCP["Live Enterprise Data Ingestion"]
            T1["MCP: get_transaction_facts"]:::mcp_in
            T2["MCP: get_customer_verification"]:::mcp_in
            T3["MCP: get_dispute_history"]:::mcp_in
        end
    end

    subgraph ReasoningCore["Tier 3: LangGraph Orchestrator & LLM Reasoning"]
        PromptFuse["Fuses Live MCP Facts + Policy Grounding Envelope"]:::core
    end

    subgraph PolicyGateTier["Tier 4: Deterministic Policy Authorization Gate"]
        GateEval["Evaluates 6 Machine Rules (1.Confidence, 2.Window, 3.No Duplicate, 4.Amount Limit, 5.Identity 2FA, 6.No Conflict)"]:::gate
    end

    subgraph OutcomesTier["Tier 5: Outcomes & Action Execution Tier"]
        subgraph AutoPath["Path A: Auto-Authorized Action (100% Pass)"]
            AutoAuth["Auto-Authorized Action"]:::auto
            MCPActionAuto["MCP Action Tool (create_case)"]:::auto
            IdemRecord["Idempotent Case Record"]:::auto
        end

        subgraph HumanPath["Path B: Human Escalation (Rule Failed)"]
            AnalystConsole["Analyst Review"]:::human
            MCPActionHuman["MCP Action Tool (If Approved)"]:::auto
        end
    end

    subgraph TierKPI["Business & Governance Outcomes"]
        KPI1["AHT Reduction"]:::kpi
        KPI2["Policy Compliance"]:::kpi
        KPI3["Zero Erroneous Actions"]:::kpi
        KPI4["Idempotency & Audit Trail"]:::kpi
    end

    %% Explicit Flow Connections
    Tier1 -->|"Configure Domain"| StaticKnowledge
    Tier1 -->|"Intake Claim"| LiveMCP
    StaticKnowledge --> PromptFuse
    LiveMCP --> PromptFuse
    PromptFuse --> GateEval
    GateEval -->|"Path A: 100% Pass"| AutoAuth
    GateEval -->|"Path B: Rule Failed"| AnalystConsole
    AutoAuth --> MCPActionAuto --> IdemRecord
    AnalystConsole -->|"If Approved"| MCPActionHuman
    IdemRecord --> TierKPI
```

---

## The Exact 6 Deterministic Policy Rules Evaluated in Code

In [backend/app/domain_packs/card_dispute/rules.py](file:///c:/Users/surya/Documents/POCs/adaptive-knowledge-to-action-copilot2/backend/app/domain_packs/card_dispute/rules.py), exactly **6 machine-evaluable rules** are executed:

| # | Rule ID | Function in `rules.py` | Policy Threshold / Logic | Source Citation |
| :--- | :--- | :--- | :--- | :--- |
| **1** | `RULE-001-CONFIDENCE` | `evaluate_confidence_threshold` | Grounding confidence $\ge 0.85$ (85%) | `POL-CARD-OPS-v2#SEC-3.1` |
| **2** | `RULE-002-DISPUTE_WINDOW` | `evaluate_dispute_window` | Transaction age $\le 60$ calendar days | `POL-CARD-OPS-v2#SEC-4.2` |
| **3** | `RULE-003-NO_DUPLICATE` | `evaluate_no_duplicate_dispute` | Zero prior active disputes on transaction | `POL-CARD-OPS-v2#SEC-5.1` |
| **4** | `RULE-004-AUTO_LIMIT` | `evaluate_auto_action_limit` | Disputed amount $\le \$500.00\text{ USD}$ | `POL-CARD-OPS-v2#SEC-6.4` |
| **5** | `RULE-005-IDENTITY_VERIFICATION` | `evaluate_identity_verification` | Identity in `[VERIFIED_2FA, VERIFIED_OTP, VERIFIED_PASSCODE]` | `POL-CARD-OPS-v2#SEC-2.3` |
| **6** | `RULE-006-NO_CONFLICT` | `evaluate_no_evidence_conflict` | Zero conflicting authentication/chip insert signals | `POL-CARD-OPS-v2#SEC-7.8` |
